// ShellCommandHandler.cpp : Implementation of CShellCommandHandler

#include "stdafx.h"
#include "resource.h"
#include "AlgoSeekShellExtension.h"
#include "ShellCommandHandler.h"

using namespace TIS::Applications::Customer::Windows;

/////////////////////////////////////////////////////////////////////////////
// CShellCommandHandler

STDMETHODIMP CShellCommandHandler::Initialize (
    LPCITEMIDLIST pidlFolder, LPDATAOBJECT pDataObj, HKEY hProgID )
{
	FORMATETC fmt = { CF_HDROP, NULL, DVASPECT_CONTENT, -1, TYMED_HGLOBAL };
	STGMEDIUM stg = { TYMED_HGLOBAL };
	HDROP     hDrop;

    // Look for CF_HDROP data in the data object.
    if ( FAILED( pDataObj->GetData ( &fmt, &stg ) ))
        {
        // Nope! Return an "invalid argument" error back to Explorer.
        return E_INVALIDARG;
        }

    // Get a pointer to the actual data.
    hDrop = (HDROP) GlobalLock ( stg.hGlobal );

    // Make sure it worked.
    if ( NULL == hDrop )
        return E_INVALIDARG;

    // Sanity check - make sure there is at least one filename.
	UINT uNumFiles = DragQueryFile ( hDrop, 0xFFFFFFFF, NULL, 0 );
	HRESULT hr = S_OK;

    if ( 0 == uNumFiles )
        {
        GlobalUnlock ( stg.hGlobal );
        ReleaseStgMedium ( &stg );
        return E_INVALIDARG;
        }

    // Get the name of the first file and store it in our member variable m_szFile.
	// TODO: what to do with multiple file selection?
    if ( 0 == DragQueryFileW ( hDrop, 0, m_szFile, MAX_PATH ) )
        hr = E_INVALIDARG;

    GlobalUnlock ( stg.hGlobal );
    ReleaseStgMedium ( &stg );

    return hr;
}

STDMETHODIMP CShellCommandHandler::QueryContextMenu (
    HMENU hmenu, UINT uMenuIndex, UINT uidFirstCmd,
    UINT uidLastCmd, UINT uFlags )
{
    // If the flags include CMF_DEFAULTONLY then we shouldn't do anything.
    if ( uFlags & CMF_DEFAULTONLY )
        return MAKE_HRESULT ( SEVERITY_SUCCESS, FACILITY_NULL, 0 );

	HINSTANCE HINSTANCE_This = _Module.GetResourceInstance();

	// TODO: show only if we are on the right path

	MENUITEMINFO mySep;
	mySep.cbSize = sizeof(MENUITEMINFO);
	mySep.fMask = MIIM_TYPE;
	mySep.fType = MFT_SEPARATOR;
	// load a bitmap picture for menu item  (it should be 16x16 to display well)
	HBITMAP hBitmap = (HBITMAP)LoadBitmap(HINSTANCE_This, MAKEINTRESOURCE(IDI_MENU_ICON_BMP));
	if (hBitmap == NULL)
	{
		char szMsg[MAX_PATH + 32];
		sprintf(szMsg, "Error load icon. GetLastError()=%d", GetLastError());
		::MessageBoxA(NULL, szMsg, "Warning", 0);
	}
	// place separator
	InsertMenu(hmenu, uMenuIndex, MF_SEPARATOR | MF_BYPOSITION, NULL, NULL);
	// place a menu entry and a bitmap
	uMenuIndex++;
	// TODO: add a submenu here instead
	InsertMenuW(hmenu, uMenuIndex, MF_STRING | MF_BYPOSITION, uidFirstCmd, MENU_ITEM_NAME);
	if (SetMenuItemBitmaps(hmenu, uMenuIndex, MF_BITMAP | MF_BYPOSITION, hBitmap, hBitmap) == FALSE)
	{
		char szMsg[MAX_PATH + 32];
		sprintf(szMsg, "Error set icon. GetLastError()=%d", GetLastError());
		::MessageBoxA(NULL, szMsg, "Warning", 0);
	}
	// place separator
	uMenuIndex++;
	InsertMenu(hmenu, uMenuIndex, MF_SEPARATOR | MF_BYPOSITION, NULL, NULL);

    return MAKE_HRESULT ( SEVERITY_SUCCESS, FACILITY_NULL, 1 );
}

STDMETHODIMP CShellCommandHandler::GetCommandString (
    UINT_PTR idCmd, UINT uFlags, UINT* pwReserved, LPSTR pszName, UINT cchMax )
{
	USES_CONVERSION;

    // Check idCmd, it must be 0 since we have only one menu item.
    if ( 0 != idCmd )
        return E_INVALIDARG;

    // If Explorer is asking for a help string, copy our string into the
    // supplied buffer.
    if ( uFlags & GCS_HELPTEXT )
        {
        LPCTSTR szText = _T("This is the simple shell extension's help");

        if ( uFlags & GCS_UNICODE )
            {
            // We need to cast pszName to a Unicode string, and then use the
            // Unicode string copy API.
            lstrcpynW ( (LPWSTR) pszName, T2CW(szText), cchMax );
            }
        else
            {
            // Use the ANSI string copy API to return the help string.
            lstrcpynA ( pszName, T2CA(szText), cchMax );
            }

        return S_OK;
        }

    return E_INVALIDARG;
}

/////////////////////////////////////////////////////////////////////////////
// Loads the program with parms to run from the registry.
// Parms:
// szName - name of value to get
// szValue - buffer to recieve the results,
// nChars - buffer size in chars
// Notes :
//  The function will fail if there is no sufficient space in szValue,
//  so choose the buffer size accordingly.
//  The function will fail if the value is absent too.

BOOL CShellCommandHandler::GetStringFromConfig(IN LPCWSTR szName, OUT LPWSTR szValue, ULONG nChars)
{
	CLSID guid = CShellCommandHandler::GetObjectCLSID();
	WCHAR szSubKey[MAX_PATH] = L"";
	wsprintfW(szSubKey, L"CLSID\\{%08lX-%04hX-%04hX-%02hX%02hX-%02hX%02hX%02hX%02hX%02hX%02hX}\\InprocServer32",
		guid.Data1, guid.Data2, guid.Data3,
		guid.Data4[0], guid.Data4[1], guid.Data4[2], guid.Data4[3],
		guid.Data4[4], guid.Data4[5], guid.Data4[6], guid.Data4[7]);
	HKEY hKey = NULL;
	ULONG nBytes = nChars*sizeof(WCHAR);
	DWORD dwType = REG_SZ;
	LONG err = RegOpenKeyExW(HKEY_CLASSES_ROOT, szSubKey, 0, KEY_READ, &hKey);
	if (err != ERROR_SUCCESS)
	{
		// TODO: create a generic code base for errors
		TCHAR szMsg[MAX_PATH + 32];
		_stprintf(szMsg, _T("Cannot open registry key %ls. Error=%d"), szSubKey, err);
		::MessageBox(NULL, szMsg, _T("Error"), 0);
		return FALSE;
	}
	err = RegQueryValueExW(hKey, szName, NULL, &dwType, reinterpret_cast<LPBYTE>(szValue), &nBytes);
	if (err != ERROR_SUCCESS)
	{
		// TODO: create a generic code base for errors
		TCHAR szMsg[MAX_PATH + 32];
		_stprintf(szMsg, _T("Cannot get config value %ls from the registry %ls. Error=%d"), szName, szSubKey, err);
		::MessageBox(NULL, szMsg, _T("Error"), 0);
		return FALSE;
	}
	return TRUE;
}

BOOL CShellCommandHandler::RunCommand()
{
	ULONG nBufferSize = 2048;
	WCHAR * szCommandBuffer = new WCHAR[nBufferSize];
	BOOL res = FALSE;
	// TODO: load default python code to run here
	if (GetStringFromConfig(EXEC_COMMAND_REG_VALUE, szCommandBuffer, nBufferSize))
	{
		wcsncat(szCommandBuffer, m_szFile, nBufferSize);
		STARTUPINFOW sInfo = { 0 };
		sInfo.cb = sizeof(sInfo);
		PROCESS_INFORMATION pInfo = { 0 };

		res = CreateProcessW(NULL, szCommandBuffer, 0, 0, TRUE,
			NORMAL_PRIORITY_CLASS, 0, 0, &sInfo, &pInfo);
		if (!res)
		{
			// TODO: create a generic error-handling code
			char szMsg[MAX_PATH + 32];
			sprintf(szMsg, "Failed to start process! GetLastError()=%d", GetLastError());
			::MessageBoxA(NULL, szMsg, "Error", 0);
		}
	}

	delete[] szCommandBuffer;
	return res;
}

STDMETHODIMP CShellCommandHandler::InvokeCommand ( LPCMINVOKECOMMANDINFO pCmdInfo )
{
    // If lpVerb really points to a string, ignore this function call and bail out.
    if ( 0 != HIWORD( pCmdInfo->lpVerb ) )
        return E_INVALIDARG;

    // Get the command index - the only valid one is 0.
    switch ( LOWORD( pCmdInfo->lpVerb) )
        {
        case 0:
            {
				return Execute();
            }
        break;

        default:
            return E_INVALIDARG;
        break;
        }
}

// the object is either called as ContextMenu or ExecuteCommand

// Set item selection
STDMETHODIMP CShellCommandHandler::SetSelection(IShellItemArray * arr)
{
	DBG_TRACE(::MessageBox(NULL, _T("SetSelection"), _T("Dbg"), 0));
	if (arr == NULL)
	{
		wcscpy_s(this->m_szFile, L"");
		return S_OK;
	}
	DWORD nCount = 0;
	if (arr->GetCount(&nCount) != S_OK)
		return E_INVALIDARG;
	if (nCount == 0)
	{
		wcscpy_s(this->m_szFile, L"");
		return S_OK;
	}

	// TODO: what to do with multiple file selection?
	IShellItem * si;
	if (arr->GetItemAt(0, &si) != S_OK)
		return E_INVALIDARG;
	WCHAR* szFilepath;
	if (si->GetDisplayName(SIGDN_FILESYSPATH, &szFilepath) != S_OK)
		return E_FAIL;
	wcscpy_s(this->m_szFile, szFilepath);
	CoTaskMemFree(szFilepath);
	return S_OK;
}

// Execute command interface impl
STDMETHODIMP CShellCommandHandler::SetParameters(LPCWSTR lpszFile)
{
	//::MessageBoxW(NULL, lpszFile, L"Debug", NULL);
	//wcscpy_s(this->m_szFile, lpszFile);
	return S_OK;
}
STDMETHODIMP CShellCommandHandler::SetDirectory(LPCWSTR lpszDir)
{
	// not sure if needed at all
	return S_OK;
}
STDMETHODIMP CShellCommandHandler::Execute()
{
	if (RunCommand())
		return S_OK;
	return E_FAIL;
}


// IExplorerCommand
STDMETHODIMP CShellCommandHandler::GetTitle(
__in IShellItemArray* psiItemArray,
__out LPWSTR* ppszName
)
{
	UNREFERENCED_PARAMETER(psiItemArray);
	DBG_TRACE(::MessageBox(NULL, _T("GetTitle"), _T("Dbg"), 0));

	HRESULT hr = E_FAIL;
	hr = SHStrDupW(MENU_ITEM_NAME, ppszName);
	
	return hr;
}

STDMETHODIMP CShellCommandHandler::GetIcon(
	__in IShellItemArray* psiItemArray,
	__out LPWSTR* ppszIcon
	)
{
	UNREFERENCED_PARAMETER(psiItemArray);
	DBG_TRACE(::MessageBox(NULL, _T("GetIcon"), _T("Dbg"), 0));

	WCHAR fileName[MAX_PATH + 1] = L"";
	GetModuleFileNameW(_Module.GetResourceInstance(), fileName, MAX_PATH);
	WCHAR fullStr[MAX_PATH + 50] = L"";
	wsprintfW(fullStr, L"%ls,-%d", fileName, IDI_MENU_ICON_ICO);
	return SHStrDupW(fullStr, ppszIcon);
}

STDMETHODIMP CShellCommandHandler::GetToolTip(__in IShellItemArray* psiItemArray,
__out LPWSTR* ppszName
)
{
	UNREFERENCED_PARAMETER(psiItemArray);
	DBG_TRACE(::MessageBox(NULL, _T("GetToolTip"), _T("Dbg"), 0));

	HRESULT hr = E_FAIL;
	hr = SHStrDupW(MENU_ITEM_TOOLTIP, ppszName);

	return hr;
}
STDMETHODIMP CShellCommandHandler::GetCanonicalName(__out GUID* pguidCommandName)
{
	DBG_TRACE(::MessageBox(NULL, _T("GetCanonicalName"), _T("Dbg"), 0));
	*pguidCommandName = __uuidof(ShellCommandHandler);
	return S_OK;
}

STDMETHODIMP CShellCommandHandler::GetState(
	__in_opt IShellItemArray* psiItemArray,
	BOOL fOkToBeSlow,
	__out EXPCMDSTATE* pCmdState
	)
{
	UNREFERENCED_PARAMETER(psiItemArray);
	UNREFERENCED_PARAMETER(fOkToBeSlow);
	DBG_TRACE(::MessageBox(NULL, _T("GetState"), _T("Dbg"), 0));
	*pCmdState = ECS_ENABLED;
	return S_OK;
}

STDMETHODIMP CShellCommandHandler::GetFlags(__out EXPCMDFLAGS* pFlags)
{
	DBG_TRACE(::MessageBox(NULL, _T("GetFlags"), _T("Dbg"), 0));
	*pFlags = ECF_DEFAULT;
	return S_OK;
}

STDMETHODIMP CShellCommandHandler::EnumSubCommands(IEnumExplorerCommand** ppEnum)
{
	UNREFERENCED_PARAMETER(ppEnum);
	DBG_TRACE(::MessageBox(NULL, _T("EnumSubCommands"), _T("Dbg"), 0));
	return E_NOTIMPL;
}

STDMETHODIMP CShellCommandHandler::Invoke(__in IShellItemArray* psiItemArray, __in IBindCtx* pbc)
{
	DBG_TRACE(::MessageBox(NULL, _T("Invoke"), _T("Dbg"), 0));
	HRESULT hr = SetSelection(psiItemArray);
	if (hr != S_OK)
		return hr;
	return Execute();
}


STDMETHODIMP CShellCommandHandler::Initialize(LPCWSTR, IPropertyBag *)
{
	DBG_TRACE(::MessageBox(NULL, _T("Initialize"), _T("Dbg"), 0));
	// NOTE: the first parm is command name (just in case we use this extension to handle several different commands)
	wcscpy_s(this->m_szFile, L"");
	return S_OK;
}

HRESULT WINAPI CShellCommandHandler::InternalQueryInterface(
	_Inout_ void* pThis,
	_In_ const _ATL_INTMAP_ENTRY* pEntries,
	_In_ REFIID iid,
	_COM_Outptr_ void** ppvObject)
{
	CLSID guid = iid;
	WCHAR szMsg[256] = L"";
	wsprintfW(szMsg, L"CLSID : {%08lX-%04hX-%04hX-%02hX%02hX-%02hX%02hX%02hX%02hX%02hX%02hX}",
		guid.Data1, guid.Data2, guid.Data3,
		guid.Data4[0], guid.Data4[1], guid.Data4[2], guid.Data4[3],
		guid.Data4[4], guid.Data4[5], guid.Data4[6], guid.Data4[7]);
	DBG_TRACE(::MessageBoxW(NULL, szMsg, L"QueryInterface", 0));
	return CComObjectRootBase::InternalQueryInterface(pThis, pEntries, iid, ppvObject);
}