// SimpleShlExt.h : Declaration of the CShellCommandHandler

#ifndef __SIMPLESHLEXT_H_
#define __SIMPLESHLEXT_H_

/////////////////////////////////////////////////////////////////////////////
// A string value under HKCR\{CLSID} registry that have a command line to be run with parms
// a filename selected is appended to it (without a space)

#define EXEC_COMMAND_REG_VALUE L"Command"

/////////////////////////////////////////////////////////////////////////////
// What text is displayed as for the menu item (TODO: load from resources)
#define MENU_ITEM_NAME L"AlgoSeek Drive..."

/////////////////////////////////////////////////////////////////////////////
// What text is displayed as for tooltip of the menu item (TODO: load from resources)
#define MENU_ITEM_TOOLTIP L"Click to open Sharing and Security web interface"

namespace TIS {
	namespace Applications {
		namespace Customer {
			namespace Windows {

				/////////////////////////////////////////////////////////////////////////////
				// CShellCommandHandler

				class ATL_NO_VTABLE CShellCommandHandler :
					public CComObjectRootEx<CComSingleThreadModel>,
					public CComCoClass<CShellCommandHandler, &CLSID_ShellCommandHandler>,
					public IShellExtInit,
					public IContextMenu,
					public IExecuteCommand,
					public IObjectWithSelection,
					public IExplorerCommand,
					public IInitializeCommand
				{
				public:
					CShellCommandHandler() { }

					DECLARE_REGISTRY_RESOURCEID(IDR_SIMPLESHLEXT)

					BEGIN_COM_MAP(CShellCommandHandler)
						COM_INTERFACE_ENTRY(IShellExtInit)
						COM_INTERFACE_ENTRY(IContextMenu)
						COM_INTERFACE_ENTRY(IExecuteCommand)
						COM_INTERFACE_ENTRY(IObjectWithSelection)
						COM_INTERFACE_ENTRY(IExplorerCommand)
						COM_INTERFACE_ENTRY(IInitializeCommand)
					END_COM_MAP()

				public:
					// IShellExtInit
					STDMETHODIMP Initialize(LPCITEMIDLIST, LPDATAOBJECT, HKEY);

					// IContextMenu
					STDMETHODIMP GetCommandString(UINT_PTR, UINT, UINT*, LPSTR, UINT);
					STDMETHODIMP InvokeCommand(LPCMINVOKECOMMANDINFO);
					STDMETHODIMP QueryContextMenu(HMENU, UINT, UINT, UINT, UINT);

					// IExecuteCommand
					STDMETHODIMP SetKeyState(DWORD) { return S_OK; }
					STDMETHODIMP SetPosition(POINT) { return S_OK; }
					STDMETHODIMP SetShowWindow(int) { return S_OK; }
					STDMETHODIMP SetNoShowUI(BOOL) { return S_OK; }
					STDMETHODIMP SetParameters(LPCWSTR);
					STDMETHODIMP SetDirectory(LPCWSTR);
					STDMETHODIMP Execute();

					// IObjectWithSelection
					STDMETHODIMP SetSelection(IShellItemArray*);
					STDMETHODIMP GetSelection(__RPC__in REFIID, __RPC__deref_out_opt void **) { return E_NOTIMPL; }

					// IExplorerCommand
					STDMETHODIMP GetTitle(IShellItemArray*, LPWSTR*);
					STDMETHODIMP GetIcon(IShellItemArray*, LPWSTR*);
					STDMETHODIMP GetToolTip(IShellItemArray*, LPWSTR*);
					STDMETHODIMP GetCanonicalName(GUID *);
					STDMETHODIMP GetState(IShellItemArray*, BOOL, EXPCMDSTATE *);
					STDMETHODIMP Invoke(IShellItemArray*, IBindCtx *);
					STDMETHODIMP GetFlags(EXPCMDFLAGS *);
					STDMETHODIMP EnumSubCommands(IEnumExplorerCommand**);

					// IInitializeCommand
					STDMETHODIMP Initialize(LPCWSTR, IPropertyBag *);

					// for debugging reasons we intercept InternalQueryInterface
					HRESULT WINAPI InternalQueryInterface(
						_Inout_ void* pThis,
						_In_ const _ATL_INTMAP_ENTRY* pEntries,
						_In_ REFIID iid,
						_COM_Outptr_ void** ppvObject);

				protected:
					WCHAR m_szFile[MAX_PATH];

					BOOL GetStringFromConfig(IN LPCWSTR szName, OUT LPWSTR szValue, ULONG nChars);
					BOOL RunCommand();
				};

			}
		}
	}
}

#endif //__SIMPLESHLEXT_H_
