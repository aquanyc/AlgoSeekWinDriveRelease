"""
This module implements responses to events happened to driver
that require user attention and possibly some interaction
"""

#driver module
from ASVirtualDrive.status_code import *

#local includes
from notify import *
from errors import *
import index

#standard library
import re
import subprocess
import threading
import time
import datetime
import traceback
import logging

def get_message_code(message):
    m = re.match(r'.*Code: (.*)\n', message , re.MULTILINE+re.DOTALL)
    if not m:
        return ""
    code = m.group(1)
    return code

def get_message_parm(message):
    m = re.match(r'.*Parm: (.*)\n*', message , re.MULTILINE+re.DOTALL)
    if not m:
        return ""
    parm = m.group(1)
    return parm

#TODO: to config
access_denied_notify_threshold_sec = 10
last_access_denied_notification = None

def handle_access_denied(message):
    global last_access_denied_notification
    denied_message = "Please contact AlgoSeek for authorization.\n\n"
    if last_access_denied_notification:
        if (datetime.datetime.now() - last_access_denied_notification).seconds < access_denied_notify_threshold_sec:
            return
    message_box("AlgoSeek Drive: Access Denied" , denied_message + message)
    last_access_denied_notification = datetime.datetime.now()
    return

# list of db's that are being downloaded, we save it so not to ask user several times about db download
db_download_list = list()
# dict that has rejected downloads and corresponding time when the rejection was done
db_rejected_download = dict()
# the time after which we can re-prompt for download
# TODO: to config
rejected_download_notify_threshold_sec = 10

def handle_db_empty(message):
    global db_download_list
    global db_rejected_download
    db = get_message_parm(message)
    logging.debug("Download list: " + repr(db_download_list))
    logging.debug("Rejected downloads: " + repr(db_rejected_download))
    if db in db_download_list:
        return
    if db_rejected_download.has_key(db):
        if (datetime.datetime.now() - db_rejected_download[db]).seconds < rejected_download_notify_threshold_sec:
            return
    denied_message = "Index data should be downloaded in order to browse this section.\n\n"
    message_box("AlgoSeek Drive: No Data" , denied_message)
    if prompt_box("Download data" , "Do you want to download index data for `" + str(db) + "`?"):
        db_download_list.append(db)
        index.download_index_db_start_thread(db)
        message_box("AlgoSeek Drive: No Data" , "Download started...\nIt may take up to 10 mins.")
    else:
        db_rejected_download[db] = datetime.datetime.now()
    return

def handle_mounted(message):
    drive = get_message_parm(message)
    #getting the mount point, open it 
    logging.debug("Openning Explorer drive " + drive)
    subprocess.Popen('explorer ' + drive) #Win-specific, TODO: move to other sys-dependent file

def handle_message(message):
    try:
        #notify_user(message)
        code = str(get_message_code(message))  
        if code == FAILED_ACCESS_DENIED:
            handle_access_denied(message)
        if code == LOCAL_DB_EMPTY:
            handle_db_empty(message)
        if code == MOUNTED:
            handle_mounted(message)
    except Exception as e:
        handle_exception(e)
