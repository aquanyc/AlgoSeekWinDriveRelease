"""
Helper functions
"""
import env
if env.is_windows():
    from ctypes import windll
    
from config import *


def get_drives():
    """returns list of currently used drives e.g. ['A', 'C', 'D', 'F', 'H']"""
    drives = []
    if env.is_windows() == False:
        return drives
    bitmask = windll.kernel32.GetLogicalDrives()
    for letter in string.uppercase:
        if bitmask & 1:
            drives.append(letter)
        bitmask >>= 1
    return drives

def _find_free_drive_letter():
    """finds a free drive letter. Returns None if no drives available"""
    for i in [chr(x) for x in range(ord('A'), ord('Z')+1)].reverse():
        if not (i in get_drives()):
            return i
    return None

def pick_drive():
    """picks a drive e.g. Z: to mount , raises LookupError if none available"""
    if env.is_windows() == False:
        if not os.path.exists(default_mount_dir):
            os.makedirs(default_mount_dir)
        return default_mount_dir #TODO: get from config
    
    letter = ""
    if not default_drive in get_drives():
        letter = default_drive 
    else:
        letter = _find_free_drive_letter()
    if not letter:
        raise LookupError("Cannot find a free drive letter to mount")
    return letter+":"    
