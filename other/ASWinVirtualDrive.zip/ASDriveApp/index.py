"""
Loads index cache database files
Platform: any
"""

import sys
import os
import logging
import traceback
import zipfile
import urllib
import string
import gzip
import urllib2
import shutil
import threading

from config import *
from errors import *

def check_index_db(path):
    """checks if database is valid"""
    #TODO: implement check if it is a valid db
    return True

def apply_index_db(path):
    """copies db to working directory unzipping it if needed"""
    src_file = None
    if str(path).endswith(".gz"):
        src_file = gzip.open(path, 'rb')
    elif str(path).endswith(".zip"):
        # this one is default for now. the other variants is left for compatibility with older versions and should be deleted
        zipfile.ZipFile(path).extractall(index_root)
        return
    else:
        src_file = open(path, 'rb')
    
    outpath = os.path.basename(path).replace(".gz" , "")
    outpath = index_root + "/" + outpath 
    f_out = open(outpath, "wb")    #TODO: handle exception when DB is opened by a service, make it more user-friendly
    shutil.copyfileobj(src_file, f_out)
    src_file.close()
    f_out.close()

def apply_index_db_from_url(url , overwrite=False):
    """copies db to working directory from the internet unzipping it if needed"""
    
    outpath = os.path.basename(url)
    if not overwrite and os.path.exists(outpath):
        return

    u = urllib2.urlopen(url)
    size_written = 0
    total_size = int(u.headers['content-length'])
    f_out = open(outpath, "wb")    
    
    chunksize = 1024*1024 # read in 1M chunks
    while 1: 
        data = u.read(chunksize)
        if len(data) == 0:
            break
        size_written += len(data)
        f_out.write(data)
        percent_downloaded = 100*size_written/total_size
        notify_user(str(percent_downloaded)+"% of index DB `" + outpath + "` downloaded")

    f_out.close()
    
    unzip = False
    if str(url).endswith(".gz") or str(url).endswith(".zip"):
        unzip = True
    
    if unzip:
        notify_user("Unpacking index DB `" + outpath + "` \nIt may take up to 10 minutes...")
        apply_index_db(outpath)
    notify_user("`" + outpath + "` applied. Corresponding AlgoSeek Drive directory is ready for browsing.")

def download_index_db(bucketname):
    #here we create a default
    notify_user("Downloading index data...")
    url = default_index_db_url_format.format(bucketname)
    apply_index_db_from_url(url , True)

def _download_index_db_routine (bucketname):
    try:
        download_index_db(bucketname)
    except Exception as err:
        handle_exception(err)
        notify_user("Failed downloading index database for " + bucketname)
        

def download_index_db_start_thread (bucketname):
    threading.Thread(target=_download_index_db_routine, args=(bucketname,)).start()
