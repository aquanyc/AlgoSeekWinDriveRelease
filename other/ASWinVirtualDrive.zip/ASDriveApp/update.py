"""module for self-update"""

import logging
import urllib2
import os, datetime, time
import env

#TODO: impl linux \ cross-platform version e.g. by downloading zip and install via pip
# maybe creating a linux install script will help

def _run_msi(package_file):
    #win-only
    if env.is_windows():
        import subprocess
        DETACHED_PROCESS = 0x00000008 # hides console window
        output = subprocess.check_output(["msiexec" , "/quiet" , "/l*v" , "install.log" , "/i" , os.path.abspath(package_file) ] , creationflags = DETACHED_PROCESS)
        logging.debug(output)
    else:
        logging.warning("Self-update not implemented for non-windows versions")

C_740 = None
if (sys.version_info > (3, 0)):
    C_740 = 0o740
else:
    C_740 = 0740

def _run_script(script_file):
    """runs installer script"""
    os.chmod(script_file , C_740)
    os.system(script_file)

def update():
    """Updates modules via msiexec, returns False if update is not needed"""

    logging.basicConfig(filename="autoupdate.log" , level=logging.DEBUG)

    skip = False
    #TODO: move to config
    #TODO: handle branches somehow. for now it updates from master
    if env.is_windows():
        download_url = "https://github.com/aquanyc/AlgoSeekWinDriveRelease/raw/master/Windows/updates/PythonModules.msi"
    else:
        download_url = "https://github.com/aquanyc/AlgoSeekWinDriveRelease/raw/master/other/linux_installer.sh"
    last_commit_url = "https://api.github.com/repos/aquanyc/AlgoSeekWinDriveRelease/commits/master" # url to get the last commit description from github

    file = '.\\PythonModules.msi'
    commit_file = '.\\commit.txt'

    logging.info("Starting update...")

    u = urllib2.urlopen(download_url)
    meta = u.info()
    
    if os.path.exists(file) == False:
        skip = False
        logging.debug("Local file is not present")
    else:
        # checking if update may be skipped
        logging.debug("URL Metadata: " + repr(meta.__dict__))
        
        # 1. last-modified
        if meta.getheaders("Last-Modified"):
            # CONVERTING HEADER TIME TO UTC TIMESTAMP 
            # ASSUMING 'Sun, 28 Jun 2015 06:30:17 GMT' FORMAT
            meta_modifiedtime = time.mktime(datetime.datetime.strptime( \
                        ''.join(meta.getheaders("Last-Modified")), "%a, %d %b %Y %X GMT").timetuple())
            logging.debug(url+" Last Modified: " + str(meta.getheaders("Last-Modified")) + " , " + str(meta_modifiedtime))
            local_modifiedtime = os.path.getmtime(file)
            logging.debug(file + " Last Modified: " + str(time.ctime(local_modifiedtime)) + " , " + str(local_modifiedtime))
            # check if local MSI file exists or there is a newer one on the server
            if os.path.getmtime(file) > meta_modifiedtime:
                logging.info("Server file timestamp is not newer than a local one")
                skip = True
        else:
            try:
                # compare local last commit data and git last commit data
                commit_data = urllib2.urlopen(last_commit_url).read()
                if os.path.exists(commit_file):
                    with open(commit_file, "r") as f:
                        local_commit_data = f.read()
                        if commit_data == local_commit_data:
                            logging.info("No updates detected in a repo, skipping")
                            skip = True
                with open(commit_file , "w") as f:
                    f.write(commit_data)
            except Exception as e:
                logging.warn("Failed to get commit data " + str(e))

    if not skip:
        logging.debug("Starting download")
        buffer = u.read()
        f = open(file, 'wb')
        f.write(buffer)
        f.close()
        logging.info("MSI file successfully updated , running...")
        _run_msi(file)
        return True

    return False
       

if __name__ == '__main__':
    # test
    logging.basicConfig(level=logging.DEBUG)
    update()
