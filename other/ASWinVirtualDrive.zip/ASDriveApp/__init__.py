import version
__version__ = version.get_version(pep440=False)
