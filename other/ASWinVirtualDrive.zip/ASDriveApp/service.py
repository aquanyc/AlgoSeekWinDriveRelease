# standard modules
import subprocess
from subprocess import STDOUT
import sys
import os
import shutil
import time
import exceptions
import logging
import traceback
import zipfile
import urllib
import string
import gzip
import urllib2

#local modules
from errors import *
from helper import *
from config import *
import env



# --------------- SERVICE CONTROL

def check_nssm():
    """checks if nssm.exe is available"""
    if env.is_windows() == False:
        return True # we emulate nssm on non-win systems, so it's always available
    return os.path.exists(nssm_path)

def call_nssm(args):
    """calls nssm by given arguments, returns resulting string as output. raises exception if errorcode != 0"""
    #TODO: implement non-windows version
    if env.is_windows() == False:
        return _emulate_nssm(args)
        
    logging.debug("Calling nssm " + repr(args))
    suinfo = subprocess.STARTUPINFO()
    suinfo.dwFlags |= subprocess.STARTF_USESHOWWINDOW 
    suinfo.wShowWindow = subprocess.SW_HIDE #hides console window
    p = subprocess.Popen(args, stdout=subprocess.PIPE , stderr=subprocess.STDOUT, universal_newlines=True, startupinfo=suinfo)
    output = str(p.communicate()[0])
    output = output.replace('\x00', '') #the dumb but efficient way to battle with weird mixed ascii\utf16 returns by nssm
    logging.debug("Nssm returned: " + output)
    if p.returncode:
        raise subprocess.CalledProcessError(p.returncode , args, output)
    return output


def read_status_file():
    """Reads status file data"""
    data = ""
    if os.path.exists(fs_status_path) == False:
        return ""
    with open(fs_status_path , "r") as f:
        data = f.read()
    return data

def check_status_timeout(timestamp):
    """checks if timeout passed since the timestamp"""
    return time.time() > timestamp + service_status_timeout

def get_status_file_message():
    """Reads status file data and parses a message from it"""
    data = read_status_file()
    if not data:
        return "No data available"
    #status file format: <TIMESTAMP> <MESSAGE>
    #e.g.: 34432323 Mounted X:
    timestamp = int(data.split(' ')[0])
    if check_status_timeout(timestamp):
        return "No data available - timeout"
    message = str(data).replace(str(timestamp)+" ", "")
    return message


def check_installed():
    nssm_check = [nssm_path , "status" , service_name]
    try:
        call_nssm(nssm_check)
        return True
    except subprocess.CalledProcessError as e:
        logging.info("Nssm detected service is not installed: " + str(e.__dict__))
        return False
    except Exception as e:
        handle_exception(e)

def check_running():
    """checks service is running"""
    #TODO: implement more smart check of FS actual state
    nssm_check = [nssm_path , "status" , service_name]
    if ("SERVICE_RUNNING" in call_nssm(nssm_check)):
        return True
    return False

def get_status():
    """gets simple printable status of service"""
    if check_installed() == False:
        return "Service not installed. Please restart the app."
    if check_running():
        return "Drive Connected (Service Running): \n" + get_status_file_message() 
    else:
        return "Drive Not Connected (Service Stopped): \n" + get_status_file_message() 

def set_mount_drive():
    """sets drive to mount in svc controls"""
    #TODO: implement setting mount drive via config file
    drive = pick_drive()
    logging.info("Setting drive letter to mount " + drive)
    nssm_command = [nssm_path , "set" , service_name, "AppEnvironmentExtra", "AS_DRIVE_MOUNTPOINT="+drive]
    res = call_nssm(nssm_command)
    return res

def install():
    """installs the service"""
    # install the service
    # throws The CalledProcessError with  return code in the returncode attribute and any output in the output attribute
    # in case of errors

    #TODO: rollback installation (remove service if anything goes wrong here)
    nssm_install = [nssm_path , "install" , service_name, python_path, "-m" , "ASVirtualDrive"] #TODO: add parms to ASVirtualDrive script __main__
    res = call_nssm(nssm_install)
    
    nssm_command = [nssm_path , "set" , service_name, "AppDirectory", os.path.abspath(install_dir)]
    res = call_nssm(nssm_command)
    
    nssm_command = [nssm_path , "set" , service_name, "Start", default_service_start_behaviour]
    res = call_nssm(nssm_command)

    nssm_command = [nssm_path , "set" , service_name, "DisplayName", service_display_name]
    res = call_nssm(nssm_command)
    
    nssm_command = [nssm_path , "set" , service_name, "Description", service_description]
    res = call_nssm(nssm_command)

    nssm_command = [nssm_path , "set" , service_name, "AppExit", "Default" , "Exit"] # can also be set to "Restart"
    res = call_nssm(nssm_command)

    nssm_command = [nssm_path , "set" , service_name, "AppThrottle", "0" ] # time to wait till restart (if "Restart" is set in previous call)
    res = call_nssm(nssm_command)

    nssm_command = [nssm_path , "set" , service_name, "AppStdout", os.path.join(os.path.abspath(install_dir),"drive_stdout.log")]
    res = call_nssm(nssm_command)

    nssm_command = [nssm_path , "set" , service_name, "AppStderr", os.path.join(os.path.abspath(install_dir),"drive_stderr.log")]
    res = call_nssm(nssm_command)

    #sets the drive to mount by picking automatically 
    set_mount_drive() #TODO: make it happen on every service start in case the drive letter is already used

    return 0

def uninstall():
    nssm_remove = [nssm_path , "remove" , service_name]
    call_nssm(nssm_remove)    

def start():
    nssm_start = [nssm_path , "start" , service_name]
    call_nssm(nssm_start)    

def stop():
    nssm_stop = [nssm_path , "stop" , service_name]
    call_nssm(nssm_stop) 

C_740 = None
if (sys.version_info > (3, 0)):
    C_740 = 0o740
else:
    C_740 = 0740

def _emulate_nssm(args):
    """emulates nssm on non-win systems"""
    #TODO: make smarter install via service and other linux functions
    exec_script_filename = "./algoseek_service.sh"
    svc_name = args[2] # TODO: use svc_name to identify the process
    if args[1] == "install":
        with open(exec_script_filename, "w") as f:
            f.write("#!/bin/bash\n")
            for arg in args[3:]:
                f.write('"'+arg+'" ')
        os.chmod(exec_script_filename, C_740)
    if args[1] == "set":
        #TODO: impl other options too
        if args[3] == "AppStdout":
            with open(exec_script_filename, "a") as f:
                f.write(' >> "' + args[4] + '"')
        if args[3] == "AppStderr":
            with open(exec_script_filename, "a") as f:
                f.write(' 2 >> "' + args[4]+ '"')
    if args[1] == "start":
        os.system(exec_script_filename + " &") #TODO: impl popen or something like that
    if args[1] == "stop":
        #TODO: kill by something smarter...
        os.system("killall `ps -aux | grep " + exec_script_filename + " | grep -v grep | awk '{ print $1 }'`")
    if args[1] == "status":
        if os.path.exists(exec_script_filename) == False:
            raise subprocess.CalledProcessError(0,"")
        if os.system("ps -aux | grep " + exec_script_filename+ " | grep -v grep") == 0:
            return "SERVICE_RUNNING" #TODO: implement popen check or something like that
        else:
            return "SERVICE_STOPPED"
