# local modules
# windows-specific
from tray import SysTrayIcon
import notify

from action import *
from service import *
from index import *
from messages import *
from config import *
from interactive import *

import logging

# Tk GUI (incl in Python) for extra dialogs
import Tkinter
import tkFileDialog



# --------------- HELPER FUNCTIONS

def configure_logs():
    
    # Remove all previous handlers associated with the root logger object.
    for handler in logging.root.handlers[:]:
        logging.root.removeHandler(handler)

    logFormatter = logging.Formatter("%(asctime)s [%(threadName)-12.12s] [%(levelname)-5.5s]  %(message)s")
    rootLogger = logging.getLogger()
    rootLogger.setLevel(logging.DEBUG)

    fileHandler = logging.FileHandler(install_dir+"\\app.log")
    fileHandler.setFormatter(logFormatter)
    rootLogger.addHandler(fileHandler)

    consoleHandler = logging.StreamHandler()
    consoleHandler.setFormatter(logFormatter)
    rootLogger.addHandler(consoleHandler)

def handle_driver_message(thread, conn, ident, message):
    #TODO: implement logic: how to react to each message
    handle_message(str(message.data))

def start_menu():

    configure_logs()

    Tkinter.Tk().withdraw() # Close the root window    

    # Menu:
    # Connect (starts the service)
    # Disconnect (stops the service)
    # Apply AlgoSeek key - Get access to paid data (apply new aws config)
    # Support > 1. Contact 2. Gather Troubleshooting Data
    # Extra > 1. Update Software (download .py, restart), 2. Select Drive Letter, 3. Connect on start
    # On exit: disconnect

    menu_options = (('Status', None, action_status),
                    ('Connect', None , action_connect),
                    ('Apply AlgoSeek Key', None, action_apply_key_dialog),
                    ('Support', None, (('Contact Support', None, action_show_contacts),
                                       ('Gather Troubleshooting Info...', None, action_send_troubleshooting_info),
                                           )),
                    ('Extra', None,   (('Update Software...', None, action_update),
                                       #('Load Index DB...', None, action_update_index),
                                       ('Uninstall Filesystem Service', None, action_uninstall_service),
                                           ))
                   )
    tray_window = SysTrayIcon(main_icon, hover_text, menu_options, on_quit=action_on_quit, default_menu_index=0)
    MessageLoop.set_defult_recv(handle_driver_message)
    set_default_notification_window(tray_window)
    
    try:
        if check_nssm() == False:
            notify_user("Fatal Error: Could not find nssm.exe. Please reinstall the software!")
        else:
            if (not check_installed()): 
                install()
                notify_user("Virtual Drive Service installed!")
            action_connect(tray_window)
            upd_menu(tray_window)
            #TODO: connect here, disconnect on quit
    except Exception as e:
        notify_user("Installation failure!")
        handle_exception(e)
    
    tray_window.start()
