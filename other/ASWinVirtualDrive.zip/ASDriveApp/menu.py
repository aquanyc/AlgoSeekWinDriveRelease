# local modules
# windows-specific

import notify

from action import *
from service import *
from index import *
from messages import *
from config import *
from interactive import *
import env

import logging
import time





# --------------- HELPER FUNCTIONS

def configure_logs():
    
    # Remove all previous handlers associated with the root logger object.
    for handler in logging.root.handlers[:]:
        logging.root.removeHandler(handler)

    logFormatter = logging.Formatter("%(asctime)s [%(threadName)-12.12s] [%(levelname)-5.5s]  %(message)s")
    rootLogger = logging.getLogger()
    rootLogger.setLevel(logging.DEBUG) #TODO: get gui logs from config

    fileHandler = logging.FileHandler(install_dir+"/app.log")
    fileHandler.setFormatter(logFormatter)
    rootLogger.addHandler(fileHandler)

    #TODO: set options to write log to console
    #consoleHandler = logging.StreamHandler()
    #consoleHandler.setFormatter(logFormatter)
    #rootLogger.addHandler(consoleHandler)

def handle_driver_message(thread, conn, ident, message):
    #TODO: implement logic: how to react to each message
    handle_message(str(message.data))

def _set_background():
    """sets process to background mode detaching from terminal (linux only)"""
    if env.is_windows():
        logging.warning("Background mode is not available in Windows")
        return
    pid = os.fork()
    if pid == 0:
        # Child
        os.setsid()  # This creates a new session
        logging.debug("Moved to background mode")
    else:
        # Parent
        exit()

def start_menu():

    configure_logs()

    tray_window = None
    # configure GUI menu
    if env.is_gui():
        # Tk GUI (incl in Python) for extra dialogs
        import Tkinter
        from tray import SysTrayIcon
        
        Tkinter.Tk().withdraw() # Close the root window    

        # Menu:
        # Connect (starts the service)
        # Disconnect (stops the service)
        # Apply AlgoSeek key - Get access to paid data (apply new aws config)
        # Support > 1. Contact 2. Gather Troubleshooting Data
        # Extra > 1. Update Software (download .py, restart), 2. Select Drive Letter, 3. Connect on start
        # On exit: disconnect

        menu_options = (('Status', None, action_status),
                        ('Connect', None , action_connect),
                        ('Apply AlgoSeek Key', None, action_apply_key_dialog),
                        ('Support', None, (('Contact Support', None, action_show_contacts),
                                           ('Gather Troubleshooting Info...', None, action_send_troubleshooting_info),
                                               )),
                        ('Extra', None,   (('Update Software...', None, action_update),
                                           #('Load Index DB...', None, action_update_index),
                                           ('Uninstall Filesystem Service...', None, action_uninstall_service),
                                           ('Toggle Compression...', None, action_toggle_uncompression),
                                           ('Toggle Verbose Logging...', None, action_toggle_logging),
                                               ))
                       )
        tray_window = SysTrayIcon(main_icon, hover_text, menu_options, on_quit=action_on_quit, default_menu_index=0)
        set_default_notification_window(tray_window)

    if background_mode:
            _set_background()

    # setting message handlers
    MessageLoop.set_defult_recv(handle_driver_message)

    # connecting
    try:
        if check_nssm() == False:
            notify_user("Fatal Error: Could not find nssm.exe. Please reinstall the software!")
        else:
            if (not check_installed()): 
                install()
                notify_user("Virtual Drive Service installed!")
            action_connect(tray_window)
            upd_menu(tray_window)
            #TODO: connect here, disconnect on quit
    except Exception as e:
        notify_user("Installation failure!")
        handle_exception(e)

    if env.is_gui():
        tray_window.start()
    else:
        # go to sleep
        if background_mode and check_running():
            notify_user("AlgoSeekDrive runs in background mode. Press ENTER to continue.")
        while check_running():
            time.sleep(100)
        notify_user("AlgoSeekDrive stopped.")
        logging.info("Service runs no more, exiting.")
        
