# local modules
# windows-specific

import notify

from action import *
from service import *
from index import *
from messages import *
from config import *
from interactive import *
import env

import logging
import time





# --------------- HELPER FUNCTIONS

def configure_logs():
    
    # Remove all previous handlers associated with the root logger object.
    for handler in logging.root.handlers[:]:
        logging.root.removeHandler(handler)

    level = get_config('level' , 'logging', logging.INFO)
    max_bytes = get_config('max_size_mb' , 'logging', 10*1024*1024)

    logFormatter = logging.Formatter("%(asctime)s [%(threadName)-12.12s] [%(levelname)-5.5s]  %(message)s")
    rootLogger = logging.getLogger()
    rootLogger.setLevel(int(level)) 
    filehandler = logging.handlers.RotatingFileHandler( install_dir+"/app.log", "a+", max_bytes, 1, None, True )
    filehandler.setFormatter(logFormatter)
    rootLogger.addHandler(filehandler)

    #TODO: have option to write log to console
    #consoleHandler = logging.StreamHandler()
    #consoleHandler.setFormatter(logFormatter)
    #rootLogger.addHandler(consoleHandler)

def handle_driver_message(thread, conn, ident, message):
    #TODO: implement logic: how to react to each message
    handle_message(str(message.data))

def _set_background():
    """sets process to background mode detaching from terminal (linux only)"""
    if env.is_windows():
        logging.warning("Background mode is not available in Windows")
        return
    pid = os.fork()
    if pid == 0:
        # Child
        os.setsid()  # This creates a new session
        logging.debug("Moved to background mode")
    else:
        # Parent
        exit()

def start_menu():
    """
        default entry point (called from __main__.py)
        For GUI mode and Windows platform,
        inits tray icon window with menu populated by actions from action.py
    """

    import version
    __version__ = version.get_version(pep440=False)

    configure_logs()

    tray_window = None
    # configure GUI menu, currently Windows-only
    if env.is_gui() and env.is_windows():
        # Tk GUI (incl in Python) for extra dialogs
        import Tkinter
        # local module implementing tray Windows icon 
        from tray import SysTrayIcon
        
        Tkinter.Tk().withdraw() # Close the root window    

        #init menu with actions
        menu_options = (('Status', None, action_status),
                        ('Connect', None , action_connect),
                        ('Apply AlgoSeek Key', None, action_apply_key_dialog),
                        ('Support', None, (('Contact Support...', None, action_show_contacts),
                                           ('Gather Troubleshooting Info...', None, action_send_troubleshooting_info),
                                               )),
                        ('Extra', None,   (('Update Software...', None, action_update),
                                           #('Load Index DB...', None, action_update_index),
                                           ('Uninstall Filesystem Service...', None, action_uninstall_service),
                                           ('Toggle Compression...', None, action_toggle_uncompression),
                                           ('Toggle Verbose Logging...', None, action_toggle_logging),
                                               ))
                       )
        # init tray window
        tray_window = SysTrayIcon(main_icon, hover_text, menu_options, on_quit=action_on_quit, default_menu_index=0)
        set_default_notification_window(tray_window)

    if background_mode:
            _set_background()

    # setting message handlers
    #TODO: !!! this one is not set when connect action is called from the console!
    MessageLoop.set_defult_recv(handle_driver_message) 

    # connecting to the driver
    try:
        # nssm.exe is prereq for Windows
        if check_nssm() == False:
            notify_user("Fatal Error: Could not find nssm.exe. Please reinstall the software!")
        else:
            # install the driver if it is not installed
            if (not check_installed()): 
                install()
                notify_user("Virtual Drive Service installed!")
            # start the driver 
            action_connect(tray_window)
            # update menu options
            upd_menu(tray_window)
    except Exception as e:
        notify_user("Installation failure!")
        handle_exception(e)

    #go to endless loop 
    if env.is_gui():
        # while user doesn't quit (in GUI mode)
        tray_window.start()
    else:
        # or driver running (in CLI mode)
        # go to sleep
        if background_mode and check_running():
            notify_user("AlgoSeek Data Drive runs in background mode. Press ENTER to continue.")
        while check_running():
            time.sleep(20)
        notify_user("AlgoSeek Data Drive stopped. Shutting down notification service...")
        logging.info("Service runs no more, exiting.")
        sys.exit(0)

if __name__ == '__main__':
    # for debugging reasons
    start_menu()
        
