# local modules
from tray import SysTrayIcon
import notify

# windows-specific
from ctypes import windll

# standard modules
import subprocess
from subprocess import STDOUT
import pip
import sys
import os
import shutil
import time
import exceptions
import logging
import traceback
import zipfile
import urllib
import string
import gzip

# Tk GUI (incl in Python) for extra dialogs
import Tkinter
import tkFileDialog


#some installation dependent path variables
install_dir = "."
nssm_path = install_dir + "\\nssm.exe" # a tool to install and control services see https://nssm.cc/
key_path = install_dir+"\\key.cfg"


#fs status file
fs_status_path = install_dir+"\\fs.status"
service_status_timeout = 600 # 10 mins

#service settings
service_name = "AlgoSeekDriveSvc"
service_display_name = "AlgoSeek Windows Virtual Drive service"
service_description = "Represents AWS S3 index data and implements a filesystem interface for it."
python_path = sys.executable
default_service_start_behaviour="SERVICE_AUTO_START" #SERVICE_DEMAND_START
default_drive="S"

#Tray text and icons
hover_text = "AlgoSeek Virtual Drive"
main_icon = "algoseek.ico"


#global tray Window object
tray_window = None


# --------------- HELPER FUNCTIONS

def get_drives():
    """returns list of currently used drives e.g. ['A', 'C', 'D', 'F', 'H']"""
    drives = []
    bitmask = windll.kernel32.GetLogicalDrives()
    for letter in string.uppercase:
        if bitmask & 1:
            drives.append(letter)
        bitmask >>= 1
    return drives

def find_free_drive_letter():
    """finds a free drive letter. Returns None if no drives available"""
    for i in [chr(x) for x in range(ord('A'), ord('Z')+1)].reverse():
        if not (i in get_drives()):
            return i
    return None

def pick_drive():
    """picks a drive e.g. Z: to mount , raises LookupError if none available"""
    letter = ""
    if not default_drive in get_drives():
        letter = default_drive 
    else:
        letter = find_free_drive_letter()
    if not letter:
        raise LookupError("Cannot find a free drive letter to mount")
    return letter+":"    


def configure_logs():
    
    # Remove all previous handlers associated with the root logger object.
    for handler in logging.root.handlers[:]:
        logging.root.removeHandler(handler)

    logFormatter = logging.Formatter("%(asctime)s [%(threadName)-12.12s] [%(levelname)-5.5s]  %(message)s")
    rootLogger = logging.getLogger()
    rootLogger.setLevel(logging.DEBUG)

    fileHandler = logging.FileHandler(install_dir+"\\app.log")
    fileHandler.setFormatter(logFormatter)
    rootLogger.addHandler(fileHandler)

    consoleHandler = logging.StreamHandler()
    consoleHandler.setFormatter(logFormatter)
    rootLogger.addHandler(consoleHandler)

def notify_user(msg , title="AlgoSeek Virtual Drive"):
    logging.debug("Notifying user " + msg)
    if tray_window:
        try:
            notify.balloon_tip(title , msg , tray_window.hwnd)
            return
        except Exception as Ex:
            logging.warn("Failed to show balloon tip! " + str (Ex))
    else:
        logging.warn("Tray window is not set, using Message Boxes to notify user")
    # fallback to plain old message box
    notify.message_box(title , msg)

def handle_exception(err):
    error_msg = str(err)
    if err.__dict__.has_key('output'):
        error_msg = error_msg + "\n" + str(err.__dict__['output'])
    notify_user( error_msg , "Failure!")
    logging.error("EXCEPTION " + str(err))
    logging.error(str(err.__dict__))
    logging.error(traceback.format_exc())

# --------------- SERVICE CONTROL

def check_nssm():
    """checks if nssm.exe is available"""
    return os.path.exists(nssm_path)

def call_nssm(args):
    """calls nssm by given arguments, returns resulting string as output. raises exception if errorcode != 0"""
    logging.debug("Calling nssm " + repr(args))
    p = subprocess.Popen(args, stdout=subprocess.PIPE , stderr=subprocess.STDOUT, universal_newlines=True )
    output = str(p.communicate()[0])
    output = output.replace('\x00', '') #the dumb but efficient way to battle with weird mixed ascii\utf16 returns by nssm
    logging.debug("Nssm returned: " + output)
    if p.returncode:
        raise subprocess.CalledProcessError(p.returncode , args, output)
    return output


def read_status_file():
    """Reads status file data"""
    data = ""
    if os.path.exists(fs_status_path) == False:
        return ""
    with open(fs_status_path , "r") as f:
        data = f.read()
    return data

def check_status_timeout(timestamp):
    """checks if timeout passed since the timestamp"""
    return time.time() > timestamp + service_status_timeout

def get_status_file_message():
    """Reads status file data and parses a message from it"""
    data = read_status_file()
    if not data:
        return "No data available"
    #status file format: <TIMESTAMP> <MESSAGE>
    #e.g.: 34432323 Mounted X:
    timestamp = int(data.split(' ')[0])
    if check_status_timeout(timestamp):
        return "No data available - timeout"
    message = str(data).replace(str(timestamp)+" ", "")
    return message


def check_installed():
    nssm_check = [nssm_path , "status" , service_name]
    if (subprocess.call(nssm_check) == 0):
        return True
    return False

def check_running():
    """checks service is running"""
    #TODO: implement more smart check of FS actual state
    nssm_check = [nssm_path , "status" , service_name]
    if ("SERVICE_RUNNING" in call_nssm(nssm_check)):
        return True
    return False

def get_status():
    """gets simple printable status of service"""
    if check_installed() == False:
        return "Service not installed. Please restart the app."
    if check_running():
        return "Drive Connected (Service Running): \n" + get_status_file_message() 
    else:
        return "Drive Not Connected (Service Stopped): \n" + get_status_file_message() 

def set_mount_drive():
    """sets drive to mount in svc controls"""
    drive = pick_drive()
    logging.info("Setting drive letter to mount " + drive)
    nssm_command = [nssm_path , "set" , service_name, "AppEnvironmentExtra", "AS_DRIVE_MOUNTPOINT="+drive]
    res = call_nssm(nssm_command)
    return res

def install():
    """installs the service"""
    # install the service
    # throws The CalledProcessError with  return code in the returncode attribute and any output in the output attribute
    # in case of errors

    #TODO: rollback installation (remove service if anything goes wrong here)
    nssm_install = [nssm_path , "install" , service_name, python_path, "-m" , "ASVirtualDrive"] #TODO: add parms to ASVirtualDrive script __main__
    res = call_nssm(nssm_install)
    
    nssm_command = [nssm_path , "set" , service_name, "AppDirectory", os.path.abspath(install_dir)]
    res = call_nssm(nssm_command)
    
    nssm_command = [nssm_path , "set" , service_name, "Start", default_service_start_behaviour]
    res = call_nssm(nssm_command)

    nssm_command = [nssm_path , "set" , service_name, "DisplayName", service_display_name]
    res = call_nssm(nssm_command)
    
    nssm_command = [nssm_path , "set" , service_name, "Description", service_description]
    res = call_nssm(nssm_command)

    nssm_command = [nssm_path , "set" , service_name, "AppExit", "Default" , "Exit"] # can also be set to "Restart"
    res = call_nssm(nssm_command)

    nssm_command = [nssm_path , "set" , service_name, "AppThrottle", "0" ] # time to wait till restart (if "Restart" is set in previous call)
    res = call_nssm(nssm_command)

    nssm_command = [nssm_path , "set" , service_name, "AppStdout", os.path.abspath(install_dir)+"\\svc_stdout.log"]
    res = call_nssm(nssm_command)

    nssm_command = [nssm_path , "set" , service_name, "AppStderr", os.path.abspath(install_dir)+"\\svc_stderr.log"]
    res = call_nssm(nssm_command)

    #sets the drive to mount by picking automatically 
    set_mount_drive() #TODO: make it happen on every service start in case the drive letter is already used

    return 0

def uninstall():
    nssm_remove = [nssm_path , "remove" , service_name]
    call_nssm(nssm_remove)    

def start():
    nssm_start = [nssm_path , "start" , service_name]
    call_nssm(nssm_start)    

def stop():
    nssm_stop = [nssm_path , "stop" , service_name]
    call_nssm(nssm_stop) 

def apply_key(path):
    """Copy config with keys to the local dir so the filesystem code will apply it on the next run"""
    #backup existing key
    if (os.path.exists(key_path)):
        shutil.copyfile(key_path, key_path+str(int(time.time()))+".backup")
    shutil.copyfile(path, key_path)
    return True

def check_key(path):
    """checks if key on path is valid"""
    #TODO: implement check if it is a valid python file
    return True

def check_index_db(path):
    """checks if database is valid"""
    #TODO: implement check if it is a valid sqlite db
    return True

def apply_index_db(path):
    """copies db to working directory unzipping it if needed"""
    src_file = None
    if str(path).endswith(".gz"):
        src_file = gzip.open(path, 'rb')
    else:
        src_file = open(path, 'rb')
    
    outpath = os.path.basename(path).replace(".gz" , "")
    f_out = open(outpath, "wb")    #TODO: handle exception when DB is opened by a service, make it more user-friendly
    shutil.copyfileobj(src_file, f_out)


def upd_menu(tray):
    if check_nssm() == False:
        return

    action = action_connect
    action_text = "Connect"
    if check_running():
        action = action_disconnect
        action_text = "Disconnect"

    # update menu list with a new action
    tray.replace_action(action_connect , action, action_text)
    tray.replace_action(action_disconnect , action, action_text)
    

### --------------- MENU HANDLERS 

def action_apply_key_dialog(wnd):
    try:
        path = tkFileDialog.askopenfilename()
        if not path:
            return 
        if os.path.exists(path):
            if check_key(path):
                apply_key(path)
                notify_user("New key applied. Please reconnect to access your data.")
            else:
                notify_user("Invalid key")
    except Exception as err:
        handle_exception(err);
        
def action_update_index(wnd):
    try:
        path = tkFileDialog.askopenfilename()
        if not path:
            return 
        if os.path.exists(path):
            if check_index_db(path):
                notify_user("Applying index database file. It may take up to ten minutes. You will be notified when index is ready.")
                apply_index_db(path)
                notify_user("New db applied. Please reconnect to access your data.")
            else:
                notify_user("Invalid db")
    except Exception as err:
        handle_exception(err);

def action_connect(wnd):
    try:
        if check_running():
            notify_user("Already connected");
        else:
            start()
            time.sleep(5)
            if check_running():
                notify_user("Connected!");
                upd_menu(tray_window)
                status = str(get_status_file_message()).lower() # status should be in form "mounted x: blah-blah"
                if "mounted " in status:
                    #getting the mount point, open it 
                    drive = status.replace("mounted " , "").strip(" ").split(" ")[0]
                    logging.debug("Openning Explorer drive " + drive)
                    subprocess.Popen('explorer ' + drive)
            else:
                notify_user("Failed to connect!\n" + get_status());
    except Exception as err:
        handle_exception(err);



def action_disconnect(wnd):
    try:
        if check_running() == False:
            notify_user("Already disconnected");
        else:
            stop()
            time.sleep(2)
            if check_running():
                notify_user("Could not disconnect!");
            else:
                notify_user("Disconnected!");
        upd_menu(tray_window)
    except Exception as err:
        handle_exception(err)

def action_show_contacts(wnd):
    try:
        notify_user("For support proceed to AlgoSeek.com"); #TODO: set some simple link here
    except Exception as err:
        handle_exception(err)

def action_options(wnd):
    try:
        notify_user("No options yet...");
    except Exception as err:
        handle_exception(err)
    
def action_send_troubleshooting_info(wnd):
    try:
        #TODO: gather all logs we have. save to zip 
        archive_path = os.path.abspath(install_dir)+"\\SendMe.zip"
        zf = zipfile.ZipFile(archive_path, mode='w')
        logfiles = [f for f in os.listdir(install_dir) if str(f).endswith(".log")]
        for file in logfiles:
            zf.write(file)
        zf.close()
        subprocess.Popen(r'explorer /select,"'+archive_path+'"')
        notify_user("Info gathered at " + archive_path + "\nNow you may send it to AlgoSeek support!");
    except Exception as err:
        handle_exception(err)

def action_update(wnd):
    try:
        import update
        if update.update():
            notify_user("Update installed. Restart the app to apply them.")
        else:
            notify_user("Already up-to-date. No update required.")
    except Exception as err:
        handle_exception(err)

def action_on_quit(wnd):
    try:
        notify_user("Status:" + get_status() + "\nDisconnecting the drive.\nRestart the app so the tray icon appear again. See you later!")
        action_disconnect(wnd)
    except Exception as err:
        handle_exception(err)

def action_status(wnd):
    try:
        notify_user("Status:" + get_status() + "\nRight click on tray icon for more options")
        upd_menu(tray_window)
    except Exception as err:
        handle_exception(err)

def action_uninstall_service(wnd):
    try:
        uninstall()
        notify_user("Uninstall complete! Restart the app to reinstall the service. Use control panel to uninstall the app completely.")
    except Exception as err:
        handle_exception(err)

# ---------------------- MAIN FUNCTION

def start_menu():

    configure_logs()

    Tkinter.Tk().withdraw() # Close the root window    

    # Menu:
    # Connect (starts the service)
    # Disconnect (stops the service)
    # Apply AlgoSeek key - Get access to paid data (apply new aws config)
    # Support > 1. Contact 2. Gather Troubleshooting Data
    # Extra > 1. Update Software (download .py, restart), 2. Select Drive Letter, 3. Connect on start
    # On exit: disconnect

    menu_options = (('Status', None, action_status),
                    ('Connect', None , action_connect),
                    ('Apply AlgoSeek Key', None, action_apply_key_dialog),
                    ('Support', None, (('Contact Support', None, action_show_contacts),
                                       ('Gather Troubleshooting Info...', None, action_send_troubleshooting_info),
                                           )),
                    ('Extra', None,   (('Update Software...', None, action_update),
                                       ('Load Index DB...', None, action_update_index),
                                       ('Uninstall Filesystem Service', None, action_uninstall_service),
                                           ))
                   )
    global tray_window
    tray_window = SysTrayIcon(main_icon, hover_text, menu_options, on_quit=action_on_quit, default_menu_index=0)
    
    try:
        if check_nssm() == False:
            notify_user("Fatal Error: Could not find nssm.exe. Please reinstall the software!")
        else:
            if (not check_installed()): 
                install()
                notify_user("Virtual Drive Service installed!")
            upd_menu(tray_window)
            #TODO: connect here, disconnect on quit
    except Exception as e:
        notify_user("Installation failure!")
        handle_exception(e)
    
    tray_window.start()
