"""
Actions to do on user interaction
Platform: any
"""

import logging
import traceback

import notify

#global tray Window object
tray_window = None


def set_default_notification_window(wnd):
    global tray_window
    tray_window = wnd

def handle_exception(err):
    error_msg = str(err)
    if err.__dict__.has_key('output'):
        error_msg = error_msg + "\n" + str(err.__dict__['output'])
    notify_user( error_msg , "Failure!")
    logging.error("EXCEPTION " + str(err))
    logging.error(str(err.__dict__))
    logging.error(traceback.format_exc())

#TODO: move the notification code somewhere else e.g. to 'notify' module
def notify_user(msg , title="AlgoSeek Virtual Drive"):
    logging.debug("Notifying user " + msg)
    if tray_window:
        try:
            notify.balloon_tip(title , msg , tray_window.hwnd)
            return
        except Exception as Ex:
            logging.warn("Failed to show balloon tip! " + str (Ex))
    else:
        logging.warn("Tray window is not set, using Message Boxes to notify user")
    # fallback to plain old message box
    notify.message_box(title , msg)
