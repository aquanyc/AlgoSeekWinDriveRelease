import os
import platform
import sys


def is_windows():
    """checks if we run on windows"""
    return sys.platform.startswith('win')

def is_linux():
    """checks if we run on linux"""
    return sys.platform == "linux" or sys.platform == "linux2"

def is_mac():
    """checks if platform is Mac OS"""
    return platform == "darwin"

def is_gui():
    """
        Checks if we run in gui or console mode
        The app code should choose how to interact with
        user based on the return of is_gui() function
    """
    return is_windows()
