import os
import platform
import sys


def is_windows():
    return sys.platform.startswith('win')

def is_linux():
    return sys.platform == "linux" or sys.platform == "linux2"

def is_mac():
    return platform == "darwin"

def is_gui():
    """checks if we run in gui or console mode"""
    return is_windows()
