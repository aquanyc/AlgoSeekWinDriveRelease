"""
Actions to do on user interaction
This file is an ALTARNATIVE entry-point to serve calls from non-gui env 
Platform: any
"""

# standard modules
import subprocess
from subprocess import STDOUT
import pip
import sys
import os
import shutil
import time
import exceptions
import logging
import traceback
import zipfile
import urllib
import string
import gzip
import urllib2

from errors import *
from service import *
from helper import *
from index import *
from key import *
from config import *
from messages import *
import env

#TODO: move away from globals
message_loop = None

def upd_menu(tray):
    if check_nssm() == False:
        return
    if not tray:
        return

    action = action_connect
    action_text = "Connect"
    if check_running():
        action = action_disconnect
        action_text = "Disconnect"

    # update menu list with a new action
    tray.replace_action(action_connect , action, action_text)
    tray.replace_action(action_disconnect , action, action_text)
    

### --------------- MENU ACTIONS

#auxillary var to stop openning file dialog if it is already opened (as it causes deadlocks)
file_dialog_on = False

def action_apply_key_dialog(wnd):
    """On Windows, starts dialog to select key file.\nOn other systems, shows a help message how to apply key file manually."""
    global file_dialog_on
    if file_dialog_on == True:
        return
    try:
        if env.is_gui():
            import tkFileDialog
            file_dialog_on = True
            path = tkFileDialog.askopenfilename()
            if not path:
                return 
            if os.path.exists(path):
                if check_key(path):
                    apply_key(path)
                    notify_user("New key applied. Please reconnect to access your data.")
                else:
                    notify_user("Invalid key")
        else:
            notify_user("To apply key file, copy it to the local dir e.g. \ncp key.cfg " + os.getcwd()+"\nRestart AlgoSeekDrive to apply the setting.")
    except Exception as err:
        handle_exception(err);
    finally:
        file_dialog_on = False
        
def action_connect(wnd):
    """Runs the driver to connect (mount) filesystem."""
    global message_loop
    try:
        if check_running():
            notify_user("Already connected");
            if not message_loop:
                message_loop = MessageLoop.create_default_loop()
                message_loop.start()
        else:
            start()
            time.sleep(2)
            if check_running():
                notify_user("Connected!");
                message_loop = MessageLoop.create_default_loop()
                message_loop.start()
                upd_menu(wnd)
            else:
                notify_user("Failed to connect!\n" + get_status());
    except Exception as err:
        handle_exception(err);



def action_disconnect(wnd):
    """Stops the running driver unmounting filesystem."""
    try:
        if check_running() == False:
            notify_user("Already disconnected");
        else:
            global message_loop
            if message_loop:
                message_loop.end()
            stop()
            time.sleep(2)
            if check_running():
                notify_user("Could not disconnect!");
            else:
                notify_user("Disconnected!");
        upd_menu(wnd)
    except Exception as err:
        handle_exception(err)

def action_show_contacts(wnd):
    """Shows how to contact with support team."""
    try:
        notify_user("For support proceed to AlgoSeek.com");
        #TODO: set some simple link here
        #TODO: move the message to cfg
    except Exception as err:
        handle_exception(err)

    
def action_send_troubleshooting_info(wnd):
    """Gathers all log files available and saves to zip file."""
    try:
        archive_path = os.path.abspath(install_dir)+"\\SendMe.zip"
        zf = zipfile.ZipFile(archive_path, mode='w')
        logfiles = [f for f in os.listdir(install_dir) if str(f).endswith(".log")]
        for file in logfiles:
            zf.write(file)
        zf.close()
        if env.is_windows():
            subprocess.Popen(r'explorer /select,"'+archive_path+'"')
        notify_user("Info gathered at " + archive_path + "\nNow you may send it to AlgoSeek support!");
    except Exception as err:
        handle_exception(err)

def action_update(wnd):
    """Runs software online update."""
    try:
        import update
        if update.update():
            notify_user("Update installed. Restart the app to apply them.")
        else:
            notify_user("Already up-to-date. No update required.")
    except Exception as err:
        handle_exception(err)

def action_on_quit(wnd):
    """Same as `disconnect`."""
    try:
        notify_user("Status:" + get_status() + "\nDisconnecting the drive.\nRestart the app so the tray icon appear again. See you later!")
        action_disconnect(wnd)
    except Exception as err:
        handle_exception(err)

def action_status(wnd):
    """Shows current driver status."""
    try:
        notify_user("Status:" + get_status() + "\nRight click on tray icon for more options")
        upd_menu(wnd)
    except Exception as err:
        handle_exception(err)

def action_uninstall_service(wnd):
    """Uninstalls driver from the system."""
    try:
        uninstall()
        notify_user("Uninstall complete! Restart the app to reinstall the service. Use control panel to uninstall the app completely.")
    except Exception as err:
        handle_exception(err)

def action_toggle_uncompression(wnd):
    """Toggles automatic on-fly unzip of csv data inside the mounted drive.\nData is kept compressed in online storage. Toggle automatic unzip off to increase performance."""
    try:
        if get_config("uncompression") == "off":
            set_config("uncompression" , "on")
            notify_user("Virtual Drive data files will appear uncompressed.\nRestart AlgoSeek Drive to apply the setting.")
        else:
            set_config("uncompression" , "off")
            notify_user("Virtual Drive data files will appear in original .gz compressed format.\nRestart AlgoSeek Drive to apply the setting.")
    except Exception as err:
        handle_exception(err)

def action_toggle_logging(wnd):
    """Toggles verbose logging."""
    try:
        if get_config("level", "logging") == "20":
            set_config("level", "10" , "logging")
            notify_user("Virtual Drive verbose logging on.\nRestart AlgoSeek Drive to apply the setting.")
        else:
            set_config("level", "20" , "logging")
            notify_user("Virtual Drive verbose logging off.\nRestart AlgoSeek Drive to apply the setting.")
    except Exception as err:
        handle_exception(err)

# ------------------ ENTRY POINT:

def get_action_help():
    current_module = sys.modules[__name__]
    func_list = dir(current_module)
    msg = "Specify an action to run as a cmd line paramter.\nExample:\n{0} --toggle_logging\nAction list:\n\n".format( " ".join(sys.argv[:]) )
    for func in func_list:
        if str(func).startswith("action_"):
            msg += "--" + str(func).replace("action_", "" , 1)
            hlp = str(getattr(current_module, str(func)).__doc__)
            msg += "\n\n"+hlp+"\n\n"
            #TODO: add docs to every function
    return msg

def handle_action():
    """calls action directly that is specified by a command line"""
    if len(sys.argv) < 2:
        notify_user(get_action_help())
        return
    action = sys.argv[1]
    if action.startswith("--"):
        action=action[2:]
    funcname = "action_"+action
    current_module = sys.modules[__name__]
    method_to_call = getattr(current_module, funcname)
    method_to_call(None)

if __name__ == '__main__':
    handle_action()


