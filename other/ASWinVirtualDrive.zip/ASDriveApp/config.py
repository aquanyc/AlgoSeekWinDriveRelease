#TODO: implement data loading from config
#TODO: make it more explicit that these options came from config

import sys
import os

#some installation dependent path variables
install_dir = "."
nssm_path = install_dir + "\\nssm.exe" # a tool to install and control services see https://nssm.cc/
key_path = install_dir+"\\key.cfg"
default_index_db_url = "http://as-test-public-bucket.s3.amazonaws.com/us-equity-taq.zip"
default_index_db_url_format = "http://as-test-public-bucket.s3.amazonaws.com/{0}.zip"
index_root=install_dir+"\\index"

#fs status file
fs_status_path = install_dir+"\\fs.status"
service_status_timeout = 600 # 10 mins

#service settings
service_name = "AlgoSeekDriveSvc"
service_display_name = "AlgoSeek Windows Virtual Drive service"
service_description = "Represents AWS S3 index data and implements a filesystem interface for it."
python_path = sys.executable
default_service_start_behaviour="SERVICE_AUTO_START" #SERVICE_DEMAND_START
default_drive="S"

#Tray text and icons
hover_text = "AlgoSeek Virtual Drive"
main_icon = "algoseek.ico"

