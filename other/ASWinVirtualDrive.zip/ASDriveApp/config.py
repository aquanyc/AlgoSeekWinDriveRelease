#TODO: implement data loading from config
#TODO: make it more explicit that these options came from config

import sys
import os
import env
import ConfigParser

def set_config(key, value, section="AlgoSeek"):
    cfg = ConfigParser.ConfigParser()
    cfg.read(config_filename)
    if cfg.has_section(section) == False:
        cfg.add_section(section)
    cfg.set(section, key, value)
    with open(config_filename , "w") as f:
        cfg.write(f)

def get_config(key, section="AlgoSeek", default=None):
    cfg = ConfigParser.ConfigParser()
    cfg.read(config_filename)
    try:
        value = cfg.get(section, key)
        return value
    except Exception as e:
        #TODO: add some logs here maybe
        return default


#some installation dependent path variables
install_dir = "."
nssm_path = install_dir + "\\nssm.exe" # a tool to install and control services see https://nssm.cc/
key_path = install_dir+"/key.cfg"
default_index_db_url = "http://as-data-cache.s3.amazonaws.com/us-equity-taq.zip"
default_index_db_url_format = "http://as-data-cache.s3.amazonaws.com/{0}.zip"
index_root=install_dir+"/index"

#fs status file
fs_status_path = install_dir+"/fs.status"
service_status_timeout = 600 # 10 mins

#service settings
service_name = "AlgoSeekDriveSvc"
service_display_name = "AlgoSeek Data Drive Windows service"
service_description = "Represents AWS S3 index data and implements a filesystem interface for it."
python_path = sys.executable
driver_exe_path = install_dir+"/ASVirtualDrive"
if env.is_windows():
    driver_exe_path += ".exe"
default_service_start_behaviour="SERVICE_AUTO_START" #SERVICE_DEMAND_START
default_drive="S"
default_mount_dir="AlgoSeekDrive"

#Tray text and icons
hover_text = "AlgoSeek Data Drive"
main_icon = "algoseek.ico"

#run mode
background_mode = (not env.is_gui() and not env.is_windows())

#config file
config_filename="algoseek.ini"


    
