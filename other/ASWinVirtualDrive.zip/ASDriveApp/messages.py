"""
The module implements reading of communication messages between the fs service and app
Platform: any
"""

import threading
import logging
import types

#local modules
from errors import *

#3rd party module to impl communication
import snakemq.link
import snakemq.packeter
import snakemq.messaging
import snakemq.message

LISTEN_PORT = 4000 #TODO: put to config
DRIVER_IDENT = "driver"
GUI_IDENT = "gui"
MESSAGE_TTL = 60

class MessageLoop (threading.Thread):
    """a thread object that runs a message loop with a service app"""
    default_recv = None
    def __init__(self , recv_function, port = LISTEN_PORT, service_id = DRIVER_IDENT, my_id = GUI_IDENT):
        threading.Thread.__init__(self)
        self.port = port
        self.service_id = service_id
        self.my_id = my_id
        self.recv_function = staticmethod(recv_function)
        self.my_link = snakemq.link.Link()
        self.my_packeter = snakemq.packeter.Packeter(self.my_link)
        self.my_messaging = snakemq.messaging.Messaging(my_id, "", self.my_packeter)
        self.my_link.add_connector(("localhost", port))
        bound_func = types.MethodType(recv_function, self, MessageLoop) 
        self.my_messaging.on_message_recv.add(bound_func)
        self.my_messaging.on_message_recv.add(MessageLoop._logging_handler)
        self.exception = None
        self.__ended = False

    def run(self):
        try:
            self.my_link.loop()
        except Exception as e:
            self.exception = e
            if self.__ended == False:
                handle_exception(e)

    def end(self):
        self.__ended = True
        self.my_link.stop()
        self.my_link.cleanup()

    def send(self, message):
        self.my_messaging.send_message(self.service_id, message)

    @staticmethod
    def set_defult_recv(recv):
        MessageLoop.default_recv = recv

    @staticmethod
    def create_default_loop():
        return MessageLoop(MessageLoop.default_recv)

    @staticmethod
    def _logging_handler(conn, ident, message):
        logging.debug("Got message from " + ident + ": " + str(message.data))
        

        

    
