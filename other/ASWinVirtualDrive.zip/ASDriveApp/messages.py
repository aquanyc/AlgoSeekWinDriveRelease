"""
The module implements reading of communication messages between the fs service and app
Platform: any
"""

import threading
import logging
import types

#local modules
from errors import *

#3rd party module to impl communication
import snakemq.link
import snakemq.packeter
import snakemq.messaging
import snakemq.message

LISTEN_PORT = 4000 #TODO: put to config
DRIVER_IDENT = "driver"
GUI_IDENT = "gui"
MESSAGE_TTL = 60

class MessageLoop (threading.Thread):
    """a thread object that runs a message loop"""
    default_recv = None
    
    def __init__(self , recv_function, port = LISTEN_PORT, service_id = DRIVER_IDENT, my_id = GUI_IDENT):
        """
            inits message loop with a handler function and default values
            normally called by create_default_loop()
        """
        threading.Thread.__init__(self)
        # default snake mq stuff
        self.port = port
        self.service_id = service_id
        self.my_id = my_id
        self.recv_function = staticmethod(recv_function)
        self.my_link = snakemq.link.Link()
        self.my_packeter = snakemq.packeter.Packeter(self.my_link)
        self.my_messaging = snakemq.messaging.Messaging(my_id, "", self.my_packeter)
        self.my_link.add_connector(("localhost", port))
        # some python magic to set up the callback to message handler function
        bound_func = types.MethodType(recv_function, self, MessageLoop) 
        self.my_messaging.on_message_recv.add(bound_func)
        self.my_messaging.on_message_recv.add(MessageLoop._logging_handler)
        self.exception = None
        self.__ended = False
        # set daemon so the thread ends when the app closes()
        self.setDaemon(True)

    def run(self):
        """starts message loop thread"""
        try:
            self.my_link.loop()
        except Exception as e:
            self.exception = e
            if self.__ended == False:
                handle_exception(e)

    def end(self):
        """stops message loop thread"""
        self.__ended = True
        self.my_link.stop()
        self.my_link.cleanup()

    def send(self, message):
        """sends a message (not used for now)"""
        self.my_messaging.send_message(self.service_id, message)

    @staticmethod
    def set_defult_recv(recv):
        """a static method to set message handler function for loop created by create_default_loop()"""
        MessageLoop.default_recv = recv

    @staticmethod
    def create_default_loop():
        """a factory method called to create a message loop"""
        return MessageLoop(MessageLoop.default_recv)

    @staticmethod
    def _logging_handler(conn, ident, message):
        """a handler to log messages"""
        logging.debug("Got message from " + ident + ": " + str(message.data))
        

        

    
