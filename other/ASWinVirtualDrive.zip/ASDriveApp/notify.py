"""
Code containing balloon notificiation in python
"""

import sys, os
import struct
import time

# local modules:
import env
if env.is_windows():
    # win modules
    from win32api import *
    from win32gui import *
    import win32con

class WindowsBalloonTip:
    def __init__(self, title, msg , hwnd):
        
        hinst = GetModuleHandle(None)
        iconPathName = os.path.abspath(os.path.join( sys.path[0], "balloontip.ico" ))
        icon_flags = win32con.LR_LOADFROMFILE | win32con.LR_DEFAULTSIZE
        try:
            hicon = LoadImage(hinst, iconPathName, \
                win32con.IMAGE_ICON, 0, 0, icon_flags)
        except:
            hicon = LoadIcon(0, win32con.IDI_APPLICATION)

        # if there is now prebuilt parent tray icon
        if hwnd == None:
            # Create the Window if not created yet.
            message_map = {
                win32con.WM_DESTROY: self.OnDestroy,
            }
             # Register the Window class.
            wc = WNDCLASS()
            wc.hInstance = hinst
            wc.lpszClassName = "PythonTaskbar"
            wc.lpfnWndProc = message_map # could also specify a wndproc.
            classAtom = RegisterClass(wc)
            style = win32con.WS_OVERLAPPED | win32con.WS_SYSMENU
            self.hwnd = CreateWindow( classAtom, "Taskbar", style, \
                    0, 0, win32con.CW_USEDEFAULT, win32con.CW_USEDEFAULT, \
                    0, 0, hinst, None)
            UpdateWindow(self.hwnd)
            flags = NIF_ICON | NIF_MESSAGE | NIF_TIP
            nid = (self.hwnd, 0, flags, win32con.WM_USER+20, hicon, "tooltip")
            Shell_NotifyIcon(NIM_ADD, nid)
        else:
            self.hwnd = hwnd
        
        Shell_NotifyIcon(NIM_MODIFY, \
                         (self.hwnd, 0, NIF_INFO, win32con.WM_USER+20,\
                          hicon, "Balloon  tooltip",msg,200,title))
        # if there is now prebuilt parent tray icon
        if not hwnd:
            DestroyWindow(self.hwnd)
        
    def OnDestroy(self, hwnd, msg, wparam, lparam):
        nid = (self.hwnd, 0)
        Shell_NotifyIcon(NIM_DELETE, nid)
        PostQuitMessage(0) # Terminate the app.

#These functions may be overriden for other platforms
def balloon_tip(title, msg, hwnd):
    if env.is_gui():
        if env.is_windows():
            w=WindowsBalloonTip(title, msg, hwnd)
        else:
            raise NotImplemented("Non-Windows GUI not implemented")
    else:
        print(title + ":" + msg)
        

def message_box(title, msg):
    if env.is_gui():
        if env.is_windows():
            import ctypes
            MessageBox = ctypes.windll.user32.MessageBoxA
            MB_SYSTEMMODAL = 0x00001000
            MB_ICONINFORMATION = 0x00000040
            flags = MB_SYSTEMMODAL + MB_ICONINFORMATION
            MessageBox(None, msg, title, flags)
        else:
            raise NotImplemented("Non-Windows GUI not implemented")
    else:
        if env.is_linux():
            os.system('echo "'+title ":" + msg+'" | wall')
        else:
            print(title + ":" + msg)

def prompt_box(title, msg):
    if env.is_gui():
        if env.is_windows():
            import ctypes
            MessageBox = ctypes.windll.user32.MessageBoxA
            MB_SYSTEMMODAL = 0x00001000
            MB_YESNO = 0x00000004
            MB_ICONQUESTION = 0x00000020
            flags = MB_SYSTEMMODAL + MB_YESNO + MB_ICONQUESTION
            IDYES = 6
            IDNO = 7
            return MessageBox(None, msg, title, flags) == IDYES
        else:
            raise NotImplemented("Non-Windows GUI not implemented")
    else:
        return True #we assume user always confirm these prompts
