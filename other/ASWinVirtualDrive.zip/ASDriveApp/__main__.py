# local modules
from tray import SysTrayIcon
import notify

# standard modules
import subprocess
import pip
import sys
import os
import shutil
import time
import logging
import exceptions
import traceback
import zipfile
import urllib

# Tk GUI (incl in Python) for extra dialogs
import Tkinter
import tkFileDialog

""" Main module for Windows AlgoDrive app """

#some installation dependent path variables
install_dir = "."
nssm_path = install_dir + "\\nssm.exe" # a tool to install and control services see https://nssm.cc/
key_path = install_dir+"\\key.cfg"

#service settings
service_name = "AlgoSeekDriveSvc"
service_display_name = "AlgoSeek Windows Virtual Drive service"
service_description = "Represents AWS S3 index data and implements a filesystem interface for it."
python_path = sys.executable
default_service_start_behaviour="Manual"

#Tray text and icons
hover_text = "AlgoSeek Virtual Drive"
main_icon = "algoseek.ico"

#update source
update_url = ""

#global tray Window object
tray_window = None

# --------------- HELPER FUNCTIONS

def notify_user(msg , title="AlgoSeek Virtual Drive"):
    if tray_window:
        try:
            notify.balloon_tip(title , msg , tray_window.hwnd)
            return
        except Exception as Ex:
            logging.warn("Failed to show balloon tip! " + str (Ex))
    else:
        logging.warn("Tray window is not set, using Message Boxes to notify user")
    # fallback to plain old message box
    notify.message_box(title , msg)

def handle_exception(err):
    notify_user(str(err) , "Failure!")
    logging.error("EXCEPTION " + str(err))
    logging.error(traceback.format_exc())


def configure_logs():
    logFormatter = logging.Formatter("%(asctime)s [%(threadName)-12.12s] [%(levelname)-5.5s]  %(message)s")
    rootLogger = logging.getLogger()

    fileHandler = logging.FileHandler(install_dir+"\\app.log")
    fileHandler.setFormatter(logFormatter)
    rootLogger.addHandler(fileHandler)

    consoleHandler = logging.StreamHandler()
    consoleHandler.setFormatter(logFormatter)
    rootLogger.addHandler(consoleHandler)


# --------------- SERVICE CONTROL

#here we define actions for buttons
def update():
    #pip or MSI?
    return 0

def check_nssm():
    """checks if nssm.exe is available"""
    return os.path.exists(nssm_path)

def check_installed():
    nssm_check = [nssm_path , "status" , service_name]
    if (subprocess.call(nssm_check) == 0):
        return True
    return False

def check_running():
    """checks service is running"""
    #TODO: implement more smart check of FS actual state
    nssm_check = [nssm_path , "status" , service_name]
    if ("SERVICE_RUNNING" in subprocess.check_output(nssm_check)):
        return True
    return False

def get_status():
    """gets simple printable status of service"""
    if check_installed() == False:
        return "Service not installed. Please restart the app."
    if check_running():
        return "Service Running"
    else:
        return "Service Stopped"

def install():
    """installs the service"""
    # install the service
    # throws The CalledProcessError with  return code in the returncode attribute and any output in the output attribute
    # in case of errors
    nssm_install = [nssm_path , "install" , service_name, python_path, "-m" , "ASVirtualDrive"] #TODO: add parms to ASVirtualDrive script __main__
    res = subprocess.check_output(nssm_install)
    
    nssm_command = [nssm_path , "set" , service_name, "AppDirectory", os.path.abspath(install_dir)]
    res = subprocess.check_output(nssm_command)
    
    nssm_command = [nssm_path , "set" , service_name, "Start", default_service_start_behaviour]
    res = subprocess.check_output(nssm_command)

    nssm_command = [nssm_path , "set" , service_name, "DisplayName", service_display_name]
    res = subprocess.check_output(nssm_command)
    
    nssm_command = [nssm_path , "set" , service_name, "Description", service_description]
    res = subprocess.check_output(nssm_command)

    # TODO: set service description 
    return 0

def start():
    #TODO: use popen to return text result in case of errors
    nssm_start = [nssm_path , "start" , service_name]
    subprocess.check_output(nssm_start)    

def stop():
    #TODO: use popen to return text result in case of errors
    nssm_start = [nssm_path , "stop" , service_name]
    subprocess.check_output(nssm_stop) 

def apply_key(path):
    """Copy config with keys to the local dir so the filesystem code will apply it on the next run"""
    #backup existing key
    shutil.copyfile(key_path, key_path+str(int(time.time()))+".backup")
    shutil.copyfile(path, key_path)
    return True

def check_key(path):
    """checks if key on path is valid"""
    #TODO: implement check if it is valid python file
    return True

### --------------- MENU HANDLERS 

def action_apply_key_dialog(wnd):
    try:
        path = tkFileDialog.askopenfilename()
        if not path:
            return 
        if os.path.exists(path):
            if check_key(path):
                apply_key(path)
                notify_user("New key applied. Please reconnect to access your data.")
            else:
                notify_user("Invalid key")
    except Exception as err:
        handle_exception(err);
        


def action_connect(wnd):
    try:
        if check_running():
            notify_user("Already connected");
        else:
            start()
            time.sleep(5)
            if check_running():
                notify_user("Connected!");
            else:
                notify_user("Connection Error!!");
    except Exception as err:
        handle_exception(err);



def action_disconnect(wnd):
    try:
        if check_running() == False:
            notify_user("Already disconnected");
        else:
            stop()
            time.sleep(5)
            if check_running():
                notify_user("Could not disconnect!");
            else:
                notify_user("Disconnected!");
    except Exception as err:
        handle_exception(err)

def action_show_contacts(wnd):
    try:
        notify_user("For support proceed to AlgoSeek.com"); #TODO: set some simple link here
    except Exception as err:
        handle_exception(err)

def action_options(wnd):
    try:
        notify_user("No options yet...");
    except Exception as err:
        handle_exception(err)
    
def action_send_troubleshooting_info(wnd):
    try:
        #TODO: gather all logs we have. save to zip 
        archive_path = os.path.abspath(install_dir)+"\\SendMe.zip"
        zf = zipfile.ZipFile(archive_path, mode='w')
        logfiles = [f for f in os.listdir(install_dir) if str(f).endswith(".log")]
        for file in logfiles:
            zf.write(file)
        zf.close()
        subprocess.Popen(r'explorer /select,"'+archive_path+'"')
        notify_user("Info gathered at " + archive_path + "\nNow you may send it to AlgoSeek support!");
    except Exception as err:
        handle_exception(err)

def action_update(wnd):
    try:
        update()
    except Exception as err:
        handle_exception(err)

def action_on_quit(wnd):
    try:
        notify_user("Status:" + get_status() + "\nRestart the app so the tray icon appear again. See you later!")
    except Exception as err:
        handle_exception(err)

def action_status(wnd):
    try:
        notify_user("Status:" + get_status() + "\nRight click on tray icon for more options")
    except Exception as err:
        handle_exception(err)

# ---------------------- MAIN

def main():

    configure_logs();

    Tkinter.Tk().withdraw() # Close the root window

    # On start:
    # 1. Update
    # 2. If not present - reinstall
    # Optionally:
    # 3. Connect 
    # 4. TODO: Wait and check connection OK. Make some py related checks for it, e.g. file that contains start time
    # 5. Show message (in tray or message box that we run)

    update()
    if check_nssm() == False:
        notify_user("Fatal Error: Could not find nssm.exe. Please reinstall the software!")
        #exit(0)
    else:
        if (not check_installed()): 
            install()
            notify_user("Virtual Drive Service installed!")

    # Menu:
    # Connect (starts the service)
    # Disconnect (stops the service)
    # Apply AlgoSeek key - Get access to paid data (apply new aws config)
    # Support > 1. Contact 2. Gather Troubleshooting Data
    # Extra > 1. Update Software (download .py, restart), 2. Select Drive Letter, 3. Connect on start

    # On exit: disconnect
    
    menu_options = (('Status', None, action_status),
                    ('Connect', None, action_connect),
                    ('Disconnect', None, action_disconnect), #TODO: make disconnect grey if connected
                    ('Apply AlgoSeek Key', None, action_apply_key_dialog),
                    ('Support', None, (('Contact Support', None, action_show_contacts),
                                       ('Gather Troubleshooting Info...', None, action_send_troubleshooting_info),
                                           )),
                    ('Extra', None,   (('Update Software', None, action_update),
                                       ('Options...', None, action_options),
                                           ))
                   )

    global tray_window
    tray_window = SysTrayIcon(main_icon, hover_text, menu_options, on_quit=action_on_quit, default_menu_index=0)
    tray_window.start()


if __name__ == '__main__':
    main()
