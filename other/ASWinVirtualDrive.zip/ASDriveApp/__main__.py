import logging
import traceback
import ctypes, sys

""" Main module for Windows AlgoDrive app. It acts as bootstrapper. The main code is done in menu.py """

import os
import sys
import win32com.shell.shell as shell
ASADMIN = 'asadmin'

def is_admin():
    try:
        return ctypes.windll.shell32.IsUserAnAdmin()
    except:
        return False

def spawn_as_administrator():
    """ Spawn ourself with administrator rights and wait for new process to exit
        Make the new process use the same console as the old one.
          Raise Exception() if we could not get a handle for the new re-run the process
          Raise pywintypes.error() if we could not re-spawn
        Return the exit code of the new process,
          or return None if already running the second admin process.
         Taken from: https://stackoverflow.com/a/34216774/2951531 """
    #pylint: disable=no-name-in-module,import-error
    import win32event, win32api, win32process
    import win32com.shell.shell as shell
    if '--admin' in sys.argv:
        return None
    script = '"'+ os.path.abspath(sys.argv[0]) + '"'
    params = ' '.join(script + sys.argv[1:] + ['--admin'])
    SEE_MASK_NO_CONSOLE = 0x00008000
    SEE_MASK_NOCLOSE_PROCESS = 0x00000040
    process = shell.ShellExecuteEx(lpVerb='runas', lpFile=sys.executable, lpParameters=params, fMask=SEE_MASK_NO_CONSOLE|SEE_MASK_NOCLOSE_PROCESS)
    hProcess = process['hProcess']
    if not hProcess:
        raise Exception("Could not identify administrator process to install drivers")
    # It is necessary to wait for the elevated process or else
    #  stdin lines are shared between 2 processes: they get one line each
    INFINITE = -1
    win32event.WaitForSingleObject(hProcess, INFINITE)
    exitcode = win32process.GetExitCodeProcess(hProcess)
    win32api.CloseHandle(hProcess)
    return exitcode

# ---------------------- MAIN

def main():
    """bootstraper to update program code and run main menu"""

    # Re-run the program with admin rights
    if not is_admin():
        spawn_as_administrator()
        sys.exit(0)

    try:
        
        try:
            import update
            update.update()    
            # reload module that possibly was updated
            #reload(update)
        except Exception as e:
            logging.warn("Failed to update! " + str(e) + " " + repr(e))
            logging.warn(traceback.format_exc())

        # import after update
        import menu
        menu.start_menu()

    except Exception as e:
        logging.error("Generic init failure! " + str(e) + " " + repr(e))
        logging.error(traceback.format_exc())
   


if __name__ == '__main__':
    main()
