import logging
import traceback
import ctypes, sys

""" Main module for Windows AlgoDrive app. It acts as bootstrapper. The main code is done in menu.py """

import os
import sys
import win32com.shell.shell as shell
ASADMIN = 'asadmin'

def is_admin():
    try:
        return ctypes.windll.shell32.IsUserAnAdmin()
    except:
        return False

# ---------------------- MAIN

def main():
    """bootstraper to update program code and run main menu"""

    # Re-run the program with admin rights
    if not is_admin():
        if sys.argv[-1] != ASADMIN:
            script = os.path.abspath(sys.argv[0])
            params = ' '.join([script] + sys.argv[1:] + [ASADMIN])
            shell.ShellExecuteEx(lpVerb='runas', lpFile=sys.executable, lpParameters=params)
            sys.exit(0)

    try:
        
        try:
            import update
            update.update()    
            # reload module that possibly was updated
            #reload(update)
        except Exception as e:
            logging.warn("Failed to update! " + str(e) + " " + repr(e))
            logging.warn(traceback.format_exc())

        # import after update
        import menu
        menu.start_menu()

    except Exception as e:
        logging.error("Generic init failure! " + str(e) + " " + repr(e))
        logging.error(traceback.format_exc())
   


if __name__ == '__main__':
    main()
