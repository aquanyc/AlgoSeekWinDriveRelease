import shutil
import os
import time

from config import *

#TODO: obsolete. keys should be implemented via config
def apply_key(path):
    """Copy config with keys to the local dir so the filesystem code will apply it on the next run"""
    #backup existing key
    if (os.path.exists(key_path)):
        shutil.copyfile(key_path, key_path+str(int(time.time()))+".backup")
    shutil.copyfile(path, key_path)
    return True

def check_key(path):
    """checks if key on path is valid"""
    #TODO: implement check if it is a valid python file
    return True
