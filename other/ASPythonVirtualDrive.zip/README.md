# Introduction

FUSE filesystem to enumerate and read stock data from S3.

Filesystem can show data from several data sources (S3 buckets). For each bucket, a separate local index database cache file has to be available in order data to be accessible.

The filesystem is available on Linux and Windows platforms. 
It utilizes FUSE (or FUSE-compatible like WinFSP) driver to interact with operating system kernel whilst file system logic is handled in python user-space modules.

## Requirements

TODO: supported OS, python version

## Installation

TODO: installation with pip

# Technical documentation

The section describes main mechanisms involved in AlgoSeek drive filesystem implementation.

## How data stored in S3

TODO: info about how data is stored in S3

## How data is represented

TODO: how data is represented

### Root folders (VFS)

TODO: how root folders are implemented. The structure of json file

## Index database

Metadata (filenames, directory structure, actual S3 data location) is taken from local index database cache file.

There is a separate database for each S3 bucket of source data. Database name equals to bucket name it represents.

### Index database structure (filedb)

Index database is implemented as a local filesystem folder that consists of subfolders and metadata files. Folder name is equal to s3 bucket name.
These subfolders consists of either more subfolders, or metadata (csv) files.
Folders and subfolders represent emulated filesystem hierarchy (folders) while metadata files have entries for files. 
A metadata file has entries for files, one row per file. An entry have the following fields: source S3 bucket name, full path to a folder that contains the file, filename, its compressed size, its original uncompressed size.
A metadata file has also entries for directories. It has the same format as a file entry but its size fields are set to zero.

Whenever a filesystem client queries a filesystem directory contents, filesystem forwards the query to index database. Index database searches
if there is a corresponding subfolder (with the same dirname path as requested directory) in database folder.
Then, a) if database folder exists, index database enlists all (local filesystem) folders within the folder found to return them as subfolders. Then, index database open AS_metadata.csv file inside the folder if available, and
searches for all file entries that have folder path matching the folder (direct ascendants in the hierarchy) to return them either as files or folders.
If b) database folder is absent, index database searches for a folder one level higher and AS_metadata.csv there and seeks for the folder entry, and its direct ascendants so to return them (if an upper-level folder is also absent, it goes one level higher again till the topmost folder is reached).

Concluding, AS_metadata.csv file contains file entries but also a complementary to database local filesystem folder structure in order to represend emulated filesystem hierarchy.

An example of folder structure within index database is shown below.

<sub>
 
    /us-equity-taq
     /2007
      /A
       /AAA
        /AS_metadata.csv
       /ABC
        /AS_metadata.csv
      /B
      /AS_metadata.csv
    /2008
     /AS_metadata.csv
    /2009
     /AS_metadata.csv
     /A
      /AAA
       /AS_metadata.csv
</sub>

It may represent the following filesystem (depending on AS_metadata.csv contents)

<sub>
 
    /us-equity-taq
     /2007
      /A
       /AAA
        /file1.csv
        /file2.csv
        /file3.csv
       /ABC
        /file1.csv
        /file2.csv
      /B
       /BAA
        /file1.csv
        /BAA-SUBFOLDER
         /file1.csv
         /file2.csv
       /BBB
         /file1.csv
     /2008
      /A
       /AAA
        /file1.csv
        /file2.csv
        /file3.csv
       /ABC
        /file1.csv
        /file2.csv
     /2009
      /A
       /AAA
        /file1.csv
        /file2.csv
        /file3.csv
      /B
       /BAA
        /file1.csv
        
</sub>

The logic of the database is implemented in filedb.py

### HOWTO: Create index database

To create an index database file for a bucket (both Linux and Windows):

1. Make sure python is installed and available from the command line 
2. Get the source code (by downloading and unzipping https://github.com/aquanyc/ASPythonVirtualDrive/archive/master.zip or running 'git clone https://github.com/aquanyc/ASPythonVirtualDrive.git')
3. cd to ASPythonVirtualDrive/ASVirtualDrive
4. python filedb.py --new --compress --bucket DATABUCKET --awskey AWSKEY --awssecret AWSSECRET --merge 4096
   
   e.g. 
   
   python filedb.py --new --compress --bucket us-equity-taq --awskey AKIAIIOU5OR424SMYJTQ --awssecret KZHq2CLcfwmxKK4CTJ6/GyYDWpcTnR7vg5srzhho --merge 4096

5. Zip file containing db will appear in index/ subfolder

## Misc

TODO: links: options, winfsp. python

