# Introduction

AlgoSeek filesystem driver (referred as 'the driver') to enumerate and read stock data from S3.

Filesystem can show data from several data sources (S3 buckets). For each bucket, a separate local index database cache file has to be available in order data to be accessible.

The filesystem is available on Linux and Windows platforms. 
It utilizes FUSE (or FUSE-compatible like WinFSP) driver to interact with operating system kernel whilst file system logic is handled in python user-space modules.

## Requirements

### Windows

Operating Systems, Windows: Windows 7+, Windows Sever 2008 R2+

WinFSP driver installed

### Linux

Any distro with FUSE dirver installed

### Python version

2.6 , 2.7

Python PIP installer available.

## Installation

sudo pip install https://github.com/aquanyc/ASPythonVirtualDrive

## Run

python -m ASVirtualDrive.__main__

Note: using a user App (https://github.com/aquanyc/ASWinVirtualDrive) to configure the driver properly is highly recommended

# Technical documentation

The section describes main mechanisms involved in AlgoSeek drive filesystem implementation.

## How data stored in S3

Historical market data is stored in buckets on AWS S3.   The buckets have names like:
us-equity-taq
us-futures-taq-2017.

Buckets have millions of historical data objects.  The top level of buckets looks like:
us-equity-taq/2017/20170328/*
us-futures-taq-2017/20170328/* 

Native Amazon API to index data cannot be used as it is implies extra listing costs.

as-data-index public bucket is used to store metadata for market data files.
Each bucket has a corresponding folder in s3://as-data-index with an index of all historical data files in the bucket.
E.g. the index bucket for us-equity-taq will be s3://as-data-index/us-equity-taq/ .  
Each index bucket contains compressed csv files with one file per tradedate, for example “us-futures-taq-2017/2017018.csv.gz “ .
The csv file contains the following fields: Bucket, path, filename, compressed_size, uncompressed_size

Index of Index Bucket.  Each bucket index has a file called “index.json.gz” which is a json file showing tradedates available for each year. 
Each tradedate in the json corresponds to a tradedate file in the index bucket.  The format is
{
“2007” : [ “20070103”, “20070104”, “20070104”],
“2008” : [ “20080103”, “20080104”, “20080104”]
}

## Index database

Metadata (filenames, directory structure, actual S3 data location) is taken from local index database cache file.

There is a separate database for each S3 bucket of source data. Database name equals to bucket name it represents.

Index database is created based on data available in as-data-index public bucket via a script included into filesystem module (see `HOWTO: Create index database` below).

### Index database structure (filedb)

Index database is implemented as a local filesystem folder that consists of subfolders and metadata files. Folder name is equal to s3 bucket name.
These subfolders consists of either more subfolders, or metadata (csv) files.
Folders and subfolders represent emulated filesystem hierarchy (folders) while metadata files have entries for files. 
A metadata file has entries for files, one row per file. An entry have the following fields: source S3 bucket name, full path to a folder that contains the file, filename, its compressed size, its original uncompressed size.
A metadata file has also entries for directories. It has the same format as a file entry but its size fields are set to zero.

Whenever a filesystem client queries a filesystem directory contents, filesystem forwards the query to index database. Index database searches
if there is a corresponding subfolder (with the same dirname path as requested directory) in database folder.
Then, a) if database folder exists, index database enlists all (local filesystem) folders within the folder found to return them as subfolders. Then, index database open AS_metadata.csv file inside the folder if available, and
searches for all file entries that have folder path matching the folder (direct ascendants in the hierarchy) to return them either as files or folders.
If b) database folder is absent, index database searches for a folder one level higher and AS_metadata.csv there and seeks for the folder entry, and its direct ascendants so to return them (if an upper-level folder is also absent, it goes one level higher again till the topmost folder is reached).

Concluding, AS_metadata.csv file contains file entries but also a complementary to database local filesystem folder structure in order to represend emulated filesystem hierarchy.

An example of folder structure within index database is shown below.

<sub>
 
    /us-equity-taq
     /2007
      /A
       /AAA
        /AS_metadata.csv
       /ABC
        /AS_metadata.csv
      /B
      /AS_metadata.csv
    /2008
     /AS_metadata.csv
    /2009
     /AS_metadata.csv
     /A
      /AAA
       /AS_metadata.csv
</sub>

It may represent the following filesystem (depending on AS_metadata.csv contents)

<sub>
 
    /us-equity-taq
     /2007
      /A
       /AAA
        /file1.csv
        /file2.csv
        /file3.csv
       /ABC
        /file1.csv
        /file2.csv
      /B
       /BAA
        /file1.csv
        /BAA-SUBFOLDER
         /file1.csv
         /file2.csv
       /BBB
         /file1.csv
     /2008
      /A
       /AAA
        /file1.csv
        /file2.csv
        /file3.csv
       /ABC
        /file1.csv
        /file2.csv
     /2009
      /A
       /AAA
        /file1.csv
        /file2.csv
        /file3.csv
      /B
       /BAA
        /file1.csv
        
</sub>

The logic of the database is implemented in filedb.py

### HOWTO: Create index database

To create an index database file for a bucket (both Linux and Windows):

1. Make sure python is installed and available from the command line 
2. Get the source code (by downloading and unzipping https://github.com/aquanyc/ASPythonVirtualDrive/archive/master.zip or running 'git clone https://github.com/aquanyc/ASPythonVirtualDrive.git')
3. cd to ASPythonVirtualDrive/ASVirtualDrive
4. python filedb.py --new --compress --bucket DATABUCKET --awskey AWSKEY --awssecret AWSSECRET --merge 4096
   
   e.g. 
   
   python filedb.py --new --compress --bucket us-equity-taq --awskey AKIAIIOU5OR424SMYJTQ --awssecret KZHq2CLcfwmxKK4CTJ6/GyYDWpcTnR7vg5srzhho --merge 4096

5. Zip file containing db will appear in index/ subfolder

Note: http://as-data-index.s3.amazonaws.com/bucket-name/index.json.gz should be available for Db creation sctipt to run

## How data is represented

A user may browse several buckets, so the filesystem mounts several buckets in a time. 
It is done by creating an extra layer (called 'VFS', an analogy to VFS in \*nix kernel) of subdirectories emulated by the filesystem driver. 
Buckets (and their corresponding index databases) may be 'mounted' to these emulated subdirectories. 
VFS may have an arbitrary hierarchy and names for mount points.

NOTE: 'mount' is a mere analogy with actual mount of filesystem. From the system perspective there is only one mount point - the root one created when driver starts.

What buckets are 'mounted' and thus available for browsing is configured by VFS json file (default is 'default.json') consisting of a list with entries.

JSON file enlists directories. Directory entries are in the following form: {"size": 4096, "id": null, "name": "Test Dev Data/"}. 

"size" is always 4096, "id" is null, "name" is the full path to the emulated directory ending with `/`.

NOTE: A node for each level of directory hierarchy should be created.

JSON file also enlists mount points. Directories in which actual bucket data would be displayed, e.g.
{"params":"us-equity-trades", "size": 4096, "type": "mount", "id": null, "name": "Test Data/US Equity/US Equity Trades"}

"size" is always 4096, "type" is set to "mount", "id" is null, "name" is full path to mount point without trailing slash, "params" equals to bucket name.

An example for json VFS file:
<sub>
 
     [
     {"size": 4096, "id": null, "name": "Test Data/"}, 
     {"size": 4096, "id": null, "name": "Test Data/US Equity/"}, 
     {"params": "us-equity-taq", "size": 4096, "type": "mount", "id": null, "name": "Test Data/US Equity/US Equity Taq"}, 
     {"params":"us-equity-trades", "size": 4096, "type": "mount", "id": null, "name": "Test Data/US Equity/US Equity Trades"},
     {"size": 4096, "id": null, "name": "Test Data/US Futures/"}, 
     {"params": "us-futures-taq-2009", "size": 4096, "type": "mount", "id": null, "name": "Test Data/US Futures/US Futures Taq 2009 (Unavailable)"}, 
     {"params": "us-futures-taq-2010", "size": 4096, "type": "mount", "id": null, "name": "Test Data/US Futures/US Futures Taq 2010"}, 
     {"size": 4096, "id": null, "name": "Test Data/US Options/"}, 
     {"params": "us-options-1min-trades-2016", "size": 4096, "type": "mount", "id": null, "name": "Test Data/US Options/US Options 1 min Trades 2016"}, 
     {"params": "us-options-1min-trades-2017", "size": 4096, "type": "mount", "id": null, "name": "Test Data/US Options/US Options 1 min Trades 2017 (Unavailable)"}
     ]
     
</sub>


## Misc

Configuration file description: https://github.com/aquanyc/AlgoSeekWinDriveRelease/blob/master/OPTIONS.md

TODO: links: options, winfsp. python

