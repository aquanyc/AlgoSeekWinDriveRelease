## Introduction

FUSE filesystem to enumerate and read stock data from S3.

The metadata (filenames, directory structure, actual data location) is taken from local index database cache file.

Filesystem can show data from several data sources (S3 buckets). For each bucket, a separate local index database cache file has to be available in order data is accessible.

The filesystem is available on Linux and Windows platforms.

TODO: more readme entries


## Misc:

### Create index database:

To create an index database file for a bucket (both Linux and Windows):

1. Make sure python is installed and available from the command line 
2. Get the source code (by downloading and unzipping https://github.com/aquanyc/ASPythonVirtualDrive/archive/master.zip or running 'git clone https://github.com/aquanyc/ASPythonVirtualDrive.git')
3. cd to ASPythonVirtualDrive/ASVirtualDrive
4. python filedb.py --new --compress --bucket DATABUCKET --awskey AWSKEY --awssecret AWSSECRET --merge 4096
   
   e.g. 
   
   python filedb.py --new --compress --bucket us-equity-taq --awskey AKIAIIOU5OR424SMYJTQ --awssecret KZHq2CLcfwmxKK4CTJ6/GyYDWpcTnR7vg5srzhho --merge 4096

5. Zip file containing db will appear in index/ subfolder


