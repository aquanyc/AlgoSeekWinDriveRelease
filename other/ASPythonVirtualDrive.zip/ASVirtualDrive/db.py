import os
import re
import sqlite3
import itertools


PATH_PATTERN = re.compile(
    r'^\/(?P<year>\d{4})\/(?P<data_date>\d{8})\/(?P<first_symbol>[A-Z]{1})\/(?P<file_name>[A-Z]+\.csv\.gz$)'
)


def get_connection(database, create_db=None):
    database = database + '.db' if not database.endswith('.db') else database
    if os.path.exists(database) or create_db:
        return sqlite3.connect(database , check_same_thread=False)
    else:
        raise Exception('No database found with path {}'.format(database))


def dict_factory(cursor, row):
    return {col[0]:row[idx] for idx, col in enumerate(cursor.description)}


def _query_bucket(connection, year=None, data_date=None, first_symbol=None, file_name=None):
    connection.row_factory = dict_factory
    cursor = connection.cursor()
    if all((year, data_date, first_symbol)):
        cursor.execute('select file_name, file_size from bucket '
                       'inner join years using (year_id) '
                       'inner join dates using (date_id) '
                       'inner join symbols using (symbol_id) '
                       'inner join files using (file_id) '
                       'where year = ? and data_date = ? and first_symbol = ? and file_name like ?',
                       (year, data_date, first_symbol, (file_name or '') + '%'))
    elif all((year, data_date)):
        cursor.execute('select distinct first_symbol from bucket '
                       'inner join years using (year_id) '
                       'inner join dates using (date_id) '
                       'inner join symbols using (symbol_id) '
                       'where year = ? and data_date = ? and first_symbol like ?',
                       (year, data_date, (first_symbol or '') + '%'))
    elif all((year,)):
        cursor.execute('select distinct data_date from bucket '
                       'inner join years using (year_id) '
                       'inner join dates using (date_id) '
                       'where year = ? and data_date like ?',
                       (year, (data_date or '') + '%'))
    else:
        cursor.execute('select distinct year from years')
    return cursor.fetchall()


def get_folder_content(connection, path):
    path_dict = {it[0]: it[1] for it in
                 itertools.izip_longest(('year', 'data_date', 'first_symbol', 'file_name'), split_path(path))}
    return _query_bucket(connection, **path_dict)


def get_file_size(connection, path):
    connection.row_factory = dict_factory
    year, data_date, first_symbol, file_name = split_path(path)
    cursor = connection.cursor()
    if not all((year, data_date, first_symbol, file_name)):
        raise Exception('Invalid path')
    cursor.execute('select file_size from bucket '
                   'inner join years using (year_id) '
                   'inner join dates using (date_id) '
                   'inner join symbols using (symbol_id) '
                   'inner join files using (file_id) '
                   'where year = ? and data_date = ? and first_symbol = ? and file_name = ?',
                   (year, data_date, first_symbol, file_name + '.gz'))
    res = cursor.fetchone()
    if not res:
        raise Exception('File not found')
    return res['file_size']


def split_path(path):
    head, tail = os.path.split(path)
    if not head or head == '/':
        return tail,
    else:
        return split_path(head) + (tail,)

if __name__ == '__main__':
    import sys
    import csv
    def _load_data_into_bucket_db(bucket, data_file_path):
        data_reader = csv.reader(open(data_file_path), delimiter=',')
        conn = get_connection(bucket, create_db=True)
        cursor = conn.cursor()
        cursor.execute('CREATE TABLE IF NOT EXISTS bucket '
                       '(year_id INT, date_id INT, symbol_id INT, file_id INT, file_size INT)')
        cursor.execute('CREATE TABLE IF NOT EXISTS years (year_id INT, year TEXT)')
        cursor.execute('CREATE TABLE IF NOT EXISTS dates (date_id INT, data_date TEXT)')
        cursor.execute('CREATE TABLE IF NOT EXISTS symbols (symbol_id INT, first_symbol TEXT)')
        cursor.execute('CREATE TABLE IF NOT EXISTS files (file_id INT, file_name TEXT)')
        years = {}
        years_key = 0
        dates = {}
        dates_key = 0
        symbols = {}
        symbols_key = 0
        files = {}
        files_key = 0
        for _, path, file_name, _, uncompressed_size in data_reader:
            year, data_date, first_symbol = split_path(path)
            if year in years:
                year_id = years[year]
            else:
                year_id = years_key
                years_key += 1
                years[year] = year_id
            if data_date in dates:
                date_id = dates[data_date]
            else:
                date_id = dates_key
                dates_key += 1
                dates[data_date] = date_id
            if first_symbol in symbols:
                symbol_id = symbols[first_symbol]
            else:
                symbol_id = symbols_key
                symbols_key += 1
                symbols[first_symbol] = symbol_id
            if file_name in files:
                file_id = files[file_name]
            else:
                file_id = files_key
                files_key += 1
                files[file_name] = file_id
            cursor.execute('INSERT INTO bucket VALUES (?, ?, ?, ?, ?)',
                           (year_id, date_id, symbol_id, file_id, uncompressed_size))
        cursor.executemany('INSERT INTO years VALUES (?, ?)',
                           [(year_id, year) for year, year_id in years.items()])
        cursor.executemany('INSERT INTO dates VALUES (?, ?)',
                           [(date_id, date) for date, date_id in dates.items()])
        cursor.executemany('INSERT INTO symbols VALUES (?, ?)',
                           [(symbol_id, symbol) for symbol, symbol_id in symbols.items()])
        cursor.executemany('INSERT INTO files VALUES (?, ?)',
                           [(file_id, file_name) for file_name, file_id in files.items()])
        conn.commit()
        conn.close()
    bucket, data_file_path = sys.argv[1], sys.argv[2]
    _load_data_into_bucket_db(bucket, data_file_path)
