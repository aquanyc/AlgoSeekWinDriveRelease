"""The module defines predifined status code string constants"""

OK = "OK"
LOCAL_DB_FAILURE = "DB FAILURE" #parm: bucketname
LOCAL_DB_EMPTY = "DB EMPTY" #parm: bucketname
FAILED_ACCESS_DENIED = "ACCESS DENIED"
GENERIC_DATA_ACCESS_ERROR = "DATA ACCESS ERROR"
MOUNT_FAILURE="MOUNT FAILED"
NOT_FOUND="NOT FOUND"
MOUNTED="MOUNTED" #parm: mountpoint
