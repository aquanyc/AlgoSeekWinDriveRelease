"""
A module that has some profiling functions for deep verbose tracing using logging.debug.
The functions execute only if options.profiling is set to true
"""

import options 
import logging
import time


def trace_in(function_name , param_dict):
    """
        traces the function entry. params are the function name and its parameters dictionary.
        returns time value which can be passed to trace_out function for profiling
    """
    if not options.profiling:
        return 0
    timestart = time.time()
    #TODO: use a different logger for that
    
    logging.debug('>>> %s : %s' % (function_name, str(param_dict) ) )
    return timestart


def trace_out(function_name , t_start = None, retval = None ):
    """
        traces the function return optionally taking return value and t_start - time as returned by trace_in
    """
    if not options.profiling:
        return
    timeend = time.time()
    timestart = t_start
    if not t_start:
        timestart = timeend
    #TODO: use a different logger for that
    
    logging.debug('<<< %s %0.3f ms ret:%s' % (function_name, (timeend-timestart)*1000.0, str(retval)) )
    return timeend-timestart
