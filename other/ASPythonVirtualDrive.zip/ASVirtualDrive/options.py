"""module that holds global options for the program and functions to load them"""

# TODO: more options like buckets here
# TODO: function to load them from args and enivron
profiling = True