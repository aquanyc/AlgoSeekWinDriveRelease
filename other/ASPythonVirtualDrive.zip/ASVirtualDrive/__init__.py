from version import *
__version__ = get_version(pep440=False)