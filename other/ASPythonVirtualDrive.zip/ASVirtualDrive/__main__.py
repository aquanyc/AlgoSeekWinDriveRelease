import os
import sys
import logging

logging.basicConfig(level=logging.INFO , filename="drive.log")

import s3client

#get AS_DRIVE_MOUNTPOINT and AS_DRIVE_BUCKET as env variables or use default values
mountpoint = os.getenv("AS_DRIVE_MOUNTPOINT" , "Z:")
bucket = os.getenv("AS_DRIVE_BUCKET", 'us-equity-taq')

s3client.main(bucket , mountpoint)