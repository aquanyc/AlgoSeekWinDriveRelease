import os
import sys
import logging
import local_config
import s3client

local_config.load_config()
local_config.set_logging()

#get AS_DRIVE_MOUNTPOINT and AS_DRIVE_BUCKET as env variables or use default values
if local_config.config.has_key('mountpoint'):
    mountpoint = local_config.config['mountpoint']
else:
    #TODO: change on linux from Z: to something else
    mountpoint = os.getenv("AS_DRIVE_MOUNTPOINT" , "Z:")

s3client.main(mountpoint)
