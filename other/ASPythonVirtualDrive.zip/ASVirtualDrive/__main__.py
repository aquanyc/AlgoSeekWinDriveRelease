import s3client

s3client.main('as-test-public-bucket' , 'Z:')