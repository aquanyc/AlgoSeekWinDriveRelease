import datetime
import json
import os
import zlib
import sqlite3

import local_config as conf

from s3client import S3Client, NoKeyException


BUCKET = 'as-data-index'
CATALOG = 'us-equity-taq'
INDEX_FILE = 'index.json.gz'
DAY_INDEX_FILE = lambda day: os.path.join(CATALOG, '{}.csv.gz'.format(day))
PARSE_LINE = lambda line: line.split(',')


def get_connection(database, create_db=None):
    database = database + '.db' if not database.endswith('.db') else database
    if os.path.exists(database) or create_db:
        return sqlite3.connect(database, check_same_thread=False)
    else:
        raise Exception('No database found with path {}'.format(database))


def split_path(path):
    head, tail = os.path.split(path)
    if not head or head == '/':
        return tail,
    else:
        return split_path(head) + (tail,)


def load_day_data_into_bucket_db(day_data, bucket):
    def dict_factory(cursor, row):
        return {col[0]: row[idx] for idx, col in enumerate(cursor.description)}

    conn = get_connection(bucket, create_db=True)
    conn.row_factory = dict_factory

    cursor = conn.cursor()

    cursor.execute('CREATE TABLE IF NOT EXISTS bucket '
                   '(year_id INT, date_id INT, symbol_id INT, file_id INT, file_size INT,'
                   'PRIMARY KEY(year_id,date_id,symbol_id,file_id))')
    cursor.execute('CREATE TABLE IF NOT EXISTS years (year_id INT PRIMARY KEY, year TEXT)')
    cursor.execute('CREATE TABLE IF NOT EXISTS dates (date_id INT PRIMARY KEY, data_date TEXT)')
    cursor.execute('CREATE TABLE IF NOT EXISTS symbols (symbol_id INT PRIMARY KEY, first_symbol TEXT)')
    cursor.execute('CREATE TABLE IF NOT EXISTS files (file_id INT PRIMARY KEY, file_name TEXT)')

    cursor.execute('select year_id, year from years')
    years = {it['year']:it['year_id'] for it in cursor.fetchall()}
    years_key = max(years.values() or (0,))
    cursor.execute('select date_id, data_date from dates')
    dates = {it['data_date']:it['date_id'] for it in cursor.fetchall()}
    dates_key = max(dates.values() or (0,))
    cursor.execute('select symbol_id, first_symbol from symbols')
    symbols = {it['first_symbol']:it['symbol_id'] for it in cursor.fetchall()}
    symbols_key = max(symbols.values() or (0,))
    cursor.execute('select file_id, file_name from files')
    files = {it['file_name']:it['file_id'] for it in cursor.fetchall()}
    files_key = max(files.values() or (0,))
    for line in day_data.splitlines():
        _, path, file_name, _, uncompressed_size = PARSE_LINE(line)
        year, data_date, first_symbol = split_path(path)
        if year in years:
            year_id = years[year]
        else:
            years_key += 1
            year_id = years_key
            years[year] = year_id
        if data_date in dates:
            date_id = dates[data_date]
        else:
            dates_key += 1
            date_id = dates_key
            dates[data_date] = date_id
        if first_symbol in symbols:
            symbol_id = symbols[first_symbol]
        else:
            symbols_key += 1
            symbol_id = symbols_key
            symbols[first_symbol] = symbol_id
        if file_name in files:
            file_id = files[file_name]
        else:
            files_key += 1
            file_id = files_key
            files[file_name] = file_id
        cursor.execute('INSERT OR IGNORE INTO bucket VALUES (?, ?, ?, ?, ?)',
                       (year_id, date_id, symbol_id, file_id, uncompressed_size))
    cursor.executemany('INSERT OR IGNORE INTO years VALUES (?, ?)',
                       [(year_id, year) for year, year_id in years.items()])
    cursor.executemany('INSERT OR IGNORE INTO dates VALUES (?, ?)',
                       [(date_id, date) for date, date_id in dates.items()])
    cursor.executemany('INSERT OR IGNORE INTO symbols VALUES (?, ?)',
                       [(symbol_id, symbol) for symbol, symbol_id in symbols.items()])
    cursor.executemany('INSERT OR IGNORE INTO files VALUES (?, ?)',
                       [(file_id, file_name) for file_name, file_id in files.items()])
    conn.commit()
    conn.close()


def _decompress_data(data):
    return zlib.decompress(data, 16+zlib.MAX_WBITS)


def get_catalog_index(client):
    index_data = _decompress_data(client.get_object(key=os.path.join(CATALOG, INDEX_FILE)))
    return json.loads(index_data)


def get_day_index_file(client, day):
    try:
        return _decompress_data(client.get_object(key=DAY_INDEX_FILE(day)))
    except NoKeyException:
        pass


def get_last_loaded_date(bucket):
    conn = get_connection(bucket)
    cursor = conn.cursor()
    cursor.execute('select max(data_date) from dates')
    res = cursor.fetchone()
    conn.close()
    if res:
        return res[0]


def dates_between(start_date, end_date):
    for n in range(1, (end_date - start_date).days + 1):
        yield start_date + datetime.timedelta(n)


def main():
    client = S3Client(conf.AWS_ACCESS_KEY_ID, conf.AWS_SECRET_ACCESS_KEY, BUCKET)
    client.connect()
    most_recent_date = datetime.datetime.strptime(
        sorted((i for inner in get_catalog_index(client).values() for i in inner), reverse=True)[0],
        '%Y%m%d')
    last_index_date = datetime.datetime.strptime(get_last_loaded_date(CATALOG), '%Y%m%d')
    for day in dates_between(last_index_date, most_recent_date):
        data = get_day_index_file(client, day.strftime('%Y%m%d'))
        if data:
            load_day_data_into_bucket_db(data, CATALOG)


if __name__ == '__main__':
    main()
