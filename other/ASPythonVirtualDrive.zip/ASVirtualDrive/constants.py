import sys

C_755 = None

if (sys.version_info > (3, 0)):
    C_755 = 0o755
else:
    C_755 = 0755
