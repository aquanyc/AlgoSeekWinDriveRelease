import gzip
import io
import logging
import os
import stat
import struct
import sys
import tempfile
import collections
import traceback
import errno
import json

import boto3
from botocore.exceptions import ClientError

from fuse import FuseOSError, Operations, LoggingMixIn, FUSE

import local_config as conf
import vfs
from constants import C_755
import db
import filedb
import status
import status_code

MAX_INMEM_FILESIZE = 100 * 1024 * 1024
# MAX_FILE_POOL_LIMIT - the maximum number of file metadata we keep in in-memory cache
# Size considerations:
# the in-memory cache should be able to store all entries for at least one dir, so
# metadata queries done by commands like 'ls' for a directory works without quring metadata from cloud\db
# a day supedir like /2015/20150406 often contains around 8k objects so having metadata cache
# of size > 8k is a good idea too
MAX_FILE_POOL_LIMIT = 1024*16

# MAX_FILE_POOL_LIMIT - the maximum number of opened file obj we keep in in-memory cache
MAX_FILEOBJ_POOL_LIMIT = 2048


class Cache(object):
    """
    stores various temp data to enhance performance:
    For 'csv.gz' keys - file metadata including (original, not gzipped) file size 
    For '.csv' keys - file objects of temp local files
    For directories - its contents
    #TODO: make a separate cache for each data type to avoid mess...
    #TODO: check if it is used in multithreaded env...
    """

    def __init__(self, max_size=MAX_FILE_POOL_LIMIT):
        self._max_size = max_size
        self._current_size = 0
        self._cache = collections.OrderedDict()

    def _renew(self, key):
        val = self._cache.pop(key, None)
        if val:
            self._cache[key] = val

    def _clean(self):
        while len(self._cache) > self._max_size:
            val = self._cache.popitem(last=False) # pops the oldest item from the list
            try:
                val.close()
            except Exception:
                pass

    def get(self, key):
        if key in self._cache:
            self._renew(key)
            return self._cache[key]

    def set(self, key, value):
        if key not in self._cache:
            self._cache[key] = value
        elif key in self._cache and self._cache[key] is not value:
            old_value = self._cache[key]
            try:
                old_value.close()
            except Exception:
                pass
            self._cache[key] = value
        else:
            self._renew(key)
        self._clean()


class NoKeyException(Exception):
    """Raise when key does not exist in s3."""

class S3Client(object):
    logger = logging.getLogger('s3-client')

    def __init__(self, access_key, secret_key, bucket_name):
        self.access_key = access_key
        self.secret_key = secret_key
        self.bucket_name = bucket_name
        self.session = None

    def connect(self):
        self.s3 = boto3.client('s3', aws_access_key_id=self.access_key, aws_secret_access_key=self.secret_key)

    def get_file_stream(self, file_name):
        response = self.s3.get_object(Bucket=self.bucket_name, Key=file_name, RequestPayer='requester')
        return io.BytesIO(response['Body'].read())

    def get_object(self, key, **kwargs):
        try:
            response = self.s3.get_object(Bucket=self.bucket_name, Key=key, RequestPayer='requester', **kwargs)
            return response['Body'].read()
        except self.s3.exceptions.NoSuchKey:
            raise NoKeyException

    def list_objects(self, path=None):
        paginator = self.s3.get_paginator('list_objects')
        params = {'Bucket': self.bucket_name, 'Delimiter': '/', 'RequestPayer':'requester'}
        if path and len(path) > 1:
            params['Prefix'] = path[1:] + '/'
        page_iterator = paginator.paginate(**params)
        result = []
        for page in page_iterator:
            result.extend([{'name': obj['Key'], 'size': obj['Size'], 'id': obj['ETag']}
                           for obj in page.get('Contents', [])])
            result.extend([{'name': obj['Prefix'], 'size': 4096, 'id': None}
                           for obj in page.get('CommonPrefixes', [])])
        return result

    def get_metadata(self, path):
        response = self.s3.get_object(Bucket=self.bucket_name, Key=path, RequestPayer='requester')
        return response

    def download_file(self, key, fileobj):
        self.s3.download_fileobj(Fileobj=fileobj, Bucket=self.bucket_name, Key=key,
                                 ExtraArgs={'RequestPayer': 'requester'})

class BucketFS(LoggingMixIn, Operations):
    """FUSE Operations implementation class for 1 bucket"""
    logger = logging.getLogger('bucket-s3fs')

    def __init__(self, path_prefix="" , bucket=""):
        self._default_status = "Bucket "+bucket+" mounted, Status: OK"
        self._default_status_code = status_code.OK
        self.client = S3Client(conf.AWS_ACCESS_KEY_ID, conf.AWS_SECRET_ACCESS_KEY, bucket)
        self.client.connect()
        self.cache = Cache()
        self.fileobj_cache = Cache(MAX_FILEOBJ_POOL_LIMIT)
        self.bucket = bucket

        # a prefix for any path inside fs that should be ignored
        self.path_prefix = path_prefix 
        if not self.path_prefix.startswith("/"):
            self.path_prefix = "/"+self.path_prefix
        if self.path_prefix.endswith("/"):
            self.path_prefix = self.path_prefix[:-1]

        self.db_connection = None
        self._reopen_db()
        
        if self.db_connection == None:
            status.set_status("FAILED to load cache database!" , status_code.LOCAL_DB_FAILURE , self.bucket)
        else:
            status.set_status(self._default_status , self._default_status_code)
        
            
    def _reopen_db(self):
        try:
            self.db_connection = filedb.get_connection(self.bucket) 
        except Exception as e:
            #TODO: make some notification
            self.logger.warning("Cannot find S3 key database")
            self.logger.warning(traceback.format_exc())

    def _get_key(self, key):
        return '{}.gz'.format(key)

    def _full_path(self, partial):
        if partial.startswith('/'):
            partial = partial[1:]
        path = os.path.join(self.root, partial)
        return path

    def _get_gz_size(self, key):
        if key.startswith('/'):
            key = key[1:]
        if not key.endswith('.gz'):
            key += '.gz'
        size = struct.unpack('I', self.client.get_object(key, Range='bytes=-4'))[0]
        return size

    def _download(self, path):
        self.logger.debug("_download %r", path)
        prefix = self._get_key(os.path.basename(path))
        local_file = tempfile.NamedTemporaryFile(prefix=prefix)
        try:
            self.client.download_file(path[1:], local_file)
        except ClientError as e:
            logging.error("S3 Error while downloading " + path)
            logging.error(str(e) + " " + e.response['Error']['Message'])
            status.set_status("Failed to download data. " + e.response['Error']['Code'], status_code.GENERIC_DATA_ACCESS_ERROR, str(e))
            # convert http error code to errno
            oserr = OSError(errno.EIO, "Generic AWS IO error. " + e.response['Error']['Code'])
            if e.response['ResponseMetadata']['HTTPStatusCode'] == 403:
                status.set_status("Failed to download data. ", status_code.FAILED_ACCESS_DENIED , str(e))
                oserr = OSError(errno.EACCES , 'Access denied.')
            if e.response['ResponseMetadata']['HTTPStatusCode'] == 404:
                oserr = OSError(errno.ENOENT , 'Not found.')
            if oserr:
                raise oserr
            raise
        except Exception as e:
            raise OSError(errno.EIO, "Generic IO error. " + str(e))
        local_file.seek(0)
        self.logger.debug("!!!!!!!!!!!!!!!!! Finished download %r", path)
        return gzip.GzipFile(fileobj=local_file, mode='rb')

    def getattr(self, path, fh=None):
        self.logger.debug("getattr path=%r", path)
        if path.startswith(self.path_prefix):
            path = path.replace(self.path_prefix, "", 1)
        if not path.endswith('csv'): #TODO: make more reliable way to determine if it's a file or not by e.g. checking its size
            metadata = vfs.get_default_metadata()
            metadata['st_mode'] = (stat.S_IFDIR | C_755) #TODO: set to readonly
            metadata['st_size'] = 4096
        else:
            metadata = vfs.get_default_metadata()
            size = self.cache.get(path + '.gz')
            if size is None:
                self.logger.debug("File metadata is absent in metadata cache")
                try:
                    size = filedb.get_file_size(self.db_connection, path)
                except Exception:
                    self.logger.warn("Failed to get metadata from db - quering the cloud")
                    size = self._get_gz_size(path + '.gz')
                self.cache.set(path, size)

            metadata['st_size'] = size
            metadata['st_mode'] = (stat.S_IFREG | C_755)

        return metadata

    def readdir(self, path, fh=None):
        self.logger.debug("readdir path=%r", path)
        if self.db_connection == None:
            self._reopen_db()
            if self.db_connection == None:
                status.set_status("Cannot load data as no index is downloaded yet for " + path , status_code.LOCAL_DB_EMPTY, self.bucket)
                return []
        if path.startswith(self.path_prefix):
            path = path.replace(self.path_prefix, "", 1)
        
        
        dirs = ['.', '..']
        strip_gz = lambda in_str: in_str[:-3] if in_str.endswith('.gz') else in_str
        basename = lambda in_str: os.path.basename(os.path.normpath(in_str))
        try:
            metadata = self.cache.get(path)
            if metadata is None:
                metadata = filedb.get_folder_content(self.db_connection, path)
            for item in metadata:
                # If there are files metadata, cache sizes
                if 'file_name' in item and 'file_size' in item and item['file_name'].endswith('csv.gz'):
                    #TODO: check if compressed is set or not
                    self.cache.set(path + '/' + item['file_name'], item['file_size'])
                dirs.append(strip_gz(item['file_name']))
        except Exception as e:
            logging.warn("Failed to find directory " + path + " " + str(e))
            status.set_status("Directory not found " + str(e) , status_code.NOT_FOUND)
            raise OSError(errno.ENOENT , 'No such directory')
        self.cache.set(path, metadata)
        status.set_status(self._default_status , self._default_status_code)
        return dirs

    def read(self, path, size, offset, fh):
        self.logger.debug("read '%s' '%i' '%i' '%s'" % (path, size, offset, fh))
        if self.db_connection == None:
            status.set_status("Cannot load data as no index is downloaded yet for " + path , status_code.LOCAL_DB_EMPTY, self.bucket)
            return ""
        if path.startswith(self.path_prefix):
            path = path.replace(self.path_prefix, "", 1)
        fileobj = self.fileobj_cache.get(path)
        if not fileobj:
            try:
                fileobj = self._download(path + '.gz')
                self.fileobj_cache.set(path, fileobj)
            except Exception as e:
                logging.warn("Failed to download file " + path + " " + str(e))
                raise
        status.set_status(self._default_status , self._default_status_code)
        fileobj.seek(offset)
        return fileobj.read(size)

    def release(self, path, fh):
        '''closes the temp file descriptor when the virtual file is closed by OS'''
        self.logger.debug("release path=%r", path)
        if path.startswith(self.path_prefix):
            path = path.replace(self.path_prefix, "", 1)
            
        try:
            #TODO: test what happened when cache is being cleaned
            #TODO: also, note the approach is not very thread-safe, should impl some locks
            fileobj = self.fileobj_cache.get(path)
            if fileobj:
                fileobj.close()
                self.fileobj_cache.set(path, None)
        except Exception as e:
            self.logger.debug('failed to release fileobj ' + str(e))
            

        
    def statfs(self, path):
        self.logger.debug("statfs %r", path)
        return {
            "f_namemax" : 512,
            "f_bsize" : 1024 * 1024,
            "f_blocks" : 1024 * 1024 * 1024,
            "f_bfree" : 1024 * 1024 * 1024,
            "f_bavail" : 1024 * 1024 * 1024,
            "f_files" : 1024 * 1024 * 1024,
            "f_favail" : 1024 * 1024 * 1024,
            "f_ffree" : 1024 * 1024 * 1024
        }

        

class QGS3FS(LoggingMixIn, Operations):
    """FUSE Operations implementation class"""
    logger = logging.getLogger('qg-s3fs')

    def __init__(self, root, vfs_metadata=None):
        self.root = root
        self._default_status = "MOUNTED "+root+" Status: OK"
        self.vfs = vfs.VFS(vfs_metadata, BucketFS)
        self._mount_notified = False
        

    def getattr(self, path, fh=None):
        try:
            lookup = self.vfs.get(path)
            if isinstance(lookup,vfs.MountPoint): #forward to mount point (BucketFS object)
                #TODO: check if this function is available and impl
                return lookup.mount_point_obj.getattr(path, fh)
            if lookup:
                metadata = lookup.metadata
            else:
                raise OSError(errno.ENOENT , 'Error looking for file\directory ' + path)
            return metadata
        except Exception as e:
            self.logger.warn("Unexpected error getattr() "  + str(e))
            self.logger.warn(traceback.format_exc())
        return []

    def readdir(self, path, fh=None):
        try:
            lookup = self.vfs.get(path)
            self.logger.debug("Lookup result for " + path + " : " + str(lookup))
            if isinstance(lookup, vfs.MountPoint): #forward to mount point (BucketFS object)
                #TODO: check if this function is available and impl
                return lookup.mount_point_obj.readdir(path, fh)
            if isinstance(lookup, vfs.Directory):
                return [f.name for f in lookup.content]
        except Exception as e:
            self.logger.warn("Unexpected error readdir() "  + str(e))
            self.logger.warn(traceback.format_exc())
        self.logger.warn("Failed to find directory " + path )
        status.set_status("WARNING Directory not found " + path)
        raise OSError(errno.ENOENT , 'No such directory')
        

    def read(self, path, size, offset, fh):
        try:
            lookup = self.vfs.get(path)
            if isinstance(lookup, vfs.MountPoint): #forward to mount point (BucketFS object)
                #TODO: check if this function is available and impl
                return lookup.mount_point_obj.read(path, size, offset, fh)
        except Exception as e:
            self.logger.warn("Unexpected error read() "  + str(e))
            self.logger.warn(traceback.format_exc())

        self.logger.warn("Failed to find file " + path )
        status.set_status("WARNING File not found " + path )
        raise OSError(errno.ENOENT , 'No file found')

    def release(self, path, fh):
        lookup = None
        try:
            lookup = self.vfs.get(path)
            if isinstance(lookup, vfs.MountPoint): #forward to mount point (BucketFS object)
                #TODO: check if this function is available and impl
                return lookup.mount_point_obj.release(path, fh)
        except Exception as e:
            self.logger.warn("Unexpected error release() "  + str(e))
            self.logger.warn(traceback.format_exc())
        if not lookup:
            self.logger.warn("Failed to find file " + path)
            status.set_status("WARNING File not found ")
            raise OSError(errno.ENOENT , 'No file found')
        else:
            return
            
    def statfs(self, path):
        #TODO: change it to something more appealing to Windows Explorer
        if not self._mount_notified:
            status.set_status(self._default_status , status_code.MOUNTED , self.root)
            self._mount_notified = True
        self.logger.debug("statfs %r", path)
        return {
            "f_namemax" : 512,
            "f_bsize" : 1024 * 1024,
            "f_blocks" : 1024 * 1024 * 1024,
            "f_bfree" : 1024 * 1024 * 1024,
            "f_bavail" : 1024 * 1024 * 1024,
            "f_files" : 1024 * 1024 * 1024,
            "f_favail" : 1024 * 1024 * 1024,
            "f_ffree" : 1024 * 1024 * 1024
        }
        return 0



def main(mountpoint, **kwargs):
    mountpath = mountpoint
    
    if sys.platform != 'cygwin' and sys.platform != 'nt' and sys.platform != 'win32': #not windows
        mountpath = os.path.abspath(mountpoint)
    else: # if windows
        import win32file
        win32file._setmaxstdio(2048) # maximum amount of files that is opened simultaneously. cannot be incresed due to system limits

        
    mount_options = {
        'mountpoint': mountpath,
        'fsname':'qgs3fs',
        'allow_other': True,
        'auto_cache': True,
        'atime': False,
        'max_read': 131072,
        'max_write': 131072,
        'max_readahead': 131072,
        'direct_io': True,
        'ro': True,
        'debug': False,
        'nothreads': True,
        'foreground': True,
    }
    if sys.platform == 'darwin':
        mount_options['volname'] = os.path.basename(mountpoint)
        mount_options['noappledouble'] = True
        mount_options['daemon_timeout'] = 3600
    else:
        mount_options['big_writes'] = True
    

    # load metadata
    metadata_path = os.path.dirname(__file__) + "/test.json" #TODO: remove test.json in prod
    if conf.config.has_key('folders'):
        metadata_path = conf.config['folders']
    try:
        folder_metadata = json.loads(open(metadata_path, "r").read())
    except Exception as e:
        logging.error("Cannot load metadata from file: " + str(e))
        logging.error(traceback.format_exc())
        return
    
    try:
        fs = QGS3FS(mountpoint, folder_metadata)
        FUSE(fs, **mount_options)
    except Exception as e:
        status.set_status("FAILED to mount " + mountpoint + " " + str(e) , status_code.MOUNT_FAILURE)
        logging.error(str(e))
        logging.error(traceback.format_exc())


if __name__ == '__main__':
    import argparse
    local_config.load_config()
    local_config.set_logging()
    parser = argparse.ArgumentParser('QuantGo FUSE RO interface to S3 buckets')
    parser.add_argument('--mount-point', required=True, help='Path to mount point.')
    args = parser.parse_args()
    logging.basicConfig(level=logging.ERROR)
    sys.exit(main(args.mount_point))
