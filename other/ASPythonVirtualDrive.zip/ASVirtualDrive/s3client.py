import gzip
import io
import logging
import os
import stat
import struct
import sys
import tempfile
import collections
import traceback
import errno

import boto3
from botocore.exceptions import ClientError

from fuse import FuseOSError, Operations, LoggingMixIn, FUSE

import local_config as conf
import vfs
from constants import C_755
import db
import status

MAX_INMEM_FILESIZE = 100 * 1024 * 1024
MAX_FILE_POOL_LIMIT = 2048


class Cache(object):

    def __init__(self, max_size=MAX_FILE_POOL_LIMIT):
        self._max_size = max_size
        self._current_size = 0
        self._cache = collections.OrderedDict()

    def _renew(self, key):
        val = self._cache.pop(key, None)
        if val:
            self._cache[key] = val

    def _clean(self):
        while len(self._cache) > MAX_FILE_POOL_LIMIT:
            val = self._cache.popitem()
            try:
                val.close()
            except Exception:
                pass

    def get(self, key):
        if key in self._cache:
            self._renew(key)
            return self._cache[key]

    def set(self, key, value):
        if key not in self._cache:
            self._cache[key] = value
        elif key in self._cache and self._cache[key] is not value:
            old_value = self._cache[key]
            try:
                old_value.close()
            except Exception:
                pass
            self._cache[key] = value
        else:
            self._renew(key)
        self._clean()


class S3Client(object):
    logger = logging.getLogger('s3-client')

    def __init__(self, access_key, secret_key, bucket_name):
        self.access_key = access_key
        self.secret_key = secret_key
        self.bucket_name = bucket_name
        self.session = None

    def connect(self):
        self.s3 = boto3.client('s3', aws_access_key_id=self.access_key, aws_secret_access_key=self.secret_key)

    def get_file_stream(self, file_name):
        response = self.s3.get_object(Bucket=self.bucket_name, Key=file_name, RequestPayer='requester')
        return io.BytesIO(response['Body'].read())

    def get_object(self, key, **kwargs):
        response = self.s3.get_object(Bucket=self.bucket_name, Key=key, RequestPayer='requester', **kwargs)
        return response['Body'].read()

    def list_objects(self, path=None):
        paginator = self.s3.get_paginator('list_objects')
        params = {'Bucket': self.bucket_name, 'Delimiter': '/', 'RequestPayer':'requester'}
        if path and len(path) > 1:
            params['Prefix'] = path[1:] + '/'
        page_iterator = paginator.paginate(**params)
        result = []
        for page in page_iterator:
            result.extend([{'name': obj['Key'], 'size': obj['Size'], 'id': obj['ETag']}
                           for obj in page.get('Contents', [])])
            result.extend([{'name': obj['Prefix'], 'size': 4096, 'id': None}
                           for obj in page.get('CommonPrefixes', [])])
        return result

    def get_metadata(self, path):
        response = self.s3.get_object(Bucket=self.bucket_name, Key=path, RequestPayer='requester')
        return response

    def download_file(self, key, fileobj):
        self.s3.download_fileobj(Fileobj=fileobj, Bucket=self.bucket_name, Key=key,
                                 ExtraArgs={'RequestPayer': 'requester'})


class QGS3FS(LoggingMixIn, Operations):
    """FUSE Operations implementation class"""
    logger = logging.getLogger('qg-s3fs')

    def __init__(self, bucket, root):
        self.root = root
        self._default_status = "MOUNTED "+root+" Status: OK" 
        self.client = S3Client(conf.AWS_ACCESS_KEY_ID, conf.AWS_SECRET_ACCESS_KEY, bucket)
        self.client.connect()
        self.vfs = None
        self.cache = Cache()
        try:
            self.db_connection = db.get_connection(bucket)
            status.set_status(self._default_status)
        except Exception as e:
            status.set_status("FAILED to load cache database!")
            self.logger.error("FATAL: Cannot find S3 key database")
            self.logger.error(traceback.format_exc())

    def _get_key(self, key):
        return '{}.gz'.format(key)

    def _full_path(self, partial):
        if partial.startswith('/'):
            partial = partial[1:]
        path = os.path.join(self.root, partial)
        return path

    def _get_gz_size(self, key):
        if key.startswith('/'):
            key = key[1:]
        if not key.endswith('.gz'):
            key += '.gz'
        size = struct.unpack('I', self.client.get_object(key, Range='bytes=-4'))[0]
        return size

    def _download(self, path):
        self.logger.debug("_download %r", path)
        prefix = self._get_key(os.path.basename(path))
        local_file = tempfile.NamedTemporaryFile(prefix=prefix)
        try:
            self.client.download_file(path[1:], local_file)
        except ClientError as e:
            logging.error("S3 Error while downloading " + path)
            logging.error(str(e) + " " + e.response['Error']['Message'])
            if e.response['ResponseMetadata']['HTTPStatusCode'] == 403:
                raise OSError(errno.EACCES , 'Access denied.')
            if e.response['ResponseMetadata']['HTTPStatusCode'] == 404:
                raise OSError(errno.ENOENT , 'Not found.')
            raise
        local_file.seek(0)
        self.logger.debug("!!!!!!!!!!!!!!!!! Finished download %r", path)
        return gzip.GzipFile(fileobj=local_file, mode='rb')

    def getattr(self, path, fh=None):
        self.logger.debug("getattr path=%r", path)
        if not path.endswith('csv'):
            metadata = vfs.get_default_metadata()
            metadata['st_mode'] = (stat.S_IFDIR | C_755)
            metadata['st_size'] = 4096
        else:
            metadata = vfs.get_default_metadata()
            size = self.cache.get(path + '.gz')
            if size is None:
                try:
                    size = db.get_file_size(self.db_connection, path)
                except Exception:
                    size = self._get_gz_size(path + '.gz')
                self.cache.set(path, size)

            metadata['st_size'] = size
            metadata['st_mode'] = (stat.S_IFREG | C_755)

        return metadata

    def readdir(self, path, fh=None):
        self.logger.debug("readdir path=%r", path)
        dirs = ['.', '..']
        strip_gz = lambda in_str: in_str[:-3] if in_str.endswith('.gz') else in_str
        basename = lambda in_str: os.path.basename(os.path.normpath(in_str))
        try:
            metadata = self.cache.get(path)
            if metadata is None:
                metadata = db.get_folder_content(self.db_connection, path)
            for item in metadata:
                name_field = 'year' if 'year' in item else \
                    'data_date' if 'data_date' in item else \
                        'first_symbol' if 'first_symbol' in item else \
                            'file_name' if 'file_name' in item else None
                # If there are files metadata, cache sizes
                if 'file_name' in item and item['file_name'].endswith('csv.gz'):
                    self.cache.set(path + '/' + item['file_name'], item['file_size'])
                dirs.append(strip_gz(item[name_field]))
        except Exception as e:
            logging.warn("Failed to find directory " + path + " " + str(e))
            status.set_status("WARNING Directory not found in cache " + str(e))
            raise OSError(errno.ENOENT , 'No such directory')
        self.cache.set(path, metadata)
        status.set_status(self._default_status)
        return dirs

    def read(self, path, size, offset, fh):
        self.logger.debug("read '%s' '%i' '%i' '%s'" % (path, size, offset, fh))
        fileobj = self.cache.get(path)
        if not fileobj:
            try:
                fileobj = self._download(path + '.gz')
                self.cache.set(path, fileobj)
            except Exception as e:
                logging.warn("Failed to download file " + path + " " + str(e))
                status.set_status("WARNING Failed to download data. " + str(e))
                raise
        status.set_status(self._default_status)
        fileobj.seek(offset)
        return fileobj.read(size)

    def statfs(self, path):
        self.logger.debug("statfs %r", path)
        return {
            "f_namemax" : 512,
            "f_bsize" : 1024 * 1024,
            "f_blocks" : 1024 * 1024 * 1024,
            "f_bfree" : 1024 * 1024 * 1024,
            "f_bavail" : 1024 * 1024 * 1024,
            "f_files" : 1024 * 1024 * 1024,
            "f_favail" : 1024 * 1024 * 1024,
            "f_ffree" : 1024 * 1024 * 1024
        }

    def _get_attr_native(self, path):
        self.logger.debug("_get_attr_native %r", path)
        st = os.lstat(path)
        return {key: getattr(st, key) for key in
                ('st_atime', 'st_ctime', 'st_gid', 'st_mode', 'st_mtime', 'st_nlink', 'st_size', 'st_uid')}


def main(bucket, mountpoint, **kwargs):
    mountpath = mountpoint
    if sys.platform != 'cygwin' and sys.platform != 'nt' and sys.platform != 'win32':
        mountpath = os.path.abspath(mountpoint)
    mount_options = {
        'mountpoint': mountpath,
        'fsname':'qgs3fs',
        'allow_other': True,
        'auto_cache': True,
        'atime': False,
        'max_read': 131072,
        'max_write': 131072,
        'max_readahead': 131072,
        'direct_io': True,
        'ro': True,
        'debug': False,
        'nothreads': True,
        'foreground': True,
    }
    if sys.platform == 'darwin':
        mount_options['volname'] = os.path.basename(mountpoint)
        mount_options['noappledouble'] = True
        mount_options['daemon_timeout'] = 3600
    else:
        mount_options['big_writes'] = True

    try:
        FUSE(QGS3FS(bucket, mountpoint), **mount_options)
    except Exception as e:
        status.set_status("FAILED to mount " + mountpoint + " . Generic driver error. Please consult log files for more info.")
        logging.error(str(e))
        logging.error(traceback.format_exc())


if __name__ == '__main__':
    import argparse
    parser = argparse.ArgumentParser('QuantGo FUSE RO interface to S3 buckets')
    parser.add_argument('--mount-point', required=True, help='Path to mount point.')
    parser.add_argument('--bucket', required=True, help='Bucket name.')
    args = parser.parse_args()
    logging.basicConfig(level=logging.ERROR)
    sys.exit(main(args.bucket, args.mount_point))
