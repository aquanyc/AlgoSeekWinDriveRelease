"""
 s3client.py
 This module implements FUSE virtual filesystem that works as a client to AWS S3.
 This class defines FUSE callback classes (QGS3FS and BucketFS) along with several supplimentary classes
 for in-memory caching of metadata and accessing AWS S3.
"""

#standard libs
import gzip
import io
import logging
import os
import stat
import struct
import sys
import tempfile
import collections
import traceback
import errno
import json
import threading

#3-rd party libs
import boto3
from botocore.exceptions import ClientError
from fuse import FuseOSError, Operations, LoggingMixIn, FUSE

#local imports
import local_config as conf
import vfs
from constants import C_755
import db
import filedb
import status
import status_code

MAX_INMEM_FILESIZE = 100 * 1024 * 1024
# MAX_FILE_POOL_LIMIT - the maximum number of file metadata we keep in in-memory cache
# Size considerations:
# the in-memory cache should be able to store all entries for at least one dir, so
# metadata queries done by commands like 'ls' for a directory works without quring metadata from cloud\db
# a day supedir like /2015/20150406 often contains around 8k objects so having metadata cache
# of size > 8k is a good idea too
MAX_FILE_POOL_LIMIT = 1024*16

# MAX_FILE_POOL_LIMIT - the maximum number of opened file obj we keep in in-memory cache
MAX_FILEOBJ_POOL_LIMIT = 2048

class Cache(object):
    """
        In-memory key-value cache to store various temp data to enhance performance:
        For 'csv.gz' keys - file metadata including (original, not gzipped) file size 
        For '.csv' keys - file objects of temp local files
        For directories - its contents
    """

    def __init__(self, max_size=MAX_FILE_POOL_LIMIT):
        """inits the cache with maximum size"""
        self._max_size = max_size
        self._current_size = 0
        self._cache = collections.OrderedDict()

    def _renew(self, key):
        """Updates cache value"""
        val = self._cache.pop(key, None)
        if val:
            self._cache[key] = val

    def _clean(self):
        """Remove old entries if cache size exceeds the predefined size"""
        while len(self._cache) > self._max_size:
            val = self._cache.popitem(last=False) # pops the oldest item from the list
            try:
                val.close()
            except Exception:
                pass

    def get(self, key):
        """gets data from in-mem cache"""
        if key in self._cache:
            self._renew(key)
            return self._cache[key]

    def set(self, key, value):
        """
            Save data to in-mem cache.
            Remove old entries if cache size exceeds the predefined size
        """
        if key not in self._cache:
            self._cache[key] = value
        elif key in self._cache and self._cache[key] is not value:
            old_value = self._cache[key]
            try:
                old_value.close()
            except Exception:
                pass
            self._cache[key] = value
        else:
            self._renew(key)
        self._clean()


class NoKeyException(Exception):
    """
        Auxillary exception (for use in filedb module)
        Raise when key does not exist in s3.
    """

class S3Client(object):
    """
        A wrapper for AWS S3 operations performed by boto3 library.
    """
    logger = logging.getLogger('s3-client')

    def __init__(self, access_key, secret_key, bucket_name):
        """ Constructor taking AWS keys and bucket as parms"""
        self.access_key = access_key
        self.secret_key = secret_key
        self.bucket_name = bucket_name
        self.session = None

    def connect(self):
        """ Initializes boto3 objects """
        self.s3 = boto3.client('s3', aws_access_key_id=self.access_key, aws_secret_access_key=self.secret_key)

    def get_file_stream(self, file_name):
        """
            Downloads a file from bucket.
            Returns file stream object constructed from downloaded data
        """
        response = self.s3.get_object(Bucket=self.bucket_name, Key=file_name, RequestPayer='requester')
        return io.BytesIO(response['Body'].read())

    def get_object(self, key, **kwargs):
        """
            Downloads a file from bucket.
            Returns byte array of file data
        """
        try:
            response = self.s3.get_object(Bucket=self.bucket_name, Key=key, RequestPayer='requester', **kwargs)
            return response['Body'].read()
        except self.s3.exceptions.NoSuchKey:
            raise NoKeyException

    def list_objects(self, path=None):
        """
            Lists objects in a bucket.
            (Not used actually)
        """
        paginator = self.s3.get_paginator('list_objects')
        params = {'Bucket': self.bucket_name, 'Delimiter': '/', 'RequestPayer':'requester'}
        if path and len(path) > 1:
            params['Prefix'] = path[1:] + '/'
        page_iterator = paginator.paginate(**params)
        result = []
        for page in page_iterator:
            result.extend([{'name': obj['Key'], 'size': obj['Size'], 'id': obj['ETag']}
                           for obj in page.get('Contents', [])])
            result.extend([{'name': obj['Prefix'], 'size': 4096, 'id': None}
                           for obj in page.get('CommonPrefixes', [])])
        return result

    def get_metadata(self, path):
        """
           Gets S3 object medatada.
        """
        response = self.s3.head_object(Bucket=self.bucket_name, Key=path, RequestPayer='requester')
        return response

    def download_file(self, key, fileobj):
        """
           Downloads file specified by 'key' and saves its data to file object
           with RequestPayer set.
        """
        self.s3.download_fileobj(Fileobj=fileobj, Bucket=self.bucket_name, Key=key,
                                 ExtraArgs={'RequestPayer': 'requester'})

class BucketFS(LoggingMixIn, Operations):
    """
        Intro
            AlgoSeek stock data is stored in a number of separate buckets in AWS S3.
            Each bucket contain a specific dataset e.g. trades, equity, options and so on. 
        Details
            BucketFS is mounted to one of virtual dirs created by root QGS3FS class.
            QGS3FS forwards FUSE callbacks to BucketFS objects (one BucketFS object per virtual directory mount point)
            BucketFS is a 'concrete file system' class that has
            one source bucket per 'concrete file system' object.
            For instance, BucketFS mounted to '/Trades/US Equity Trades' has
            'us-equity-trades' source bucket.
            There is no hardcoded correspondence between mount point names and bucket names. The correspondence between mount point name and a bucket name is governed by VFS configuration.
            BucketFS (BucketFS class, s3client.py) implements file system callbacks:
            readdir(), getattr(), read(), and release().
    """
    logger = logging.getLogger('bucket-s3fs')

    def __init__(self, path_prefix="" , bucket=""):
        """
            Constructor. Initializes object with supplimentary structures and application-wide configs.
            Takes path_prefix (a mount point path), and target bucket name as parm.
        """
        self._default_status = "Bucket "+bucket+" mounted, Status: OK"
        self._default_status_code = status_code.OK
        self.client = S3Client(conf.AWS_ACCESS_KEY_ID, conf.AWS_SECRET_ACCESS_KEY, bucket)
        self.client.connect()
        self.fileobj_cache = Cache(MAX_FILEOBJ_POOL_LIMIT)
        self.cache = Cache()
        self.bucket = bucket
        
        # Load application wide configs
        #TODO: move this options somewhere else e.g. as parm
        if conf.config.has_key("uncompression") and conf.config["uncompression"] == "off":
            self.uncompression = False
        else:
            self.uncompression = True
        if conf.config.has_key("cache_update_sec"):
            self.update_seconds = int(conf.config["cache_update_sec"])
        else:
            self.update_seconds = 60*60 #1hour 

        # set a prefix (mount point path) for any path inside fs that should be ignored
        self.path_prefix = path_prefix 
        if not self.path_prefix.startswith("/"):
            self.path_prefix = "/"+self.path_prefix
        if self.path_prefix.endswith("/"):
            self.path_prefix = self.path_prefix[:-1]

        # try to open index db
        self.db_connection = None
        self._reopen_db()
        
        if self.db_connection == None:
            status.set_status("FAILED to load cache database!" , status_code.LOCAL_DB_FAILURE , self.bucket)
        else:
            status.set_status(self._default_status , self._default_status_code)

        # set DB autoupdate
        if self.update_seconds:
            self._set_update_timer()

    def _set_update_timer(self):
        """
            Internal function to set index db autoupdate timer
        """
        threading.Timer(self.update_seconds, self._set_update_timer).start()
        self._update_db()

    def _update_db(self):
        """
            Internal function to update db
            It is called every self._set_update_timer seconds
        """
        try:
            if self.db_connection:
                self.logger.info("Updating db for " + self.bucket)
                filedb.update_db(self.bucket)
        except Exception as e:
            self.logger.warn("Unexpected error updating db "  + str(e))
            self.logger.warn(traceback.format_exc())
        
            
    def _reopen_db(self):
        """
            Intenal function to try to reopen DB.
        """
        try:
            self.db_connection = filedb.get_connection(self.bucket) 
        except Exception as e:
            #TODO: make some notification
            self.logger.warning("Cannot find S3 key database")
            self.logger.warning(traceback.format_exc())

    def _get_key(self, key):
        """
            Internal function to convert a filename to AWS key
            (Not used)
        """
        return '{0}.gz'.format(key)

    def _full_path(self, partial):
        """
            Internal function. (Not used)
        """
        if partial.startswith('/'):
            partial = partial[1:]
        path = os.path.join(self.root, partial)
        return path

    def _get_compressed_size(self, key):
        """
            Internal function to get object compressed size from S3 (not index).
            (Not used but might be helpful in the future)
        """
        if key.startswith('/'):
            key = key[1:]
        if not key.endswith('.gz'):
            key += '.gz'
        metadata = self.client.get_metadata(key)
        size = 0
        if metadata.has_key('ContentLength'):
            size = int(metadata['ContentLength'])
        else:
            self.logger.warning("Failed to get the size of S3 object " + key)
        return size

    def _get_gz_size(self, key):
        """
            Internal function.
            Gets the decompressed size of S3 object by reading several bytest from .gz header
        """
        if key.startswith('/'):
            key = key[1:]
        if not key.endswith('.gz'):
            key += '.gz'
        size = struct.unpack('I', self.client.get_object(key, Range='bytes=-4'))[0]
        return size

    def _download(self, path):
        """
            Internal function. Downloads a file from S3 storage and store it locally.
            Converts S3 exception to FUSE-compatible OSError 
        """
        self.logger.debug("_download %r", path)
        prefix = self._get_key(os.path.basename(path))
        local_file = tempfile.NamedTemporaryFile(prefix=prefix)
        try:
            self.client.download_file(path[1:], local_file)
        except ClientError as e:
            logging.error("S3 Error while downloading " + path)
            logging.error(str(e) + " " + e.response['Error']['Message'])
            status.set_status("Failed to download data. " + e.response['Error']['Code'], status_code.GENERIC_DATA_ACCESS_ERROR, str(e))
            # convert http error code to errno
            oserr = OSError(errno.EIO, "Generic AWS IO error. " + e.response['Error']['Code'])
            if e.response['ResponseMetadata']['HTTPStatusCode'] == 403:
                status.set_status("Failed to download data. ", status_code.FAILED_ACCESS_DENIED , str(e))
                oserr = OSError(errno.EACCES , 'Access denied.')
            if e.response['ResponseMetadata']['HTTPStatusCode'] == 404:
                oserr = OSError(errno.ENOENT , 'Not found.')
            if oserr:
                raise oserr
            raise
        except Exception as e:
            raise OSError(errno.EIO, "Generic IO error. " + str(e))
        local_file.seek(0)
        self.logger.debug("!!!!!!!!!!!!!!!!! Finished download %r", path)
        if not self.uncompression:
            return local_file
        else:
            return gzip.GzipFile(fileobj=local_file, mode='rb')

    def getattr(self, path, fh=None):
        """
            FUSE callback: gets file system object attrs to learn its metadata including type (file or dir), and size.
            readdir() and getattr() perform the following operations:
                1. Check if index is available. If it is not available,
                    it notifies the App and aborts the operation.
                2. Check metadata in-memory cache for corresponding metadata.
                    If it is available, returns the cached data.
                3. Get metadata from the index database.
                    Save it to in-memory cache. For getattr(),
                    return all relevant metadata; for readdir(),
                    return directory content names only
                    (other metadata is kept in in-memory cache to speed up the subsequent getattr() calls).
                4. Return error if no metadata is available.
            Note, in current implementation, getattr() treats all paths that do not end with .csv extension as folders.
            Note, in current implementation, getattr() tries to query AWS for file size in case data is absent in Index. 
        """
        self.logger.debug("getattr path=%r", path)
        if not self.uncompression and path.endswith('.gz'):
            path = path[:-3] # removes trailing gz

        # removes mount-point prefix
        if path.startswith(self.path_prefix):
            path = path.replace(self.path_prefix, "", 1)
            
        # Anything that is not csv is treated as directory
        #TODO: make more reliable way to determine if it's a file or not by e.g. checking its size
        if not path.endswith('csv'): 
            metadata = vfs.get_default_metadata()
            metadata['st_mode'] = (stat.S_IFDIR | C_755) #TODO: set to readonly
            metadata['st_size'] = 4096
        else:
            # try to get data from inmemory cache
            metadata = vfs.get_default_metadata()
            size = self.cache.get(path + '.gz')                
            if size is None:
                # if data is unavailable in cache
                self.logger.debug("File metadata is absent in metadata cache")
                try:
                    # get it from Index DB
                    size = filedb.get_file_size(self.db_connection, path, not self.uncompression)
                except Exception as e:
                    self.logger.warn("Failed to get metadata from db - quering the cloud. " + str(e))
                    # Fallback: get data directly from AWS
                    if self.uncompression:
                        size = self._get_gz_size(path + '.gz')
                    else:
                        size = self._get_compressed_size(path + '.gz')
                # save data in in-memory cache     
                self.cache.set(path, size)
            metadata['st_size'] = size
            metadata['st_mode'] = (stat.S_IFREG | C_755)
        return metadata

    def readdir(self, path, fh=None):
        """
            FUSE callback: enums contents of a dir
            readdir() and getattr() perform the following operations:
                readdir() and getattr() perform the following operations:
                1. Check if index is available. If it is not available,
                    it notifies the App and aborts the operation.
                2. Check metadata in-memory cache for corresponding metadata.
                    If it is available, returns the cached data.
                3. Get metadata from the index database.
                    Save it to in-memory cache. For getattr(),
                    return all relevant metadata; for readdir(),
                    return directory content names only
                    (other metadata is kept in in-memory cache to speed up the subsequent getattr() calls).
                4. Return error if no metadata is available.
        """
        self.logger.debug("readdir path=%r", path)

        #Try to reopen index database if not available
        if self.db_connection == None:
            self._reopen_db()
            if self.db_connection == None:
                # send LOCAL_DB_EMPTY message to a client app
                status.set_status("Cannot load data as no index is downloaded yet for " + path , status_code.LOCAL_DB_EMPTY, self.bucket)
                return []
            
        # remove mount point prefix
        if path.startswith(self.path_prefix):
            path = path.replace(self.path_prefix, "", 1)

        #populate resulting array with default entries
        dirs = ['.', '..']
        if self.uncompression:
            strip_gz = lambda in_str: in_str[:-3] if in_str.endswith('.gz') else in_str
        else:
            strip_gz = str

        basename = lambda in_str: os.path.basename(os.path.normpath(in_str))
        try:
            # try to get data from local in memory cache
            metadata = self.cache.get(path)
            if metadata is None:
                # if not available get dir contents from the index
                metadata = filedb.get_folder_content(self.db_connection, path)
            for item in metadata:
                # If there file metadata available, pre-cache file sizes
                if 'file_name' in item and item['file_name'].endswith('csv.gz'):
                    size = None
                    # save compressed or uncompressed size depending on self.uncompression value
                    if self.uncompression and 'file_size' in item:
                        size = item['file_size']
                    if not self.uncompression and 'gz_file_size' in item:
                        size = item['gz_file_size']
                    if size:
                        # save size entry in in-memory cache
                        self.cache.set(path + '/' + item['file_name'], size)
                # add dir entries to resulting array
                dirs.append(strip_gz(item['file_name']))
        except Exception as e:
            self.logger.warn("Failed to find directory " + path + " " + str(e))
            status.set_status("Directory not found " + str(e) , status_code.NOT_FOUND)
            raise OSError(errno.ENOENT , 'No such directory')
        # save directory contents to in-memory cache also
        self.cache.set(path, metadata)
        # set status OK
        status.set_status(self._default_status , self._default_status_code)
        return dirs

    def read(self, path, size, offset, fh):
        """
            FUSE callback: read data from a file.
            read() callback downloads data from S3 by a path given.
            1. Converts the file system path to S3 path deleting mount point prefix and applying .gz extension if required 
            2. Checks in-memory file object cache if local file is already available. If yes, read local file object data and return.
            3. If local file is not available, download file by using S3 path (implemented in S3Client class, s3client.py) from a bucket associated with BucketFS by the initial config with S3 keys set by initial config. Save the downloaded file to a temporary directory and open it saving its handle to in-memory file object cache, then read and return its data.
            4. If S3 error happens, notify the App and return an error code as a callback result.
        """
        self.logger.debug("read '%s' '%i' '%i' '%s'" % (path, size, offset, fh))
        if not self.uncompression and path.endswith('.gz'):
            path = path[:-3] # removes trailing .gz

        #check if index DB is available
        if self.db_connection == None:
            status.set_status("Cannot load data as no index is downloaded yet for " + path , status_code.LOCAL_DB_EMPTY, self.bucket)
            return ""

        # remove mount point prefix
        if path.startswith(self.path_prefix):
            path = path.replace(self.path_prefix, "", 1)

        # check if file is already available in fileobj cache
        fileobj = self.fileobj_cache.get(path)
        if not fileobj:
            try:
                # download file
                fileobj = self._download(path + '.gz')
                # save fileobj to cache
                self.fileobj_cache.set(path, fileobj)
            except Exception as e:
                self.logger.warn("Failed to download file " + path + " " + str(e))
                raise
        status.set_status(self._default_status , self._default_status_code)
        fileobj.seek(offset)
        # read the downloaded file and return data to OS
        return fileobj.read(size)

    def release(self, path, fh):
        """
            FUSE callback: closes a file handle (meaning corresponding resources may be freed
            release() destroys resources allocated for a file when it is closed. In current implementation it closes file object handle in in-memory file object cache that corresponds to a file being closed.
        """
        self.logger.debug("release path=%r", path)
        if not self.uncompression and path.endswith('.gz'):
            path = path[:-3] # removes trailing gz

        # remove mount point prefix
        if path.startswith(self.path_prefix):
            path = path.replace(self.path_prefix, "", 1)
            
        try:
            fileobj = self.fileobj_cache.get(path)
            if fileobj:
                fileobj.close()
                self.fileobj_cache.set(path, None)
        except Exception as e:
            self.logger.debug('failed to release fileobj ' + str(e))
        
    def statfs(self, path):
        """
            FUSE callback. Not used.
        """
        self.logger.debug("statfs %r", path)
        return {
            "f_namemax" : 512,
            "f_bsize" : 1024 * 1024,
            "f_blocks" : 1024 * 1024 * 1024,
            "f_bfree" : 1024 * 1024 * 1024,
            "f_bavail" : 1024 * 1024 * 1024,
            "f_files" : 1024 * 1024 * 1024,
            "f_favail" : 1024 * 1024 * 1024,
            "f_ffree" : 1024 * 1024 * 1024
        }

        

class QGS3FS(LoggingMixIn, Operations):
    """
        FUSE Operations implementation class.
        Root file system is implemented via QGS3FS class. It is an entry point for FUSE callbacks implementing actual file system logic.
        Whenever a file operation occur and QGS3FS callback is called,
        it inquiries VFS class to check if the operation targets a 'mount point'.
        If yes, then the operation is forwarded to a 'concrete file system object'.
        The only 'concrete file system' currently available is BucketFS.
        Normally, the Driver mounts several BucketFS object, one for each data
        bucket available (see BucketFS implementation details below).
        QGS3FS implements readdir() and getaddr() for VFS file folder,
        while forwarding all other operations to corresponding 'concrete file systems'.
        QGS3FS also implements statfs() callback to return default values to operating system,
        and init() callback to notify the App that the Driver is ready.
    """
    logger = logging.getLogger('qg-s3fs')

    def __init__(self, root, vfs_metadata=None):
        """
            Constructor.
            inits with VFS metadata that defines virtual folders and BucketFS 'mount points'.
        """
        self.root = root
        self._default_status = "MOUNTED "+root+" Status: OK"
        self.vfs = vfs.VFS(vfs_metadata, BucketFS)
        self._mount_notified = False
        

    def getattr(self, path, fh=None):
        """
            FUSE callback.
            Forwarded to corresponding 'concrete file system'
        """
        # Fires MOUNTED notification if ncessary
        if not self._mount_notified:
            status.set_status(self._default_status , status_code.MOUNTED , self.root)
            self._mount_notified = True
        try:
            lookup = self.vfs.get(path)
            #forward to 'mount point' (BucketFS object)
            if isinstance(lookup,vfs.MountPoint): 
                #TODO: check if this function is available and impl
                return lookup.mount_point_obj.getattr(path, fh)
            # returns metadata supplied by VFS object if no 'mount point' available
            if lookup:
                metadata = lookup.metadata
            else:
                raise OSError(errno.ENOENT , 'Error looking for file\directory ' + path)
            return metadata
        except Exception as e:
            self.logger.warn("Unexpected error getattr() "  + str(e))
            self.logger.warn(traceback.format_exc())
        return []

    def readdir(self, path, fh=None):
        """
            FUSE callback.
            Forwarded to corresponding 'concrete file system' if targets 'mount point'
        """
        try:
            lookup = self.vfs.get(path)
            self.logger.debug("Lookup result for " + path + " : " + str(lookup))
            #forward to mount point (BucketFS object)
            if isinstance(lookup, vfs.MountPoint): 
                #TODO: check if this function is available and impl
                return lookup.mount_point_obj.readdir(path, fh)
            # if it is a virtual directory, return its contents
            if isinstance(lookup, vfs.Directory):
                return [f.name for f in lookup.content]
        except Exception as e:
            self.logger.warn("Unexpected error readdir() "  + str(e))
            self.logger.warn(traceback.format_exc())
        self.logger.warn("Failed to find directory " + path )
        status.set_status("WARNING Directory not found " + path)
        raise OSError(errno.ENOENT , 'No such directory')
        

    def read(self, path, size, offset, fh):
        """
            FUSE callback.
            Forwarded to corresponding 'concrete file system'.
        """
        try:
            lookup = self.vfs.get(path)
            #forward to mount point (BucketFS object)
            if isinstance(lookup, vfs.MountPoint): 
                #TODO: check if this function is available and impl
                return lookup.mount_point_obj.read(path, size, offset, fh)
        except Exception as e:
            self.logger.warn("Unexpected error read() "  + str(e))
            self.logger.warn(traceback.format_exc())

        self.logger.warn("Failed to find file " + path )
        status.set_status("WARNING File not found " + path )
        raise OSError(errno.ENOENT , 'No file found')

    def release(self, path, fh):
        """
            FUSE callback.
            Forwarded to corresponding 'concrete file system'.
        """
        lookup = None
        try:
            lookup = self.vfs.get(path)
            #forward to mount point (BucketFS object)
            if isinstance(lookup, vfs.MountPoint): 
                #TODO: check if this function is available and impl
                return lookup.mount_point_obj.release(path, fh)
        except Exception as e:
            self.logger.warn("Unexpected error release() "  + str(e))
            self.logger.warn(traceback.format_exc())
        if not lookup:
            self.logger.warn("Failed to find file " + path)
            status.set_status("WARNING File not found ")
            raise OSError(errno.ENOENT , 'No file found')
        else:
            return

    def init(self , init_parm1 = None, init_parm2 = None):
        """
            FUSE callback.
            The first operation is called when FS mounted
            Notifues the App that the Driver is ready with MOUNTED code
        """
        if not self._mount_notified:
            status.set_status(self._default_status , status_code.MOUNTED , self.root)
            self._mount_notified = True
            
    def statfs(self, path):
        """
            FUSE callback.
            Gets file system info like free space
            Returns default values to operating system
        """
        if not self._mount_notified:
            status.set_status(self._default_status , status_code.MOUNTED , self.root)
            self._mount_notified = True
        self.logger.debug("statfs %r", path)
        #TODO: change it to something more appealing to Windows Explorer
        return {
            "f_namemax" : 512,
            "f_bsize" : 1024 * 1024,
            "f_blocks" : 1024 * 1024 * 1024,
            "f_bfree" : 1024 * 1024 * 1024,
            "f_bavail" : 1024 * 1024 * 1024,
            "f_files" : 1024 * 1024 * 1024,
            "f_favail" : 1024 * 1024 * 1024,
            "f_ffree" : 1024 * 1024 * 1024
        }
        return 0



def main(mountpoint, **kwargs):
    """The main function"""

    #prepare mountpoint path and specific parms depending on the platform
    mountpath = mountpoint
    if sys.platform != 'cygwin' and sys.platform != 'nt' and sys.platform != 'win32': #not windows
        mountpath = os.path.abspath(mountpoint)
    else: # if windows
        # win-specific
        import win32file
        # maximum amount of files that is opened simultaneously. cannot be incresed due to system limits
        win32file._setmaxstdio(2048) 

    # default FUSE options
    mount_options = {
        'mountpoint': mountpath,
        'fsname':'qgs3fs',
        'allow_other': True,
        'auto_cache': True,
        'atime': False,
        'max_read': 131072,
        'max_write': 131072,
        'max_readahead': 131072,
        'direct_io': True,
        'ro': True,
        'debug': False,
        'nothreads': True,
        'foreground': True,
    }
    if sys.platform == 'darwin':
        mount_options['volname'] = os.path.basename(mountpoint)
        mount_options['noappledouble'] = True
        mount_options['daemon_timeout'] = 3600
    else:
        mount_options['big_writes'] = True
    

    # load VFS metadata from config
    #TODO: remove test.json in prod
    metadata_path = os.path.dirname(__file__) + "/test.json" 
    if conf.config.has_key('folders'):
        metadata_path = conf.config['folders']
    try:
        folder_metadata = json.loads(open(metadata_path, "r").read())
    except Exception as e:
        logging.error("Cannot load metadata from file: " + str(e))
        logging.error(traceback.format_exc())
        return
    
    try:
        # create QGS3FS and start FUSE
        fs = QGS3FS(mountpoint, folder_metadata)
        FUSE(fs, **mount_options)
    except Exception as e:
        status.set_status("FAILED to mount " + mountpoint + " " + str(e) , status_code.MOUNT_FAILURE)
        logging.error(str(e))
        logging.error(traceback.format_exc())


if __name__ == '__main__':
    #TODO: remove legacy code, now everything starts from __main__.py
    import argparse 
    conf.load_config()
    conf.set_logging()
    parser = argparse.ArgumentParser('QuantGo FUSE RO interface to S3 buckets')
    parser.add_argument('--mount-point', required=True, help='Path to mount point.')
    args = parser.parse_args()
    logging.basicConfig(level=logging.ERROR)
    sys.exit(main(args.mount_point))
