"""
 filedb.py
 implements a database of s3 object metadata that is backed up by underlying FS
 (mostly compatible with soon-to-be-deprecated db.py)
"""

#standard libs
import datetime
import json
import os
import zlib
import logging
import zipfile

#local libs
import local_config as conf

# some default values (may be overriden by update_db())
BUCKET = 'as-data-index'
CATALOG = 'us-equity-taq' 
INDEX_FILE = 'index.json.gz'
DAY_INDEX_FILE = lambda day: (CATALOG + '/{}.csv.gz'.format(day))
PARSE_LINE = lambda line: line.split(',')
ROOT_DIR = './index'
METADATA_FILENAME = "AS_metadata.csv"
LOCAL_INDEX = "AS_index.json"
MERGE_THRESHOLD = 4096 


def get_connection(database, create_db=None):
    """
         Gets connection object (a string) to the database
         (mimics sql-like semantics, see db.py).
         Database name should be equal to bucket name.
    """
    db_path = ROOT_DIR + "/" + database
    if create_db:
        if os.path.exists(db_path):
            if not os.path.isdir(db_path):
                raise Exception("Collision during the index database creation! " + db_path + " is already exists and not a directory!")
        else:
            os.makedirs(db_path)
    else:
        if not os.path.exists(db_path):
            #now zipfile opens on read only
            #if os.path.exists(db_path+".zip")
            #    return zipfile.ZipFile(db_path+".zip")
            return None
    return db_path


def get_folder_content(connection, path):
    """
        Gets list of object metadata in a FS folder specified by path from index.

        Performs the following steps:        
        1. Index database searches if there is a corresponding subfolder (with the same directory name path as requested directory) in database folder. 
        2. If a) database folder exists, index database enlists all
        (local filesystem) folders within the folder found to return them
        as subfolders. Then, index database open AS_metadata.csv file inside the folder if available, and searches for all file entries that have folder path matching the folder
        (direct ascendants in the hierarchy) to return them either as files or folders. 
        3. If b) database folder is absent,
        index database searches for a folder one level higher
        and AS_metadata.csv there and seeks for the folder entry,
        and its direct ascendants so to return them (if an upper-level folder is also absent, it goes one level higher again till the topmost folder is reached).
    """
    # connection.check_path
    dir_path = connection+"/"+path
    if os.path.exists(dir_path) and os.path.isdir(dir_path) == False:
        raise Exception(dir_path + " is not a directory")
    local_file_name = METADATA_FILENAME
    # connection.get_metadata
    result = list()

    # add raw files and directories from the dir
    if os.path.exists(dir_path) and os.path.isdir(dir_path):
        for dir_item in os.listdir(dir_path):
            if dir_item != local_file_name and dir_item != LOCAL_INDEX:
                result.append({'file_name': dir_item})

    # iterate thru directories from the lowest level to highest one in search for metadata
    # the reason is some dirs may not have metadata inside because its size is too small
    while dir_path and dir_path not in connection:
        file_path = dir_path + "/" + local_file_name
        if os.path.exists(file_path):
            with open(file_path , "r") as f:
                # read lines in metadata file (if available) to find corresponding entries
                for line in f.readlines():
                    if not line or line == "\n":
                        continue
                    _, file_path, file_name, compressed_size, uncompressed_size = parse_line(line)
                    if "/"+file_path == path.rstrip("/"):
                        if compressed_size:
                            result.append({'file_name': file_name, 'file_size': int(uncompressed_size), 'gz_file_size': int(compressed_size)})
                        else:
                            result.append({'file_name': file_name}) #it is directory
            break
        # switch to parent dir
        dir_path = dir_path.rstrip("/")
        dir_path = os.path.dirname(dir_path)

    if not result and not os.path.exists(dir_path):
        raise Exception("No entry for " + path + " found")
    return result


def get_file_size(connection, path, compressed=False):
    """
        Gets (compressed or decompressed) size of object specified by path from index.
        
        The logic of get_file_size() is essentially the same
        with get_folder_contents(). The difference is get_file_size()
        looks for one file only and stops whenever the file is found
        returning its compressed or decompressed size depending on
        the value of corresponding get_file_size() parameter.
    """
    virtual_file_path = connection+"/"+path
    # Note: here we can also query if virtual_file_path exists in a dir and return it...

    # iterate thru directories from the lowest level to highest one in search for metadata
    # the reason is some dirs may not have metadata inside because its size is too small
    dir_path = os.path.dirname(virtual_file_path)
    local_file_name = METADATA_FILENAME
    while dir_path and dir_path not in connection:
        file_path = dir_path + "/" + local_file_name
        if os.path.exists(file_path):
            with open(file_path , "r") as f:
                for line in f.readlines():
                    # read lines in metadata file (if available) to find the entry
                    if not line or line == "\n":
                        continue
                    _, file_path, file_name, compressed_size, uncompressed_size = parse_line(line)
                    if os.path.dirname(path) == "/"+file_path and os.path.basename(path) == file_name:
                        if compressed:
                            return int(compressed_size)
                        else:
                            return int(uncompressed_size)
            break
        # switch to parent dir
        dir_path = dir_path.rstrip("/")
        dir_path = os.path.dirname(dir_path)
    raise Exception("File entry not found " + path)

# --------- DB CREATION


def _merge_metadata(bucket , threshold = MERGE_THRESHOLD):
    """
        Perform merge of small metadata files (size < threshold).
        Walks recursively through directories within index searching
        for files smaller than threshold. if found, concatenate file contents
        with contents of metadata file in parent dir and delete the original file.

        Explanation:
        When index is made, it creates many AS_metadata files.
        For some buckets these files are too numerous (around 1M)
        while very small (say, around 100 bytes).
        It results in more than 1GB disk
        consumption while actual data is around 100MB
        (Mostly often, a file takes a minimum of 1 file system cluster of disk
        space despite of its actual size. So, if a file is 1 byte it still takes
        1 cluster). Merge option merges metadata files that are smaller than N
        (4096, that is the default NTFS cluster size, by default)
        bytes to a parent metadata file (a file that resides in a parent directory)
        during index creation.
        It results in more efficient storage of data
        and RAM requirements during zip/unzip operations. 
    """
    root_path = ROOT_DIR+"/"+bucket
    # a callback function that is called by os.path.walk for every file and folder in index
    def walkfunc(threshold, dirname, names):
        if dirname == root_path:
            return
        if METADATA_FILENAME in names:
            # if metadata file is found in a dir
            if os.stat(dirname+'/'+METADATA_FILENAME).st_size < threshold:
                # read source file
                src = open(dirname+'/'+METADATA_FILENAME , "r")
                # open parent file
                upper_dirname = os.path.dirname(dirname)
                dest = open(upper_dirname + '/' + METADATA_FILENAME , "a+")
                dest.write("\n")
                # write source data to parent file
                dest.write(src.read())
                src.close()
                # remove source file
                os.remove(dirname+'/'+METADATA_FILENAME)
                # remove the dir if it is empty
                # and add a dir entry to metadata csv
                if len(os.listdir(dirname)) == 0:
                    os.rmdir(dirname)
                    relative_upper_dirname = upper_dirname.replace("\\","/").replace(root_path+"/" , "" , 1)
                    base_dirname = os.path.basename(dirname)
                    dest.write("{0},{1},{2},0,0\n".format(bucket,relative_upper_dirname,base_dirname)) 
                dest.close()
    # walk through index and merge small files
    os.path.walk(root_path , walkfunc , threshold)
    

def get_last_loaded_date(bucket):
    """
        get last loaded date from a local index file
    """
    dir_path = ROOT_DIR+"/"+bucket
    if os.path.exists(dir_path) == False:
        raise Exception("Database not found: " + bucket)
    json_path = ROOT_DIR+"/"+bucket+"/"+LOCAL_INDEX
    with open(json_path, "r") as f:
        data = json.loads(f.read())
    dates = sorted((i for inner in data.values() for i in inner), reverse=True)
    return dates[0]

def save_local_index(dates, bucket):
    """
        saves local index file with dates downloaded
    """
    dir_path = ROOT_DIR+"/"+bucket
    if os.path.exists(dir_path) == False:
        raise Exception("Database not found: " + bucket)
    json_path = ROOT_DIR+"/"+bucket+"/"+LOCAL_INDEX
    with open(json_path, "w") as f:
        f.write(json.dumps({"dates":dates}, indent=2))
    

def load_day_data_into_bucket_db(day_data, bucket):
    """
        Loads data from date CSV file to appropriate metadata index file.
        
        For every object read, open a corresponding AS_metadata.csv
        file in local index database and write entry there.
        Corresponding AS_metadata.csv file is located by taking
        the S3 object path (relative to bucket)
        e.g. /2016/20160202/A/AAA.csv, removing
        ending filename AAA.csv, and
        appending AS_metadata.csv filename,
        and local index database location prefix resulting
        in ./index/us-equity-taq/2016/20160202/A/AS_metadata.csv path
        to store metadata for this S3 object. 
    """
    for line in day_data.splitlines():
        # parses csv line
        _, path, file_name, compressed_size, uncompressed_size = parse_line(line)
        dir_path = ROOT_DIR+"/"+bucket+"/"+path
        # find a dir to store metadata
        if os.path.exists(dir_path):
            if not os.path.isdir(dir_path):
                raise Exception("Collision during the index creation! " + dir_path + " is both file and a directory!")
        else:
            os.makedirs(dir_path)
        # append data to metdata file
        local_file_name = METADATA_FILENAME
        file_path = dir_path + "/" + local_file_name
        with open(file_path, "a+") as f:
            f.write(line+"\n")

       
def parse_line(line):
    """parses csv line"""
    result = PARSE_LINE(line)
    if len(result) < 5:
        raise Exception("Malformed line in csv file : \n" + str(line))
    return (result[0],result[1],result[2],result[3],result[4])

def _decompress_data(data):
    """unzips data"""
    return zlib.decompress(data, 16+zlib.MAX_WBITS)


def get_catalog_index(client):
    """downloads, decompresses and parses catalog index.json.gz file"""
    index_data = _decompress_data(client.get_object(CATALOG +"/"+ INDEX_FILE))
    return json.loads(index_data)


def get_day_index_file(client, day):
    """
        Downloads a S3 CSV file contents for a date
        Returns None if no CSV file available in S3.
    """
    from s3client import NoKeyException
    try:
        return _decompress_data(client.get_object(key=DAY_INDEX_FILE(day)))
    except NoKeyException:
        pass



def dates_between(start_date, end_date):
    """ Populates an array with all calendar dates between start_date and end_date"""
    for n in range(1, (end_date - start_date).days + 1):
        yield start_date + datetime.timedelta(n)

def archive_db(catalog):
    """
        Create a Zip archive from a database.
    """
    dir_path = ROOT_DIR+"/"+catalog
    zf = zipfile.ZipFile(dir_path + '.zip',
                     "w",
                     zipfile.ZIP_DEFLATED,
                     allowZip64=True)
    for root, subdirs, filenames in os.walk(dir_path):
        for subdir in subdirs:
            #this adds a dir entry to zip arc
            subdir_name = os.path.join(root, subdir)
            arcname = subdir_name.replace(ROOT_DIR,"", 1)[1:]
            zfi = zipfile.ZipInfo(arcname+"/") 
            zf.writestr(zfi, '')
        for name in filenames:
            # add a filename to archive
            filename = os.path.join(root, name)
            arcname = filename.replace(ROOT_DIR,"", 1)
            zf.write(filename, arcname)


def update_db(catalog = None, aws_key = None, aws_secret=None, index_bucket=None, create_new=False , compress=False , merge=0):
    """
        Index database is built by executing update_db() with create_new parameter set to True (filedb.py).
        update_db() call with create_new parameter set to False updates existing DB.

        To create\update an index, update_db() performs the following actions:
        1. Connects to AWS via keys provided.
        2. Gets catalog index file that corresponds to the bucket
           from as-index-data, e.g. s3://as-index-data/us-equity-taq/index.json.gz,
           unzips and parses it to get a list of available dates.
           It gets the most and last recent dates from the list.
        3. Checks if local index is already exists.
           If yes, searches for /AS_index.json file inside of it.
           The file contains list of dates that were already downloaded by the previous
           update_db() run. The last recent date is set to the most recent date of
           the list. If not, fails if create_new is set to
           False, or creates new index database if create_new is set to True.
        4. For each date between the last recent and most recent,
           download day data file e.g. s3://as-index-data/us-equity-taq/20090303.csv.gz and parse it getting all objects in the corresponding bucket for that day and their corresponding metadata values. For every object read, open a corresponding AS_metadata.csv file in local index database and write entry there. Corresponding AS_metadata.csv file is located by taking the S3 object path (relative to bucket) e.g. /2016/20160202/A/AAA.csv, removing ending filename AAA.csv, and appending AS_metadata.csv filename, and local index database location prefix resulting in ./index/us-equity-taq/2016/20160202/A/AS_metadata.csv
           path to store metadata for this S3 object. 
        5. Save local index file /AS_index.json to speed up future create\update operations. 
        6. If merge option is specified, perform metadata merging.
        7. If compression option is enabled, create an archive. 
        
        merge=0 means no merging. merge > 0 means merge threshold.         
        TODO: describe other parms
    """
    global CATALOG
    if not catalog:
        catalog = CATALOG
    else:
        CATALOG = catalog
    if not aws_key:
        aws_key = conf.AWS_ACCESS_KEY_ID
    if not aws_secret:
        aws_secret = conf.AWS_SECRET_ACCESS_KEY
    if not index_bucket:
        index_bucket = BUCKET

    from s3client import S3Client
    client = S3Client(aws_key, aws_secret, index_bucket)
    client.connect()
    dates = sorted((i for inner in get_catalog_index(client).values() for i in inner), reverse=True)
    most_recent_date = datetime.datetime.strptime(dates[0],'%Y%m%d')
    last_recent_date = datetime.datetime.strptime(dates[-1],'%Y%m%d')
    try:
        # check for local index.json file
        last_index_date = datetime.datetime.strptime(get_last_loaded_date(catalog), '%Y%m%d')
    except Exception as e:
        # if unavailable check create_new parm
        logging.info("Cannot load last data updated from the database.")
        if create_new:
            logging.info("Starting from the first date ever creating new database")
            last_index_date = last_recent_date
        else:
            logging.error("Create new database flag not specified. Aborting...")
            raise
    # iterate every date between last_index_date and most_recent_date
    for day in dates_between(last_index_date, most_recent_date):
        logging.info("Loading " + day.strftime('%Y%m%d'))
        data = get_day_index_file(client, day.strftime('%Y%m%d'))
        if data:
            # update DB with data
            load_day_data_into_bucket_db(data, catalog)
    # save local index.json file when ready
    save_local_index(dates, catalog)
    if merge:
        logging.info("Merging metadata...")
        _merge_metadata(catalog , merge)
    if compress:
        logging.info("Creating an archive...")
        archive_db(catalog)


if __name__ == '__main__':
    import argparse
    logging.basicConfig(level=logging.INFO)
    parser = argparse.ArgumentParser('Create/update index db script')
    parser.add_argument('--index', required=False, help='Path to index bucket.')
    parser.add_argument('--bucket', required=True, help='Bucket name.')
    parser.add_argument('--awskey', required=False, help='AWS Key.')
    parser.add_argument('--awssecret', required=False, help='AWS Secret Key.')
    parser.add_argument('--new', required=False, action='store_true', help='Create new index database if not present.')
    parser.add_argument('--compress', required=False, action='store_true', help='Compress folder into archive afterwards.')
    parser.add_argument('--merge', required=False, help='If set, merge small metadata files into larger ones to save space. The parameter sets the threshold size in bytes of metadata. Files below the size are merged.')
    args = parser.parse_args()
    update_db(args.bucket, args.awskey, args.awssecret, args.index, args.new, args.compress , int(args.merge))
