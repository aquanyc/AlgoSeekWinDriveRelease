"""implements a database of s3 objects that is backed up by underlying FS"""

import datetime
import json
import os
import zlib
import logging
import zipfile

import local_config as conf

BUCKET = 'as-data-index'
CATALOG = 'us-equity-taq' 
INDEX_FILE = 'index.json.gz'
DAY_INDEX_FILE = lambda day: (CATALOG + '/{}.csv.gz'.format(day))
PARSE_LINE = lambda line: line.split(',')
ROOT_DIR = '.\index'
METADATA_FILENAME = "AS_metadata.csv"
LOCAL_INDEX = "AS_index.json"
MERGE_THRESHOLD = 4096 #TODO: move to parm

# --------- DB READ

#class FileConnection
#+ open()
#+ isdir()
#+ exists()
#+ listdir()
#+ create()
#+ makedirs()

#class ZipConnection
#+ listdir(dir):
#if not dir.endswith('/'):
#   dir += '/'
#result = [f for f in file_names if len(f) > len(dir) and f.startswith(dir) and not '/' in f[len(dir):-1]]

def get_connection(database, create_db=None):
    """gets connection string to the database (emulate sql-like connection str). database should be equal to bucket"""
    db_path = ROOT_DIR + "/" + database
    if create_db:
        if os.path.exists(db_path):
            if not os.path.isdir(db_path):
                raise Exception("Collision during the index database creation! " + db_path + " is already exists and not a directory!")
        else:
            os.makedirs(db_path)
    else:
        if not os.path.exists(db_path):
            #now zipfile opens on read only
            #if os.path.exists(db_path+".zip")
            #    return zipfile.ZipFile(db_path+".zip")
            return None
    return db_path


def get_folder_content(connection, path):
    # connection.check_path
    dir_path = connection+"/"+path
    if not os.path.exists(dir_path):
        raise Exception("No entry for " + path + " found")
    if os.path.isdir(dir_path) == False:
        raise Exception(dir_path + " is not a directory")
    local_file_name = METADATA_FILENAME
    # connection.get_metadata
    result = list()

    # add raw files and directories from the dir 
    for dir_item in os.listdir(dir_path):
        if dir_item != local_file_name and dir_item != LOCAL_INDEX:
            result.append({'file_name': dir_item})

    # iterate thru directories from the lowest level to highest one in search for metadata
    # the reason is some dirs may not have metadata inside because its size is too small
    while dir_path and dir_path not in connection:
        file_path = dir_path + "/" + local_file_name
        if os.path.exists(file_path):
            with open(file_path , "r") as f:
                for line in f.readlines():
                    if not line or line == "\n":
                        continue
                    _, file_path, file_name, compressed_size, uncompressed_size = parse_line(line)
                    if "/"+file_path == path.rstrip("/"):
                        result.append({'file_name': file_name, 'file_size': int(uncompressed_size), 'gz_file_size': int(compressed_size)})
            break
        dir_path = dir_path.rstrip("/")
        dir_path = os.path.dirname(dir_path)
    
    return result


def get_file_size(connection, path, compressed=False):
    virtual_file_path = connection+"/"+path
    # Note: here we can also query if virtual_file_path exists in a dir and return it...
    # connection.get_metadata
    dir_path = os.path.dirname(virtual_file_path)
    local_file_name = METADATA_FILENAME
    while dir_path and dir_path not in connection:
        file_path = dir_path + "/" + local_file_name
        if os.path.exists(file_path):
            with open(file_path , "r") as f:
                for line in f.readlines():
                    if not line or line == "\n":
                        continue
                    _, file_path, file_name, compressed_size, uncompressed_size = parse_line(line)
                    if os.path.dirname(path) == "/"+file_path and os.path.basename(path) == file_name:
                        if compressed:
                            return int(compressed_size)
                        else:
                            return int(uncompressed_size)
            break
        dir_path = dir_path.rstrip("/")
        dir_path = os.path.dirname(dir_path)
    raise Exception("File entry not found " + path)

# --------- DB CREATION


def _merge_metadata(bucket , threshold = MERGE_THRESHOLD):
    root_path = ROOT_DIR+"/"+bucket
    def walkfunc(threshold, dirname, names):
        if dirname == root_path:
            return
        if METADATA_FILENAME in names:
            if os.stat(dirname+'/'+METADATA_FILENAME).st_size < threshold:
                src = open(dirname+'/'+METADATA_FILENAME , "r")
                upper_dirname = os.path.dirname(dirname)
                dest = open(upper_dirname + '/' + METADATA_FILENAME , "a+")
                dest.write("\n")
                dest.write(src.read())
                src.close()
                dest.close()
                os.remove(dirname+'/'+METADATA_FILENAME)
    os.path.walk(root_path , walkfunc , threshold)
    

def get_last_loaded_date(bucket):
    dir_path = ROOT_DIR+"/"+bucket
    if os.path.exists(dir_path) == False:
        raise Exception("Database not found: " + bucket)
    json_path = ROOT_DIR+"/"+bucket+"/"+LOCAL_INDEX
    with open(json_path, "r") as f:
        data = json.loads(f.read())
    dates = sorted((i for inner in data.values() for i in inner), reverse=True)
    return dates[0]

def save_local_index(dates, bucket):
    dir_path = ROOT_DIR+"/"+bucket
    if os.path.exists(dir_path) == False:
        raise Exception("Database not found: " + bucket)
    json_path = ROOT_DIR+"/"+bucket+"/"+LOCAL_INDEX
    with open(json_path, "w") as f:
        f.write(json.dumps({"dates":dates}, indent=2))
    

def load_day_data_into_bucket_db(day_data, bucket):
    for line in day_data.splitlines():
        _, path, file_name, compressed_size, uncompressed_size = parse_line(line)
        dir_path = ROOT_DIR+"/"+bucket+"/"+path
        if os.path.exists(dir_path):
            if not os.path.isdir(dir_path):
                raise Exception("Collision during the index creation! " + dir_path + " is both file and a directory!")
        else:
            os.makedirs(dir_path)
        local_file_name = METADATA_FILENAME
        file_path = dir_path + "/" + local_file_name
        with open(file_path, "a+") as f:
            f.write(line+"\n")

       
def parse_line(line):
    result = PARSE_LINE(line)
    if len(result) < 5:
        raise Exception("Malformed line in csv file : \n" + str(line))
    return (result[0],result[1],result[2],result[3],result[4])

def _decompress_data(data):
    return zlib.decompress(data, 16+zlib.MAX_WBITS)


def get_catalog_index(client):
    index_data = _decompress_data(client.get_object(CATALOG +"/"+ INDEX_FILE))
    return json.loads(index_data)


def get_day_index_file(client, day):
    try:
        return _decompress_data(client.get_object(key=DAY_INDEX_FILE(day)))
    except NoKeyException:
        pass



def dates_between(start_date, end_date):
    for n in range(1, (end_date - start_date).days + 1):
        yield start_date + datetime.timedelta(n)

def archive_db(catalog):
    dir_path = ROOT_DIR+"/"+catalog
    zf = zipfile.ZipFile(dir_path + '.zip',
                     "w",
                     zipfile.ZIP_DEFLATED,
                     allowZip64=True)
    for root, subdirs, filenames in os.walk(dir_path):
        for subdir in subdirs:
            #this adds a dir entry to zip arc
            subdir_name = os.path.join(root, subdir)
            arcname = subdir_name.replace(ROOT_DIR,"", 1)[1:]
            zfi = zipfile.ZipInfo(arcname+"/") 
            zf.writestr(zfi, '')
        for name in filenames:
            filename = os.path.join(root, name)
            arcname = filename.replace(ROOT_DIR,"", 1)
            zf.write(filename, arcname)


def update_db(catalog = None, aws_key = None, aws_secret=None, index_bucket=None, create_new=False , compress=False , merge=0):
    global CATALOG
    if not catalog:
        catalog = CATALOG
    else:
        CATALOG = catalog
    if not aws_key:
        aws_key = conf.AWS_ACCESS_KEY_ID
    if not aws_secret:
        aws_secret = conf.AWS_SECRET_ACCESS_KEY
    if not index_bucket:
        index_bucket = BUCKET

    from s3client import S3Client, NoKeyException
    client = S3Client(aws_key, aws_secret, index_bucket)
    client.connect()
    dates = sorted((i for inner in get_catalog_index(client).values() for i in inner), reverse=True)
    most_recent_date = datetime.datetime.strptime(dates[0],'%Y%m%d')
    last_recent_date = datetime.datetime.strptime(dates[-1],'%Y%m%d')
    try:
        last_index_date = datetime.datetime.strptime(get_last_loaded_date(catalog), '%Y%m%d')
    except Exception as e:
        logging.info("Cannot load last data updated from the database.")
        if create_new:
            logging.info("Starting from the first date ever creating new database")
            last_index_date = last_recent_date
        else:
            logging.error("Create new database flag not specified. Aborting...")
            raise
    for day in dates_between(last_index_date, most_recent_date):
        logging.info("Loading " + day.strftime('%Y%m%d'))
        data = get_day_index_file(client, day.strftime('%Y%m%d'))
        if data:
            load_day_data_into_bucket_db(data, catalog)
    save_local_index(dates, catalog)
    if merge:
        logging.info("Merging metadata...")
        _merge_metadata(catalog , merge)
    if compress:
        logging.info("Creating an archive...")
        archive_db(catalog)


if __name__ == '__main__':
    import argparse
    logging.basicConfig(level=logging.INFO)
    parser = argparse.ArgumentParser('Create/update index db script')
    parser.add_argument('--index', required=False, help='Path to index bucket.')
    parser.add_argument('--bucket', required=True, help='Bucket name.')
    parser.add_argument('--awskey', required=False, help='AWS Key.')
    parser.add_argument('--awssecret', required=False, help='AWS Secret Key.')
    parser.add_argument('--new', required=False, action='store_true', help='Create new index database if not present.')
    parser.add_argument('--compress', required=False, action='store_true', help='Compress folder into archive afterwards.')
    parser.add_argument('--merge', required=False, help='If set, merge small metadata files into larger ones to save space. The parameter sets the threshold size in bytes of metadata. Files below the size are merged.')
    args = parser.parse_args()
    update_db(args.bucket, args.awskey, args.awssecret, args.index, args.new, args.compress , int(args.merge))
