# -*- coding: cp1252 -*-
"""
The module implements status pipe - a mechanism to notify user apps about fs whereabouts
It is implemented via snakemq 3-rd party library
"""

import time
import threading

import snakemq.link
import snakemq.packeter
import snakemq.messaging
import snakemq.message

#TODO: define in config
LISTEN_PORT = 4000
DRIVER_IDENT = "driver"
GUI_IDENT = "gui"
MESSAGE_TTL = 60

#TODO: wrap up in a class or something
my_link = snakemq.link.Link()
my_packeter = snakemq.packeter.Packeter(my_link)
my_messaging = snakemq.messaging.Messaging(DRIVER_IDENT, "", my_packeter)
my_link.add_listener(("", LISTEN_PORT))
#TODO: find a way to stop this and\or troubleshoot logging errors as well
message_thread = threading.Thread(target=my_link.loop)
message_thread.daemon = True
message_thread.start()

#let's leave old status file thing for compatibility
#TODO: remove it from the next versions
status_filename = "./fs.status"
current_status = ""
current_status_code = None
current_status_parm = None

def set_status(status , status_code = None, status_parm=None):
    """
        set_status function is used to add a message to a queue
        set_status converts message to a binary format and
        adds it to the queue.
         (Also there is a legacy notification
         mechanism still in place and to be removed soon
         � write last message to ./status file)
    """
    global current_status
    global current_status_code
    global current_status_parm
    current_status = status
    current_status_code = status_code
    current_status_parm = status_parm
    _update_status()
    
def _update_status():
    """Internal function to apply new status message to queue (and status file)"""
    timestamp = str(int(time.time()))
    #TODO: implement some json\xml format to make messages extendible
    message = timestamp + " " + current_status + "\nCode: " + str(current_status_code) + "\nParm: " + str(current_status_parm)
    with open(status_filename , "w") as f:
        f.write(message)
    msg = snakemq.message.Message(bytes(message), ttl=MESSAGE_TTL)
    my_messaging.send_message(GUI_IDENT, msg)
