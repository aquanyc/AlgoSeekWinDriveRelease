"""The module implements status file - a mechanism to notify user apps about fs whereabouts"""

import time

status_filename = "./fs.status"
current_status = ""

def set_status(status):
    global current_status
    current_status = status
    update_status()
    
def update_status():
    """Updates status file with the existing status but another timestamp"""
    timestamp = str(int(time.time()))
    with open(status_filename , "w") as f:
        f.write(timestamp + " " + current_status);
