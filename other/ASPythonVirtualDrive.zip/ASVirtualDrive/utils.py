import datetime
import itertools
import os
import string


def generate_dates(year):
    year_days = 365 if year % 4 else 366
    start_date = datetime.datetime(year, 1, 1)
    for day_num in xrange(year_days):
        yield start_date + datetime.timedelta(days=day_num)


def generate_working_days(year):
    for day in generate_dates(year):
        if day.weekday() < 5:
            yield day


def split_path(path):
    head, tail = os.path.split(path)
    if not head or head == '/':
        return tail,
    else:
        return split_path(head) + (tail,)


def parse_path(path):
    return {it[0]: it[1] for it in
            itertools.izip_longest(('year', 'data_date', 'first_symbol', 'file_name'), split_path(path))}


def year_days(year, date_start_with=None):
    filter = lambda x: x.startswith(date_start_with) if date_start_with is not None else True
    return [dt.strftime('%Y%m%d') for dt in generate_working_days(year) if filter(dt.strftime('%Y%m%d'))]


def get_symbols():
    return list(string.ascii_uppercase)
