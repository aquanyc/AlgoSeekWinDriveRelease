"""A module to handle configs"""

import logging
import ConfigParser
import os

# Dummy default s3 keys, access works based on bucket/IAM policies.
AWS_ACCESS_KEY_ID = "NONE"
AWS_SECRET_ACCESS_KEY = "NONE"
config = dict()
full_config = dict()

def load_config(filename="algoseek.ini"):
    """loads conf and full_conf from config ini file"""
    cfg = ConfigParser.ConfigParser()
    cfg.read(filename)
    dictionary = {}
    for section in cfg.sections():
        dictionary[section] = {}
        for option in cfg.options(section):
            dictionary[section][option] = cfg.get(section, option)
    if (dictionary.has_key('AlgoSeek')):
        global config
        config = dictionary['AlgoSeek']
    global full_config
    full_config = dictionary
    global AWS_ACCESS_KEY_ID
    global AWS_SECRET_ACCESS_KEY
    if config.has_key('aws_access'):
        AWS_ACCESS_KEY_ID = config['aws_access']
    if config.has_key('aws_secret'):
        AWS_SECRET_ACCESS_KEY = config['aws_secret']

def set_logging():
    """sets logging according to config files, load_config() should be called"""
    if full_config.has_key('logging'):
        level = logging.INFO
        if full_config['logging'].has_key('level'):
            level = int(full_config['logging']['level'])
        logging.basicConfig(level=level , filename="drive.log")
    else:
        #defaults
        logging.basicConfig(level=logging.INFO , filename="drive.log")
    

def load_keys():
    """legacy function to load keys from separate py file module"""
    # load keys from file
    try:
        import imp
        mod = imp.load_source("key", "key.cfg")
        global AWS_ACCESS_KEY_ID
        global AWS_SECRET_ACCESS_KEY
        AWS_ACCESS_KEY_ID = mod.AWS_ACCESS_KEY_ID
        AWS_SECRET_ACCESS_KEY = mod.AWS_SECRET_ACCESS_KEY
        logging.info("AWS Key " + AWS_ACCESS_KEY_ID + " loaded")
    except Exception as e:
        logging.info("Key file not loaded " + str(e))


