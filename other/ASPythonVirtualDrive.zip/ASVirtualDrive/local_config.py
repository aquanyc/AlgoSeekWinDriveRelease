import logging

# Dummy default s3 keys, access works based on bucket/IAM policies.
AWS_ACCESS_KEY_ID='AKIAIIOU5OR424SMYJTQ'
AWS_SECRET_ACCESS_KEY='KZHq2CLcfwmxKK4CTJ6/GyYDWpcTnR7vg5srzhho'

# load keys from file
try:
    import imp
    mod = imp.load_source("key", "key.cfg")
    AWS_ACCESS_KEY_ID = key.AWS_ACCESS_KEY_ID
    AWS_SECRET_ACCESS_KEY = key.AWS_SECRET_ACCESS_KEY
    logging.info("AWS Key " + AWS_ACCESS_KEY_ID + " loaded")
except Exception as e:
    logging.info("Key file not found")
