# Dummy s3 keys, access works based on bucket/IAM policies.
AWS_ACCESS_KEY_ID='AKIAJCKUF2GP5XE6BGXQ'
AWS_SECRET_ACCESS_KEY='oaTGJAEGEl0bsMaI3Pq55ZByarIMhltke7oVvvNX'
